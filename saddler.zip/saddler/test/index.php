<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Loading...</title>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r121/three.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/vanta@latest/dist/vanta.net.min.js"></script>
  <style>
body
{
  margin:0;
  padding:0;
  background: #131630;
}
#preloader {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}
#loader {
    display: block;
    position: relative;
    left: 50%;
    top: 50%;
    width: 500px;
    height: 500px;
    margin: -250px 0 0 -250px;
    border-radius: 50%;
    border: 3px solid transparent;
    border-top-color: #9370DB;
    -webkit-animation: spin 2s linear infinite;
    animation: spin 2s linear infinite;
}
#loader:before {
    content: "";
    position: absolute;
    top: 5px;
    left: 5px;
    right: 5px;
    bottom: 5px;
    border-radius: 50%;
    border: 3px solid transparent;
    border-top-color: #BA55D3;
    -webkit-animation: spin 3s linear infinite;
    animation: spin 3s linear infinite;
}
#loader:after {
    content: "";
    position: absolute;
    top: 15px;
    left: 15px;
    right: 15px;
    bottom: 15px;
    border-radius: 50%;
    border: 3px solid transparent;
    border-top-color: #FF00FF;
    -webkit-animation: spin 1.5s linear infinite;
    animation: spin 1.5s linear infinite;
}
@-webkit-keyframes spin {
    0%   {
        -webkit-transform: rotate(0deg);
        -ms-transform: rotate(0deg);
        transform: rotate(0deg);
    }
    100% {
        -webkit-transform: rotate(360deg);
        -ms-transform: rotate(360deg);
        transform: rotate(360deg);
    }
}
@keyframes spin {
    0%   {
        -webkit-transform: rotate(0deg);
        -ms-transform: rotate(0deg);
        transform: rotate(0deg);
    }
    100% {
        -webkit-transform: rotate(360deg);
        -ms-transform: rotate(360deg);
        transform: rotate(360deg);
    }
}
.title{
 display: block;
    position: absolute;
    width: auto;
    height: auto;
    
    left: 50%;
    top: 50%;
z-index: 1;
 margin: -40px 0 0 -150px;
    color: #fff;
     font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;

}
</style>
</head>
<body>
    <div class="title">
       <span style="font-weight: 600; font-size: 55px;">LunaTrade<sup style="font-size:0.6em; vertical-align:super; margin-left:4px;">mobile</sup></span>
 

</div>
    <div id="vanta-bg" style="position:fixed; top:0; left:0; width:100%; height:100%; z-index:-1 ">
</div>

 

 <div id="preloader">
  <div id="loader">

 



  </div>
</div>



  <span></span>


</div>

<script>
VANTA.NET({
  el: "#vanta-bg",
  mouseControls: true,
  touchControls: true,
  gyroControls: false,
  minHeight: 200.00,
  minWidth: 200.00,
  scale: 1.00,
  scaleMobile: 1.00,
   color: 0xff3ff3,
  backgroundColor: 0x19153c
})

 /* setTimeout(function() {
      window.location.href = "https://nag-parkway-revivable.ngrok-free.dev/newtrade_02/mobile/"; // ovdje stavi URL gdje želiš redirect
    }, 3000);

*/
</script>

</body>
</html>
