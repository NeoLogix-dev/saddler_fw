Final index/sidebar/topbar/risk fix

Kopiraj:
web folder preko postojećeg web foldera.

Šta je urađeno:
1. index.php sidebar je direktno iz signals.php, uz ispravljene putanje za dashboard:
   modules/signals.php, modules/adapter.php itd.
2. index.php topbar je direktno iz signals.php, samo su naslov i podnaslov dashboarda promijenjeni.
3. Freqtrade indikator više ne dira dashboard-balance.js.
   Samo topbar-controls.js upravlja FREQTRADE ONLINE/OFFLINE.
4. Risk traka nema vanjski border/card izgled.
   Izgleda kao dio pozadine: naslov malim slovima, vrijednost ispod, samo right border između stavki.
5. Risk traka prikazuje postojeće signal/risk podatke:
   Best Pair, Action, Score, Confidence, Risk, Reason.

Nakon kopiranja:
CTRL + F5

Ako se sidebar opet razlikuje, znači browser vuče cache ili je prepisan index.php iz starijeg ZIP-a.
