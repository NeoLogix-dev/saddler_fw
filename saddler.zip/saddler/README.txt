Kopiraj:

web/assets/css/hud.css

preko:
C:\xampp\htdocs\newtrade_02\web\assets\css\hud.css

Ovo je samo fix za collapse dugme.
Dugme se više ne izvlači van sidebara, nego u collapsed modu ide na fixed poziciju:
left:55px; top:138px;

Ako želiš malo više/lijevo-desno:
u hud.css promijeni:
.app.sidebar-collapsed #collapseBtn { left:55px; top:138px; }

Nakon kopiranja:
CTRL + F5
