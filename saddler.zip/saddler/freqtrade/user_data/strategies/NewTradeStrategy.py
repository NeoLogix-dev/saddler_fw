from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta

class NewTradeStrategy(IStrategy):
    timeframe = "5m"
    can_short = True

    minimal_roi = {
        "0": 0.012,
        "30": 0.006,
        "90": 0
    }

    stoploss = -0.018
    trailing_stop = True
    trailing_stop_positive = 0.006
    trailing_stop_positive_offset = 0.012
    trailing_only_offset_is_reached = True

    process_only_new_candles = True
    startup_candle_count = 50

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe["ema_fast"] = ta.EMA(dataframe, timeperiod=12)
        dataframe["ema_slow"] = ta.EMA(dataframe, timeperiod=26)
        dataframe["rsi"] = ta.RSI(dataframe, timeperiod=14)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe["ema_fast"] > dataframe["ema_slow"]) &
                (dataframe["rsi"] > 50) &
                (dataframe["volume"] > 0)
            ),
            ["enter_long", "enter_tag"]
        ] = (1, "newtrade_long")

        dataframe.loc[
            (
                (dataframe["ema_fast"] < dataframe["ema_slow"]) &
                (dataframe["rsi"] < 45) &
                (dataframe["volume"] > 0)
            ),
            ["enter_short", "enter_tag"]
        ] = (1, "newtrade_short")

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe["ema_fast"] < dataframe["ema_slow"]) |
                (dataframe["rsi"] < 42)
            ),
            ["exit_long", "exit_tag"]
        ] = (1, "exit_long_signal")

        dataframe.loc[
            (
                (dataframe["ema_fast"] > dataframe["ema_slow"]) |
                (dataframe["rsi"] > 58)
            ),
            ["exit_short", "exit_tag"]
        ] = (1, "exit_short_signal")

        return dataframe
