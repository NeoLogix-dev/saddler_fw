import json
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
STORAGE_DIR = BASE_DIR / "storage"
SETTINGS_FILE = STORAGE_DIR / "system_settings.json"

DEFAULT_SETTINGS = {
    "profile": "balanced",
    "mode": {
        "live": False,
        "auto_trade": True
    },
    "filters": {
        "min_ai_score": 68,
        "confidence_min": 65,
        "cooldown_minutes": 5,
        "btc_trend_required": False,
        "multi_tf_required": False
    },
    "risk": {
        "risk_per_trade": 2,
        "max_open_trades": 5
    }
}

def load_settings():
    if not SETTINGS_FILE.exists():
        SETTINGS_FILE.write_text(
            json.dumps(DEFAULT_SETTINGS, indent=4),
            encoding="utf-8"
        )
        return DEFAULT_SETTINGS

    try:
        data = json.loads(
            SETTINGS_FILE.read_text(encoding="utf-8")
        )
        return data
    except Exception:
        return DEFAULT_SETTINGS

def save_settings(data):
    SETTINGS_FILE.write_text(
        json.dumps(data, indent=4),
        encoding="utf-8"
    )

def apply_profile(profile_name):
    data = load_settings()

    profiles = data.get("profiles", {})
    profile = profiles.get(profile_name)

    if not profile:
        return data

    data["profile"] = profile_name

    if "min_ai_score" in profile:
        data["filters"]["min_ai_score"] = profile["min_ai_score"]

    if "cooldown_minutes" in profile:
        data["filters"]["cooldown_minutes"] = profile["cooldown_minutes"]

    if "max_open_trades" in profile:
        data["risk"]["max_open_trades"] = profile["max_open_trades"]

    save_settings(data)
    return data
