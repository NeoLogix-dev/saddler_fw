from config import RISK_MIN_SCORE

def evaluate_risk(score, trend, funding, orderflow, onchain):
    risk_score = round((score * 0.50) + (orderflow * 0.25) + (onchain * 0.15) + (funding * 0.10), 2)

    if orderflow < 35:
        return {"allowed": False, "risk_score": risk_score, "reason": "ORDERFLOW_WEAK"}
    if funding < 35:
        return {"allowed": False, "risk_score": risk_score, "reason": "FUNDING_RISK"}
    if risk_score < RISK_MIN_SCORE:
        return {"allowed": False, "risk_score": risk_score, "reason": "RISK_SCORE_LOW"}

    return {"allowed": True, "risk_score": risk_score, "reason": "OK"}
