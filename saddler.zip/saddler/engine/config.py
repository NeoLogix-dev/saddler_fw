from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

PAIRS = ["BTC/USDT", "ETH/USDT", "SOL/USDT", "XRP/USDT", "BNB/USDT"]

SCAN_INTERVAL_SECONDS = 5
MIN_SCORE_ENTER = 72
MAX_OPEN_TRADES = 3
RISK_MIN_SCORE = 58

STORAGE_FILE = BASE_DIR / "storage" / "signals.json"
LOG_FILE = BASE_DIR / "logs" / "engine.log"