Rotation Scalp Patch

Dodato:
- SHORT bias u RANGING marketu
- LONG filter u ranging marketu
- profit pair re-entry priority
- smanjen anti-overtrade
- scalp rotation agresivniji

Restart:
python main.py
ili supervisor restart
