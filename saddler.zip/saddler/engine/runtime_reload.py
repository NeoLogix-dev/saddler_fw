
import os
import time
import json
from pathlib import Path

SETTINGS_FILE = (
    Path(__file__).resolve().parent /
    "storage" /
    "system_settings.json"
)

_last_mtime = 0
_cached = {}

def get_runtime_settings():

    global _last_mtime
    global _cached

    if not SETTINGS_FILE.exists():
        return {}

    mtime = os.path.getmtime(SETTINGS_FILE)

    if mtime != _last_mtime:

        with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
            _cached = json.load(f)

        _last_mtime = mtime

    return _cached
