import time
from position.position_manager import evaluate_positions, append_log, get_config

if __name__ == "__main__":
    append_log("Position manager daemon started")
    while True:
        try:
            cfg = get_config()
            evaluate_positions()
            time.sleep(float(cfg.get("loop_seconds", 3)))
        except Exception as e:
            append_log(f"ERROR {e}")
            time.sleep(3)
