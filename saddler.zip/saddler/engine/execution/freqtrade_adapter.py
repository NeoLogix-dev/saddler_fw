"""
Freqtrade adapter starter.
Dashboard reads Freqtrade REST API directly through web/api/freqtrade.php.
Later this adapter can be used by NewTrade engine to send validated commands.
"""
import requests

class FreqtradeAdapter:
    def __init__(self, base_url="http://127.0.0.1:8080/api/v1", username="newtrade", password="newtrade123"):
        self.base_url = base_url
        self.username = username
        self.password = password
        self.token = None

    def ping(self):
        return requests.get(f"{self.base_url}/ping", timeout=3).json()

    def login(self):
        r = requests.post(f"{self.base_url}/token/login", auth=(self.username, self.password), timeout=3)
        r.raise_for_status()
        self.token = r.json()["access_token"]
        return self.token
