from settings_manager import load_settings
import json
from datetime import datetime, timezone, timedelta
from pathlib import Path

from config import STORAGE_FILE, LOG_FILE, MAX_OPEN_TRADES

BASE_DIR = Path(__file__).resolve().parents[1]
STORAGE_DIR = BASE_DIR / "storage"

TRADE_QUEUE_FILE = STORAGE_DIR / "trade_queue.json"
COOLDOWNS_FILE = STORAGE_DIR / "cooldowns.json"
EXECUTION_STATE_FILE = STORAGE_DIR / "execution_state.json"
EMERGENCY_EVENTS_FILE = STORAGE_DIR / "emergency_events.json"
SETTINGS_FILE = STORAGE_DIR / "settings.json"
EXECUTION_CONFIG_FILE = STORAGE_DIR / "execution_config.json"
EXECUTION_HISTORY_FILE = STORAGE_DIR / "execution_history.json"

SETTINGS_RUNTIME = load_settings()

DEFAULT_CONFIG = {
    "entry_score_min": 72,
    "confidence_min": 70,
    "orderflow_min": 60,
    "risk_min": 58,
    "consensus_min": 65,
    "execution_score_min": 70,
    "signal_ttl_minutes": 5,
    "cooldown_minutes": 15,
    "max_ready_per_cycle": 3,
    "anti_overtrade_minutes": 10,
    "max_open_trades": MAX_OPEN_TRADES,

    # IMPORTANT:
    # Anti-overtrade should only block after a REAL execution event.
    # In v2.0 it was blocking READY signals too early.
    "anti_overtrade_enabled": True,
    "history_blocks_only_executed": True
}


def now():
    return datetime.now(timezone.utc)


def now_iso():
    return now().isoformat()


def parse_time(value):
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except Exception:
        return None


def read_json(path, default):
    path = Path(path)
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    data["updated_at"] = now_iso()
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def append_log(message):
    Path(LOG_FILE).parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"[{now_iso()}] EXECUTION {message}\n")


def normalize_pair(pair):
    return str(pair or "").replace(":USDT", "")


def default_queue():
    return {"queue": [], "updated_at": None}


def default_cooldowns():
    return {"pairs": {}, "updated_at": None}


def default_state():
    return {
        "engine_status": "IDLE",
        "market_state": "UNKNOWN",
        "last_decision": None,
        "auto_enabled": False,
        "live_enabled": False,
        "ready_count": 0,
        "blocked_count": 0,
        "cooldown_count": 0,
        "wait_count": 0,
        "queue_count": 0,
        "top_priority": None,
        "updated_at": None
    }


def default_emergency():
    return {"events": [], "updated_at": None}


def default_history():
    return {"items": [], "updated_at": None}


def get_config():
    cfg = read_json(EXECUTION_CONFIG_FILE, DEFAULT_CONFIG.copy())
    merged = DEFAULT_CONFIG.copy()
    merged.update(cfg)
    return merged


def is_on_cooldown(pair, cooldowns):
    pair = normalize_pair(pair)
    data = cooldowns.get("pairs", {}).get(pair)
    if not data:
        return False, None

    until = parse_time(data.get("cooldown_until", ""))
    if not until:
        return False, None

    if until > now():
        return True, data

    return False, None


def detect_market_state(signal):
    score = float(signal.get("score", 0) or 0)
    orderflow = float(signal.get("orderflow", 0) or 0)
    funding = float(signal.get("funding", 0) or 0)
    confidence = float(signal.get("confidence", 0) or 0)

    if orderflow < 35 or confidence < 45:
        return "LOW_QUALITY"
    if funding < 35:
        return "FUNDING_RISK"
    if score >= 80 and orderflow >= 70:
        return "TRENDING"
    if score < 60:
        return "RANGING"
    return "NORMAL"


def consensus_score(signal):
    trend = float(signal.get("trend", 0) or 0)
    funding = float(signal.get("funding", 0) or 0)
    orderflow = float(signal.get("orderflow", 0) or 0)
    onchain = float(signal.get("onchain", 0) or 0)
    confidence = float(signal.get("confidence", 0) or 0)

    return round((trend * 0.24) + (funding * 0.17) + (orderflow * 0.29) + (onchain * 0.18) + (confidence * 0.12), 2)


def execution_score(signal, consensus):
    score = float(signal.get("score", 0) or 0)
    risk = float(signal.get("risk", 0) or 0)
    orderflow = float(signal.get("orderflow", 0) or 0)
    confidence = float(signal.get("confidence", 0) or 0)

    return round((score * 0.30) + (risk * 0.25) + (orderflow * 0.25) + (confidence * 0.10) + (consensus * 0.10), 2)


def priority_score(signal, exec_score, consensus, market_state):
    score = float(signal.get("score", 0) or 0)
    risk = float(signal.get("risk", 0) or 0)

    bonus = 0
    if market_state == "TRENDING":
        bonus += 7
    if market_state in ["FUNDING_RISK", "LOW_QUALITY"]:
        bonus -= 15

    return round((exec_score * 0.45) + (consensus * 0.25) + (score * 0.15) + (risk * 0.15) + bonus, 2)


def anti_overtrade_block(pair, history, cfg):
    if not bool(cfg.get("anti_overtrade_enabled", True)):
        return False

    cutoff = now() - timedelta(minutes=int(cfg["anti_overtrade_minutes"]))
    pair = normalize_pair(pair)

    recent = []
    for item in history.get("items", []):
        if normalize_pair(item.get("pair")) != pair:
            continue

        item_time = parse_time(item.get("time", ""))
        if not item_time or item_time <= cutoff:
            continue

        # Only REAL execution events should block.
        # READY / READY_MANUAL are only candidates, not executions.
        if bool(cfg.get("history_blocks_only_executed", True)):
            if item.get("event") not in ["EXECUTED", "ORDER_SENT", "OPENED"]:
                continue

        recent.append(item)

    return len(recent) > 0


def evaluate_signal(signal, cooldowns, settings, history, cfg):
    pair = normalize_pair(signal.get("pair"))
    side = signal.get("side", "WAIT")
    action = signal.get("action", "WAIT")
    score = float(signal.get("score", 0) or 0)
    confidence = float(signal.get("confidence", 0) or 0)
    orderflow = float(signal.get("orderflow", 0) or 0)
    risk = float(signal.get("risk", 0) or 0)
    allowed = bool(signal.get("allowed", False))
    market_state = detect_market_state(signal)

    consensus = consensus_score(signal)
    exec_score = execution_score(signal, consensus)
    priority = priority_score(signal, exec_score, consensus, market_state)

    base = {
        "pair": pair,
        "side": side,
        "market_state": market_state,
        "consensus": consensus,
        "execution_score": exec_score,
        "priority": priority
    }

    cooldown, cooldown_data = is_on_cooldown(pair, cooldowns)
    if cooldown:
        return {**base, "status": "COOLDOWN", "reason": cooldown_data.get("reason", "COOLDOWN_ACTIVE")}

    if anti_overtrade_block(pair, history, cfg):
        return {**base, "status": "BLOCKED", "reason": "ANTI_OVERTRADE"}

    if action != "ENTER":
        return {**base, "status": "WAIT_CONFIRMATION", "reason": "ACTION_NOT_ENTER"}

    if side not in ["LONG", "SHORT"]:
        return {**base, "status": "WAIT_CONFIRMATION", "reason": "SIDE_NOT_VALID"}

    if not allowed:
        return {**base, "status": "BLOCKED", "reason": signal.get("reason", "RISK_NOT_ALLOWED")}

    if score < float(cfg["entry_score_min"]):
        return {**base, "status": "WAIT_CONFIRMATION", "reason": "SCORE_LOW"}

    if confidence < float(cfg["confidence_min"]):
        return {**base, "status": "WAIT_CONFIRMATION", "reason": "CONFIDENCE_LOW"}

    if orderflow < float(cfg["orderflow_min"]):
        return {**base, "status": "WAIT_CONFIRMATION", "reason": "ORDERFLOW_CONFIRMATION_NEEDED"}

    if risk < float(cfg["risk_min"]):
        return {**base, "status": "BLOCKED", "reason": "RISK_SCORE_LOW"}

    if consensus < float(cfg["consensus_min"]):
        return {**base, "status": "WAIT_CONFIRMATION", "reason": "CONSENSUS_LOW"}

    if exec_score < float(cfg["execution_score_min"]):
        return {**base, "status": "WAIT_CONFIRMATION", "reason": "EXECUTION_SCORE_LOW"}

    if not settings.get("auto", False):
        return {**base, "status": "READY_MANUAL", "reason": "AUTO_OFF"}

    return {**base, "status": "READY", "reason": "EXECUTION_ALLOWED"}


def upsert_queue_item(queue, signal, decision, cfg):
    pair = normalize_pair(signal.get("pair"))
    existing = None

    for item in queue["queue"]:
        if normalize_pair(item.get("pair")) == pair:
            existing = item
            break

    expires_at = now() + timedelta(minutes=int(cfg["signal_ttl_minutes"]))

    payload = {
        "pair": pair,
        "side": signal.get("side", "WAIT"),
        "action": signal.get("action", "WAIT"),
        "score": signal.get("score"),
        "confidence": signal.get("confidence"),
        "risk": signal.get("risk"),
        "orderflow": signal.get("orderflow"),
        "consensus": decision["consensus"],
        "execution_score": decision["execution_score"],
        "priority": decision["priority"],
        "status": decision["status"],
        "reason": decision["reason"],
        "market_state": decision["market_state"],
        "created_at": existing.get("created_at") if existing else now_iso(),
        "updated_at": now_iso(),
        "expires_at": expires_at.isoformat()
    }

    if existing:
        existing.update(payload)
    else:
        queue["queue"].append(payload)


def cleanup_queue(queue):
    cleaned = []
    current = now()

    for item in queue.get("queue", []):
        exp = parse_time(item.get("expires_at", ""))
        if exp and exp < current and item.get("status") not in ["OPEN", "EXECUTING"]:
            item["status"] = "CANCELLED"
            item["reason"] = "SIGNAL_EXPIRED"
        cleaned.append(item)

    cleaned.sort(key=lambda x: float(x.get("priority", 0) or 0), reverse=True)
    queue["queue"] = cleaned[-100:]


def run_cycle():
    STORAGE_DIR.mkdir(parents=True, exist_ok=True)

    cfg = get_config()
    signals_payload = read_json(STORAGE_FILE, {"signals": []})
    settings = read_json(SETTINGS_FILE, {"live": False, "auto": False})
    queue = read_json(TRADE_QUEUE_FILE, default_queue())
    cooldowns = read_json(COOLDOWNS_FILE, default_cooldowns())
    state = read_json(EXECUTION_STATE_FILE, default_state())
    emergency = read_json(EMERGENCY_EVENTS_FILE, default_emergency())
    history = read_json(EXECUTION_HISTORY_FILE, default_history())

    signals = signals_payload.get("signals", [])
    if not signals:
        state.update({
            "engine_status": "NO_SIGNALS",
            "last_decision": "No AI signals available",
            "auto_enabled": bool(settings.get("auto", False)),
            "live_enabled": bool(settings.get("live", False))
        })
        write_json(EXECUTION_STATE_FILE, state)
        return state

    ready = blocked = cooldown_count = wait = 0
    last_market_state = "UNKNOWN"

    for signal in signals:
        decision = evaluate_signal(signal, cooldowns, settings, history, cfg)
        upsert_queue_item(queue, signal, decision, cfg)

        if decision["status"] in ["READY", "READY_MANUAL"]:
            ready += 1
        elif decision["status"] == "BLOCKED":
            blocked += 1
        elif decision["status"] == "COOLDOWN":
            cooldown_count += 1
        elif decision["status"] == "WAIT_CONFIRMATION":
            wait += 1

        last_market_state = decision["market_state"]

        if decision["market_state"] in ["FUNDING_RISK", "LOW_QUALITY"] and signal.get("action") == "ENTER":
            emergency.setdefault("events", []).append({
                "time": now_iso(),
                "pair": normalize_pair(signal.get("pair")),
                "type": "ENTRY_PROTECTION",
                "reason": decision["market_state"],
                "action": "BLOCK_OR_WAIT"
            })
            emergency["events"] = emergency["events"][-100:]

    cleanup_queue(queue)

    ready_items = [x for x in queue.get("queue", []) if x.get("status") in ["READY", "READY_MANUAL"]]
    top_priority = ready_items[0] if ready_items else (queue["queue"][0] if queue.get("queue") else None)

    # FIX:
    # Do NOT add READY/READY_MANUAL to history here.
    # History is reserved for real execution events later.
    # This prevents false ANTI_OVERTRADE blocks.

    state.update({
        "engine_status": "ACTIVE",
        "market_state": last_market_state,
        "last_decision": top_priority,
        "auto_enabled": bool(settings.get("auto", False)),
        "live_enabled": bool(settings.get("live", False)),
        "ready_count": ready,
        "blocked_count": blocked,
        "cooldown_count": cooldown_count,
        "wait_count": wait,
        "queue_count": len(queue.get("queue", [])),
        "top_priority": top_priority,
        "config": cfg
    })

    write_json(TRADE_QUEUE_FILE, queue)
    write_json(COOLDOWNS_FILE, cooldowns)
    write_json(EXECUTION_STATE_FILE, state)
    write_json(EMERGENCY_EVENTS_FILE, emergency)
    write_json(EXECUTION_HISTORY_FILE, history)

    append_log(f"fix cycle ready={ready} blocked={blocked} wait={wait} cooldown={cooldown_count} queue={len(queue.get('queue', []))}")
    return state


if __name__ == "__main__":
    run_cycle()
