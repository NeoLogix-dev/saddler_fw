import json
import time
import random
from datetime import datetime, timezone, timedelta
from pathlib import Path

from execution.freqtrade_client import load_client_from_project

BASE_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = BASE_DIR.parent
STORAGE_DIR = BASE_DIR / "storage"

QUEUE_FILE = STORAGE_DIR / "trade_queue.json"
SETTINGS_FILE = STORAGE_DIR / "settings.json"
ADAPTER_CONFIG_FILE = STORAGE_DIR / "adapter_config.json"
ADAPTER_STATE_FILE = STORAGE_DIR / "adapter_state.json"
EXECUTION_HISTORY_FILE = STORAGE_DIR / "execution_history.json"
COOLDOWNS_FILE = STORAGE_DIR / "cooldowns.json"
BALANCE_MANAGER_FILE = STORAGE_DIR / "balance_manager.json"
LOG_FILE = BASE_DIR / "logs" / "engine.log"


DEFAULT_ADAPTER_CONFIG = {
    "execution_enabled": False,
    "force_entry_enabled": True,
    "force_exit_enabled": True,
    "live_execution_enabled": False,
    "paper_execution_enabled": True,
    "market_type": "futures",
    "futures_suffix": ":USDT",
    "max_entries_per_cycle": 1,
    "entry_status_required": "READY",

    # Balance Manager guard.
    "respect_trading_balance": True,
    "use_balance_manager_stake": True,
    "balance_limit_backoff_seconds": 60,

    # FIX: local guard before calling Freqtrade forceenter.
    "respect_max_open_trades": True,
    "max_open_trades": 3,
    "max_trades_backoff_seconds": 45,

    # FIX: do not keep retrying the same pair every cycle after API rejects.
    "entry_error_backoff_seconds": 30,

    "exit_on_blocked_pair": True,
    "exit_on_low_quality_market": False,
    "exit_on_funding_risk": False,
    "exit_profit_below": -0.025,
    "exit_profit_guard_enabled": False,
    "loop_seconds": 2,

    # Realistic paper simulation
    "simulate_realistic_execution": True,
    "paper_slippage_min_pct": 0.04,
    "paper_slippage_max_pct": 0.18,
    "paper_fee_pct": 0.10,
    "paper_entry_delay_ms_min": 150,
    "paper_entry_delay_ms_max": 1200,
    "paper_partial_fill_chance": 0.08,
    "paper_reject_chance": 0.03,
    "paper_volatility_multiplier": 1.0
}


def now():
    return datetime.now(timezone.utc)


def now_iso():
    return now().isoformat()


def parse_time(value):
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except Exception:
        return None


def read_json(path, default):
    path = Path(path)
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    data["updated_at"] = now_iso()
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def append_log(msg):
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"[{now_iso()}] ADAPTER {msg}\n")


def realistic_delay(cfg):
    if not cfg.get("simulate_realistic_execution", True):
        return

    delay_min = int(cfg.get("paper_entry_delay_ms_min", 150))
    delay_max = int(cfg.get("paper_entry_delay_ms_max", 1200))

    delay = random.randint(delay_min, delay_max) / 1000
    time.sleep(delay)


def realistic_execution_result(cfg, item):
    if not cfg.get("simulate_realistic_execution", True):
        return True, {"mode": "classic"}

    reject_chance = float(cfg.get("paper_reject_chance", 0.03))
    partial_chance = float(cfg.get("paper_partial_fill_chance", 0.08))

    slip_min = float(cfg.get("paper_slippage_min_pct", 0.04))
    slip_max = float(cfg.get("paper_slippage_max_pct", 0.18))

    fee_pct = float(cfg.get("paper_fee_pct", 0.10))

    volatility = max(
        1.0,
        float(item.get("volatility", 1.0) or 1.0)
    )

    slippage = round(
        random.uniform(slip_min, slip_max) * volatility,
        4
    )

    if random.random() < reject_chance:
        return False, {
            "reason": "SIMULATED_REJECT",
            "slippage_pct": slippage,
            "fee_pct": fee_pct
        }

    partial_fill = random.random() < partial_chance

    return True, {
        "slippage_pct": slippage,
        "fee_pct": fee_pct,
        "partial_fill": partial_fill
    }



def get_config():
    cfg = read_json(ADAPTER_CONFIG_FILE, DEFAULT_ADAPTER_CONFIG.copy())
    merged = DEFAULT_ADAPTER_CONFIG.copy()
    merged.update(cfg)
    return merged


def pair_for_freqtrade(pair, cfg):
    pair = str(pair or "")
    if cfg.get("market_type") == "futures":
        suffix = cfg.get("futures_suffix", ":USDT")
        if pair.endswith(suffix):
            return pair
        if "/" in pair and pair.endswith("/USDT"):
            return pair + suffix
    return pair


def normalize_pair(pair):
    return str(pair or "").replace(":USDT", "")


def open_trades_by_pair(open_trades):
    out = {}
    for t in open_trades or []:
        pair = normalize_pair(t.get("pair"))
        out[pair] = t
    return out


def side_to_freqtrade(side):
    side = str(side or "").upper()
    if side == "SHORT":
        return "short"
    return "long"


def record_history(event, item, response=None):
    history = read_json(EXECUTION_HISTORY_FILE, {"items": []})
    history.setdefault("items", []).append({
        "time": now_iso(),
        "event": event,
        "pair": item.get("pair"),
        "side": item.get("side"),
        "status": item.get("status"),
        "reason": item.get("reason"),
        "execution_score": item.get("execution_score"),
        "priority": item.get("priority"),
        "response": response,
        "simulation": locals().get("sim_data")
    })
    history["items"] = history["items"][-300:]
    write_json(EXECUTION_HISTORY_FILE, history)


def update_queue_item(pair, updates):
    queue = read_json(QUEUE_FILE, {"queue": []})
    pair_norm = normalize_pair(pair)

    for item in queue.get("queue", []):
        if normalize_pair(item.get("pair")) == pair_norm:
            item.update(updates)
            item["updated_at"] = now_iso()

    write_json(QUEUE_FILE, queue)


def state_template():
    return {
        "adapter_status": "IDLE",
        "freqtrade_online": False,
        "execution_enabled": False,
        "last_entry": None,
        "last_exit": None,
        "last_error": None,
        "open_trades_count": 0,
        "max_open_trades": None,
        "updated_at": None
    }


def mark_adapter(status, **kwargs):
    state = read_json(ADAPTER_STATE_FILE, state_template())
    state["adapter_status"] = status
    for k, v in kwargs.items():
        state[k] = v
    write_json(ADAPTER_STATE_FILE, state)
    return state


def should_execute(settings, cfg):
    if not cfg.get("execution_enabled", False):
        return False, "ADAPTER_DISABLED"

    if not settings.get("auto", False):
        return False, "AUTO_OFF"

    if settings.get("live", False) and not cfg.get("live_execution_enabled", False):
        return False, "LIVE_GUARD"

    if not settings.get("live", False) and not cfg.get("paper_execution_enabled", True):
        return False, "PAPER_DISABLED"

    return True, "OK"


def get_max_open_trades(cfg):
    # Prefer explicit adapter config, fallback to Freqtrade config if present.
    max_open = cfg.get("max_open_trades", 3)

    ft_cfg_file = PROJECT_ROOT / "freqtrade" / "user_data" / "config.json"
    if ft_cfg_file.exists():
        try:
            ft_cfg = json.loads(ft_cfg_file.read_text(encoding="utf-8"))
            max_open = int(ft_cfg.get("max_open_trades", max_open))
        except Exception:
            pass

    try:
        return int(max_open)
    except Exception:
        return 3


def backoff_until(seconds):
    return (now() + timedelta(seconds=int(seconds))).isoformat()


def item_in_backoff(item):
    until = parse_time(item.get("adapter_backoff_until", ""))
    return until is not None and until > now()


def is_max_trade_error(resp):
    raw = json.dumps(resp, ensure_ascii=False).lower()
    return "maximum number of trades" in raw or "max open trades" in raw or "max_open_trades" in raw



def get_trade_stake(trade):
    """Read stake amount from Freqtrade status trade payload."""
    for key in ("stake_amount", "stake", "amount_stake"):
        value = trade.get(key)
        if value is not None:
            try:
                return float(value)
            except Exception:
                pass
    return 0.0


def get_balance_manager_state(open_trades, max_open):
    """Return Balance Manager capital limits based on engine/storage/balance_manager.json."""
    cfg = read_json(BALANCE_MANAGER_FILE, {
        "total_balance": 1000.0,
        "trading_allocation_pct": 70.0,
        "static_allocation_pct": 30.0,
        "locked_profit": 0.0
    })

    total_balance = float(cfg.get("total_balance", 1000.0) or 1000.0)

    # Support both key names because earlier code/examples used both.
    trading_pct = cfg.get("trading_allocation_pct", cfg.get("trading_allocation_percent", 70.0))
    trading_pct = float(trading_pct or 70.0)

    trading_pct = max(1.0, min(100.0, trading_pct))
    trading_balance = round(total_balance * (trading_pct / 100.0), 8)

    current_exposure = 0.0
    for trade in open_trades or []:
        current_exposure += get_trade_stake(trade)

    available_balance = round(trading_balance - current_exposure, 8)

    try:
        max_open_int = max(1, int(max_open or 1))
    except Exception:
        max_open_int = 1

    max_stake_per_trade = round(trading_balance / max_open_int, 8)

    return {
        "config": cfg,
        "total_balance": total_balance,
        "trading_pct": trading_pct,
        "trading_balance": trading_balance,
        "current_exposure": round(current_exposure, 8),
        "available_balance": available_balance,
        "max_stake_per_trade": max_stake_per_trade
    }


def balance_backoff_item(item, reason, cfg, bm):
    updates = {
        "status": "WAIT_CONFIRMATION",
        "reason": reason,
        "adapter_backoff_until": backoff_until(cfg.get("balance_limit_backoff_seconds", 60)),
        "balance_manager": {
            "trading_balance": bm.get("trading_balance"),
            "current_exposure": bm.get("current_exposure"),
            "available_balance": bm.get("available_balance"),
            "max_stake_per_trade": bm.get("max_stake_per_trade")
        }
    }
    update_queue_item(item.get("pair"), updates)


def run_once():
    cfg = get_config()
    settings = read_json(SETTINGS_FILE, {"live": False, "auto": False})
    queue = read_json(QUEUE_FILE, {"queue": []})

    client = load_client_from_project(PROJECT_ROOT)

    ping_ok, ping_data = client.ping()
    if not ping_ok:
        mark_adapter("FREQTRADE_OFFLINE", freqtrade_online=False, execution_enabled=cfg.get("execution_enabled", False), last_error=ping_data)
        append_log(f"freqtrade offline {ping_data}")
        return

    auth_ok, auth_data = client.ensure_auth()
    if not auth_ok:
        mark_adapter("AUTH_ERROR", freqtrade_online=True, execution_enabled=cfg.get("execution_enabled", False), last_error=auth_data)
        append_log(f"auth error {auth_data}")
        return

    status_ok, status_data = client.status()
    open_trades = status_data if status_ok and isinstance(status_data, list) else []
    open_by_pair = open_trades_by_pair(open_trades)
    max_open = get_max_open_trades(cfg)
    balance_manager = get_balance_manager_state(open_trades, max_open)

    can_execute, reason = should_execute(settings, cfg)

    if not can_execute:
        mark_adapter(
            reason,
            freqtrade_online=True,
            execution_enabled=cfg.get("execution_enabled", False),
            open_trades_count=len(open_trades),
            max_open_trades=max_open,
            trading_balance=balance_manager.get("trading_balance"),
            current_exposure=balance_manager.get("current_exposure"),
            available_balance=balance_manager.get("available_balance"),
            last_error=None
        )
        return

    # Sync OPEN status for queue items with actual open Freqtrade trades.
    for item in queue.get("queue", []):
        pair_norm = normalize_pair(item.get("pair"))
        if pair_norm in open_by_pair and item.get("status") not in ["OPEN", "EXECUTING"]:
            item["status"] = "OPEN"
            item["reason"] = "TRADE_OPEN"
            item["updated_at"] = now_iso()

    write_json(QUEUE_FILE, queue)

    # FIX: if Freqtrade is already full, do not call forceenter at all.
    if cfg.get("respect_max_open_trades", True) and len(open_trades) >= max_open:
        for item in queue.get("queue", []):
            if item.get("status") == cfg.get("entry_status_required", "READY"):
                item["status"] = "WAIT_CONFIRMATION"
                item["reason"] = "MAX_TRADES_REACHED"
                item["adapter_backoff_until"] = backoff_until(cfg.get("max_trades_backoff_seconds", 45))
                item["updated_at"] = now_iso()
        write_json(QUEUE_FILE, queue)

        mark_adapter(
            "MAX_TRADES_REACHED",
            freqtrade_online=True,
            execution_enabled=True,
            open_trades_count=len(open_trades),
            max_open_trades=max_open,
            last_error=None
        )
        return

    entries_sent = 0
    sorted_queue = sorted(
        queue.get("queue", []),
        key=lambda x: float(x.get("priority", 0) or 0),
        reverse=True
    )

    # ENTRY ADAPTER
    for item in sorted_queue:
        if entries_sent >= int(cfg.get("max_entries_per_cycle", 1)):
            break

        if item.get("status") != cfg.get("entry_status_required", "READY"):
            continue

        if item_in_backoff(item):
            continue

        pair_norm = normalize_pair(item.get("pair"))

        # BALANCE MANAGER LIMIT CHECK
        if cfg.get("respect_trading_balance", True):
            available_balance = float(balance_manager.get("available_balance", 0.0) or 0.0)
            max_stake_per_trade = float(balance_manager.get("max_stake_per_trade", 0.0) or 0.0)

            if available_balance <= 0:
                balance_backoff_item(item, "TRADING_BALANCE_LIMIT", cfg, balance_manager)
                record_history("TRADING_BALANCE_LIMIT", item, balance_manager)
                mark_adapter(
                    "TRADING_BALANCE_LIMIT",
                    freqtrade_online=True,
                    execution_enabled=True,
                    open_trades_count=len(open_trades),
                    max_open_trades=max_open,
                    trading_balance=balance_manager.get("trading_balance"),
                    current_exposure=balance_manager.get("current_exposure"),
                    available_balance=balance_manager.get("available_balance"),
                    last_error=None
                )
                append_log(
                    f"entry blocked pair={item.get('pair')} reason=TRADING_BALANCE_LIMIT "
                    f"trading_balance={balance_manager.get('trading_balance')} "
                    f"exposure={balance_manager.get('current_exposure')} "
                    f"available={balance_manager.get('available_balance')}"
                )
                continue

            if max_stake_per_trade > available_balance:
                balance_backoff_item(item, "INSUFFICIENT_TRADING_BALANCE", cfg, balance_manager)
                record_history("INSUFFICIENT_TRADING_BALANCE", item, balance_manager)
                mark_adapter(
                    "INSUFFICIENT_TRADING_BALANCE",
                    freqtrade_online=True,
                    execution_enabled=True,
                    open_trades_count=len(open_trades),
                    max_open_trades=max_open,
                    trading_balance=balance_manager.get("trading_balance"),
                    current_exposure=balance_manager.get("current_exposure"),
                    available_balance=balance_manager.get("available_balance"),
                    last_error=None
                )
                append_log(
                    f"entry blocked pair={item.get('pair')} reason=INSUFFICIENT_TRADING_BALANCE "
                    f"max_stake={max_stake_per_trade} available={available_balance}"
                )
                continue

        if pair_norm in open_by_pair:
            update_queue_item(item.get("pair"), {"status": "OPEN", "reason": "ALREADY_OPEN"})
            continue

        if not cfg.get("force_entry_enabled", True):
            update_queue_item(item.get("pair"), {"status": "READY", "reason": "FORCE_ENTRY_DISABLED"})
            continue

        ft_pair = pair_for_freqtrade(item.get("pair"), cfg)
        ft_side = side_to_freqtrade(item.get("side"))

        update_queue_item(item.get("pair"), {"status": "EXECUTING", "reason": "ORDER_SENT"})
        stake_amount = None
        if cfg.get("use_balance_manager_stake", True):
            stake_amount = round(
                min(
                    float(balance_manager.get("max_stake_per_trade", 0.0) or 0.0),
                    float(balance_manager.get("available_balance", 0.0) or 0.0)
                ),
                2
            )

        ok, resp = client.force_enter(ft_pair, ft_side, stake_amount=stake_amount)

        if ok:
            entries_sent += 1
            if stake_amount is not None:
                balance_manager["current_exposure"] = round(float(balance_manager.get("current_exposure", 0.0) or 0.0) + float(stake_amount), 8)
                balance_manager["available_balance"] = round(float(balance_manager.get("trading_balance", 0.0) or 0.0) - float(balance_manager.get("current_exposure", 0.0) or 0.0), 8)
            update_queue_item(item.get("pair"), {"status": "ORDER_SENT", "reason": "ORDER_SENT", "stake_amount": stake_amount})
            record_history("ORDER_SENT", item, resp)
            mark_adapter(
                "ENTRY_SENT",
                freqtrade_online=True,
                execution_enabled=True,
                last_entry={"pair": ft_pair, "side": ft_side, "response": resp},
                open_trades_count=len(open_trades),
                max_open_trades=max_open,
                trading_balance=balance_manager.get("trading_balance"),
                current_exposure=balance_manager.get("current_exposure"),
                available_balance=balance_manager.get("available_balance")
            )
            append_log(f"entry sent pair={ft_pair} side={ft_side}")
        else:
            reason = "MAX_TRADES_REACHED" if is_max_trade_error(resp) else "ORDER_ERROR"
            backoff_seconds = cfg.get("max_trades_backoff_seconds", 45) if reason == "MAX_TRADES_REACHED" else cfg.get("entry_error_backoff_seconds", 30)

            update_queue_item(item.get("pair"), {
                "status": "WAIT_CONFIRMATION" if reason == "MAX_TRADES_REACHED" else "READY",
                "reason": reason,
                "adapter_backoff_until": backoff_until(backoff_seconds)
            })
            record_history(reason, item, resp)
            mark_adapter(
                reason,
                freqtrade_online=True,
                execution_enabled=True,
                last_error=resp,
                open_trades_count=len(open_trades),
                max_open_trades=max_open
            )
            append_log(f"entry blocked/error pair={ft_pair} reason={reason} resp={resp}")

    # EXIT ADAPTER
    if cfg.get("force_exit_enabled", True):
        refreshed_ok, refreshed_status = client.status()
        open_trades = refreshed_status if refreshed_ok and isinstance(refreshed_status, list) else open_trades

        queue_now = read_json(QUEUE_FILE, {"queue": []})
        queue_by_pair = {normalize_pair(x.get("pair")): x for x in queue_now.get("queue", [])}

        for trade in open_trades:
            pair_norm = normalize_pair(trade.get("pair"))
            q = queue_by_pair.get(pair_norm)

            should_exit = False
            exit_reason = None

            if q:
                if cfg.get("exit_on_blocked_pair", True) and q.get("status") == "BLOCKED":
                    should_exit = True
                    exit_reason = "EXIT_BLOCKED_PAIR"

                if cfg.get("exit_on_low_quality_market", False) and q.get("market_state") == "LOW_QUALITY":
                    should_exit = True
                    exit_reason = "EXIT_LOW_QUALITY"

                if cfg.get("exit_on_funding_risk", False) and q.get("market_state") == "FUNDING_RISK":
                    should_exit = True
                    exit_reason = "EXIT_FUNDING_RISK"

            if cfg.get("exit_profit_guard_enabled", False):
                profit = trade.get("profit_ratio")
                try:
                    if profit is not None and float(profit) <= float(cfg.get("exit_profit_below", -0.025)):
                        should_exit = True
                        exit_reason = "EXIT_PROFIT_GUARD"
                except Exception:
                    pass

            if should_exit:
                trade_id = trade.get("trade_id") or trade.get("id")
                if trade_id is None:
                    continue

                ok, resp = client.force_exit(trade_id)
                hist_item = q or {"pair": pair_norm, "side": trade.get("side"), "status": "OPEN", "reason": exit_reason}

                if ok:
                    record_history("EXIT_SENT", hist_item, resp)
                    mark_adapter(
                        "EXIT_SENT",
                        freqtrade_online=True,
                        execution_enabled=True,
                        last_exit={"trade_id": trade_id, "pair": pair_norm, "reason": exit_reason, "response": resp},
                        open_trades_count=len(open_trades),
                        max_open_trades=max_open
                    )
                    append_log(f"exit sent pair={pair_norm} trade_id={trade_id} reason={exit_reason}")
                else:
                    record_history("EXIT_ERROR", hist_item, resp)
                    mark_adapter(
                        "EXIT_ERROR",
                        freqtrade_online=True,
                        execution_enabled=True,
                        last_error=resp,
                        open_trades_count=len(open_trades),
                        max_open_trades=max_open
                    )
                    append_log(f"exit error pair={pair_norm} trade_id={trade_id} resp={resp}")

    mark_adapter(
        "ACTIVE",
        freqtrade_online=True,
        execution_enabled=True,
        open_trades_count=len(open_trades),
        max_open_trades=max_open,
        trading_balance=balance_manager.get("trading_balance"),
        current_exposure=balance_manager.get("current_exposure"),
        available_balance=balance_manager.get("available_balance")
    )


def run_loop():
    append_log("Execution adapter daemon started")
    while True:
        try:
            cfg = get_config()
            run_once()
            time.sleep(float(cfg.get("loop_seconds", 2)))
        except Exception as e:
            append_log(f"ERROR {e}")
            mark_adapter("ERROR", last_error=str(e))
            time.sleep(2)


if __name__ == "__main__":
    run_loop()
