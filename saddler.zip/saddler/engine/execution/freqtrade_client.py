import base64
import json
import urllib.error
import urllib.request
from pathlib import Path


class FreqtradeClient:
    def __init__(self, base_url="http://127.0.0.1:8080/api/v1", username=None, password=None, timeout=5):
        self.base_url = base_url.rstrip("/")
        self.username = username
        self.password = password
        self.timeout = timeout
        self.access_token = None

    def _headers(self):
        headers = {"Content-Type": "application/json"}
        if self.access_token:
            headers["Authorization"] = f"Bearer {self.access_token}"
        return headers

    def _request(self, method, endpoint, payload=None, auth_basic=False):
        url = self.base_url + "/" + endpoint.lstrip("/")
        data = None

        if payload is not None:
            data = json.dumps(payload).encode("utf-8")

        headers = self._headers()

        if auth_basic and self.username and self.password:
            token = base64.b64encode(f"{self.username}:{self.password}".encode("utf-8")).decode("ascii")
            headers["Authorization"] = f"Basic {token}"

        req = urllib.request.Request(url, data=data, headers=headers, method=method)

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
                try:
                    return True, json.loads(raw) if raw else {}
                except Exception:
                    return True, {"raw": raw}
        except urllib.error.HTTPError as e:
            raw = e.read().decode("utf-8", errors="replace")
            return False, {"error": f"HTTP {e.code}", "body": raw, "endpoint": endpoint}
        except Exception as e:
            return False, {"error": str(e), "endpoint": endpoint}

    def ping(self):
        return self._request("GET", "ping")

    def login(self):
        ok, data = self._request("POST", "token/login", auth_basic=True)
        if ok and isinstance(data, dict) and data.get("access_token"):
            self.access_token = data["access_token"]
        return ok, data

    def ensure_auth(self):
        if self.access_token:
            return True, {"status": "token_cached"}
        return self.login()

    def status(self):
        self.ensure_auth()
        return self._request("GET", "status")

    def count(self):
        self.ensure_auth()
        return self._request("GET", "count")

    def profit(self):
        self.ensure_auth()
        return self._request("GET", "profit")

    def force_enter(self, pair, side="long", price=None, stake_amount=None):
        self.ensure_auth()

        side = str(side or "long").lower()
        payload = {"pair": pair, "side": side}
        if price is not None:
            payload["price"] = price
        if stake_amount is not None:
            payload["stake_amount"] = float(stake_amount)

        # Modern endpoint.
        ok, data = self._request("POST", "forceenter", payload)
        if ok:
            return ok, data

        # Fallback for older installs.
        fallback_payload = {"pair": pair}
        if price is not None:
            fallback_payload["price"] = price
        if stake_amount is not None:
            fallback_payload["stake_amount"] = float(stake_amount)

        ok2, data2 = self._request("POST", "forcebuy", fallback_payload)
        if ok2:
            return ok2, data2

        return False, {"forceenter": data, "forcebuy": data2}

    def force_exit(self, trade_id):
        self.ensure_auth()

        payload = {"tradeid": trade_id}
        ok, data = self._request("POST", "forceexit", payload)
        if ok:
            return ok, data

        # Fallback for older installs.
        ok2, data2 = self._request("POST", f"forcesell/{trade_id}")
        if ok2:
            return ok2, data2

        ok3, data3 = self._request("POST", "forcesell", {"tradeid": trade_id})
        if ok3:
            return ok3, data3

        return False, {"forceexit": data, "forcesell_path": data2, "forcesell_body": data3}


def load_client_from_project(project_root: Path):
    project_root = Path(project_root)

    cfg_file = project_root / "freqtrade" / "user_data" / "config.json"
    base_url = "http://127.0.0.1:8080/api/v1"
    username = None
    password = None

    if cfg_file.exists():
        try:
            cfg = json.loads(cfg_file.read_text(encoding="utf-8"))
            api = cfg.get("api_server", {})
            host = api.get("listen_ip_address", "127.0.0.1")
            if host == "0.0.0.0":
                host = "127.0.0.1"
            port = api.get("listen_port", 8080)
            username = api.get("username")
            password = api.get("password")
            base_url = f"http://{host}:{port}/api/v1"
        except Exception:
            pass

    return FreqtradeClient(base_url=base_url, username=username, password=password)
