import subprocess
import sys
import time
import json
import signal
from datetime import datetime, timezone
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
STORAGE_DIR = BASE_DIR / "storage"
LOG_DIR = BASE_DIR / "logs"

SUPERVISOR_STATE_FILE = STORAGE_DIR / "supervisor_state.json"
SUPERVISOR_LOG_FILE = LOG_DIR / "supervisor.log"

PYTHON = sys.executable

SERVICES = [
    {
        "name": "AI Signal Engine",
        "key": "signal_engine",
        "cmd": [PYTHON, "main.py"],
        "enabled": True,
        "restart": True
    },
    {
        "name": "Execution Queue",
        "key": "execution_daemon",
        "cmd": [PYTHON, "execution_daemon.py"],
        "enabled": True,
        "restart": True
    },
    {
        "name": "Execution Adapter",
        "key": "execution_adapter",
        "cmd": [PYTHON, "-m", "execution.execution_adapter"],
        "enabled": True,
        "restart": True
    },
    {
        "name": "Position Manager",
        "key": "position_manager",
        "cmd": [PYTHON, "position_daemon.py"],
        "enabled": True,
        "restart": True
    },
    {
        "name": "Position Executor",
        "key": "position_executor",
        "cmd": [PYTHON, "position_executor_daemon.py"],
        "enabled": True,
        "restart": True
    }
]

processes = {}
stopping = False


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def log(msg):
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    line = f"[{now_iso()}] {msg}"
    print(line, flush=True)
    with open(SUPERVISOR_LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def load_overrides():
    cfg_file = STORAGE_DIR / "supervisor_config.json"
    default = {
        "restart_delay_seconds": 3,
        "services": {s["key"]: {"enabled": s["enabled"], "restart": s["restart"]} for s in SERVICES}
    }

    if not cfg_file.exists():
        STORAGE_DIR.mkdir(parents=True, exist_ok=True)
        cfg_file.write_text(json.dumps(default, indent=2), encoding="utf-8")
        return default

    try:
        data = json.loads(cfg_file.read_text(encoding="utf-8"))
        for s in SERVICES:
            data.setdefault("services", {}).setdefault(s["key"], {"enabled": s["enabled"], "restart": s["restart"]})
        data.setdefault("restart_delay_seconds", 3)
        return data
    except Exception:
        return default


def save_state():
    STORAGE_DIR.mkdir(parents=True, exist_ok=True)
    state = {
        "updated_at": now_iso(),
        "supervisor_status": "STOPPING" if stopping else "RUNNING",
        "services": []
    }

    for svc in SERVICES:
        key = svc["key"]
        proc = processes.get(key)
        running = proc is not None and proc.poll() is None

        state["services"].append({
            "key": key,
            "name": svc["name"],
            "pid": proc.pid if proc else None,
            "running": running,
            "returncode": proc.poll() if proc else None,
            "cmd": " ".join(svc["cmd"])
        })

    SUPERVISOR_STATE_FILE.write_text(json.dumps(state, indent=2), encoding="utf-8")


def service_log_file(key):
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    return open(LOG_DIR / f"{key}.log", "a", encoding="utf-8")


def start_service(svc):
    key = svc["key"]

    if key in processes and processes[key].poll() is None:
        return

    log(f"Starting {svc['name']}")

    lf = service_log_file(key)

    proc = subprocess.Popen(
        svc["cmd"],
        cwd=str(BASE_DIR),
        stdout=lf,
        stderr=subprocess.STDOUT,
        creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if sys.platform.startswith("win") else 0
    )

    processes[key] = proc
    log(f"{svc['name']} started PID={proc.pid}")


def stop_service(key):
    proc = processes.get(key)
    if not proc:
        return

    if proc.poll() is not None:
        return

    log(f"Stopping {key} PID={proc.pid}")

    try:
        if sys.platform.startswith("win"):
            proc.send_signal(signal.CTRL_BREAK_EVENT)
            time.sleep(1)
            if proc.poll() is None:
                proc.terminate()
        else:
            proc.terminate()

        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()

    except Exception as e:
        log(f"Error stopping {key}: {e}")


def stop_all():
    global stopping
    stopping = True
    log("Stopping all services...")
    for svc in SERVICES:
        stop_service(svc["key"])
    save_state()
    log("Supervisor stopped.")


def handle_signal(sig, frame):
    stop_all()
    sys.exit(0)


def main():
    global stopping

    signal.signal(signal.SIGINT, handle_signal)
    signal.signal(signal.SIGTERM, handle_signal)

    log("NewTrade Supervisor started")
    log(f"Python: {PYTHON}")

    while not stopping:
        cfg = load_overrides()
        restart_delay = float(cfg.get("restart_delay_seconds", 3))

        for svc in SERVICES:
            key = svc["key"]
            svc_cfg = cfg.get("services", {}).get(key, {})
            enabled = bool(svc_cfg.get("enabled", svc["enabled"]))
            restart = bool(svc_cfg.get("restart", svc["restart"]))

            proc = processes.get(key)

            if not enabled:
                if proc and proc.poll() is None:
                    stop_service(key)
                continue

            if proc is None:
                start_service(svc)
                continue

            rc = proc.poll()

            if rc is not None:
                log(f"{svc['name']} stopped returncode={rc}")

                if restart and not stopping:
                    log(f"Restarting {svc['name']} in {restart_delay}s")
                    time.sleep(restart_delay)
                    start_service(svc)

        save_state()
        time.sleep(2)


if __name__ == "__main__":
    try:
        main()
       
    finally:
        stop_all()
