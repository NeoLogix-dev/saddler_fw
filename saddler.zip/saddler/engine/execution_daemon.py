import time
from config import SCAN_INTERVAL_SECONDS
from execution.execution_engine import run_cycle, append_log

if __name__ == "__main__":
    append_log("Execution daemon v2 started")
    while True:
        try:
            run_cycle()
        except Exception as e:
            append_log(f"ERROR {e}")
        time.sleep(SCAN_INTERVAL_SECONDS)
