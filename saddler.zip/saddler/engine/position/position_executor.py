import json
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path

from execution.freqtrade_client import load_client_from_project

BASE_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = BASE_DIR.parent
STORAGE_DIR = BASE_DIR / "storage"

POSITION_STATE_FILE = STORAGE_DIR / "position_state.json"
POSITION_CONFIG_FILE = STORAGE_DIR / "position_config.json"
POSITION_EXECUTOR_CONFIG_FILE = STORAGE_DIR / "position_executor_config.json"
POSITION_EXECUTOR_STATE_FILE = STORAGE_DIR / "position_executor_state.json"
POSITION_EXECUTOR_EVENTS_FILE = STORAGE_DIR / "position_executor_events.json"
POSITION_EVENTS_FILE = STORAGE_DIR / "position_events.json"
SETTINGS_FILE = STORAGE_DIR / "settings.json"
BALANCE_MANAGER_FILE = STORAGE_DIR / "balance_manager.json"
BALANCE_STATS_FILE = STORAGE_DIR / "balance_stats.json"
COOLDOWNS_FILE = STORAGE_DIR / "cooldowns.json"
LOG_FILE = BASE_DIR / "logs" / "engine.log"

DEFAULT_CONFIG = {
    "executor_enabled": False,

    "paper_execution_enabled": True,
    "live_execution_enabled": False,

    "breakeven_executor_enabled": True,
    "trailing_executor_enabled": True,
    "partial_tp_executor_enabled": False,
    "emergency_exit_executor_enabled": True,
    "exposure_reducer_enabled": False,
    "profit_lock_executor_enabled": True,

    "execute_emergency_exit": True,
    "execute_reduce_or_exit": False,
    "execute_partial_tp": False,

    "tp1_execute_once": True,
    "tp2_execute_once": True,

    "min_seconds_between_actions": 45,
    "max_actions_per_cycle": 1,
    "profit_lock_cooldown_seconds": 300,
    "fee_buffer_pct": 0.12,
    "loop_seconds": 3
}


def now():
    return datetime.now(timezone.utc)


def now_iso():
    return now().isoformat()


def parse_time(value):
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except Exception:
        return None


def read_json(path, default):
    path = Path(path)
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    data["updated_at"] = now_iso()
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def append_log(msg):
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"[{now_iso()}] POS_EXECUTOR {msg}\n")


def normalize_pair(pair):
    return str(pair or "").replace(":USDT", "")


def get_config():
    cfg = read_json(POSITION_EXECUTOR_CONFIG_FILE, DEFAULT_CONFIG.copy())
    merged = DEFAULT_CONFIG.copy()
    merged.update(cfg)
    return merged


def state_default():
    return {
        "executor_status": "IDLE",
        "freqtrade_online": False,
        "executor_enabled": False,
        "last_action": None,
        "last_error": None,
        "actions_sent": 0,
        "updated_at": None
    }


def events_default():
    return {"events": [], "updated_at": None}


def add_event(event_type, pair, action, status, reason, response=None):
    events = read_json(POSITION_EXECUTOR_EVENTS_FILE, events_default())
    events.setdefault("events", []).append({
        "time": now_iso(),
        "type": event_type,
        "pair": normalize_pair(pair),
        "action": action,
        "status": status,
        "reason": reason,
        "response": response
    })
    events["events"] = events["events"][-300:]
    write_json(POSITION_EXECUTOR_EVENTS_FILE, events)


def mark_state(status, **kwargs):
    st = read_json(POSITION_EXECUTOR_STATE_FILE, state_default())
    st["executor_status"] = status
    for k, v in kwargs.items():
        st[k] = v
    write_json(POSITION_EXECUTOR_STATE_FILE, st)
    return st


def can_execute_by_mode(settings, cfg):
    if not cfg.get("executor_enabled", False):
        return False, "EXECUTOR_DISABLED"

    if settings.get("live", False) and not cfg.get("live_execution_enabled", False):
        return False, "LIVE_GUARD"

    if not settings.get("live", False) and not cfg.get("paper_execution_enabled", True):
        return False, "PAPER_DISABLED"

    return True, "OK"


def action_cooldown_ok(pair, action, cfg):
    events = read_json(POSITION_EXECUTOR_EVENTS_FILE, events_default()).get("events", [])
    cutoff = now() - timedelta(seconds=int(cfg.get("min_seconds_between_actions", 45)))
    pair = normalize_pair(pair)

    for e in reversed(events):
        if normalize_pair(e.get("pair")) != pair:
            continue
        if e.get("action") != action:
            continue
        t = parse_time(e.get("time"))
        if t and t > cutoff and e.get("status") in ["SENT", "OK"]:
            return False
    return True


def already_executed_once(pair, action):
    events = read_json(POSITION_EXECUTOR_EVENTS_FILE, events_default()).get("events", [])
    pair = normalize_pair(pair)

    for e in events:
        if normalize_pair(e.get("pair")) == pair and e.get("action") == action and e.get("status") in ["SENT", "OK"]:
            return True

    return False



def today_key():
    return now().strftime("%Y-%m-%d")


def month_key():
    return now().strftime("%Y-%m")


def update_balance_after_profit_lock(position, reason, response=None, cfg=None):
    """Move realized profit estimate into locked/static balance after force exit is accepted."""
    cfg = cfg or {}
    bm = read_json(BALANCE_MANAGER_FILE, {
        "total_balance": 1000.0,
        "trading_allocation_pct": 70.0,
        "static_allocation_pct": 30.0,
        "locked_profit": 0.0,
        "profit_lock_trigger_pct": 0.4,
        "mode": "profit_only"
    })

    stats = read_json(BALANCE_STATS_FILE, {
        "daily": {},
        "monthly": {},
        "realized_total": 0.0,
        "locked_total": 0.0,
        "events": []
    })

    stake = float(position.get("stake_amount") or position.get("stake") or 0.0)
    pnl_ratio = float(position.get("profit_ratio") or 0.0)

    # Fee buffer is percent of stake, used as conservative estimate.
    fee_buffer_pct = float(cfg.get("fee_buffer_pct", 0.12) or 0.0)
    gross_profit = stake * pnl_ratio
    fee_buffer = stake * (fee_buffer_pct / 100.0)
    net_profit = round(max(0.0, gross_profit - fee_buffer), 8)

    if net_profit <= 0:
        return {"ok": False, "reason": "NO_NET_PROFIT", "gross_profit": gross_profit, "fee_buffer": fee_buffer, "net_profit": net_profit}

    bm["locked_profit"] = round(float(bm.get("locked_profit", 0.0) or 0.0) + net_profit, 8)

    # Static balance displayed by UI is total_balance * static allocation + locked_profit,
    # so we DO NOT increase total_balance here to avoid double-counting.
    bm["last_profit_lock"] = {
        "time": now_iso(),
        "pair": normalize_pair(position.get("pair")),
        "trade_id": get_trade_id(position),
        "stake_amount": stake,
        "profit_ratio": pnl_ratio,
        "profit_pct": round(pnl_ratio * 100.0, 4),
        "gross_profit": round(gross_profit, 8),
        "fee_buffer": round(fee_buffer, 8),
        "net_profit": net_profit,
        "reason": reason,
        "response": response
    }
    write_json(BALANCE_MANAGER_FILE, bm)

    day = today_key()
    month = month_key()
    stats.setdefault("daily", {})
    stats.setdefault("monthly", {})
    stats["daily"][day] = round(float(stats["daily"].get(day, 0.0) or 0.0) + net_profit, 8)
    stats["monthly"][month] = round(float(stats["monthly"].get(month, 0.0) or 0.0) + net_profit, 8)
    stats["realized_total"] = round(float(stats.get("realized_total", 0.0) or 0.0) + net_profit, 8)
    stats["locked_total"] = round(float(stats.get("locked_total", 0.0) or 0.0) + net_profit, 8)
    stats.setdefault("events", []).append(bm["last_profit_lock"])
    stats["events"] = stats["events"][-500:]
    write_json(BALANCE_STATS_FILE, stats)

    return {"ok": True, "net_profit": net_profit, "gross_profit": gross_profit, "fee_buffer": fee_buffer}


def add_pair_cooldown(pair, seconds, reason):
    cooldowns = read_json(COOLDOWNS_FILE, {"items": []})
    until = now() + timedelta(seconds=int(seconds))
    cooldowns.setdefault("items", []).append({
        "time": now_iso(),
        "pair": normalize_pair(pair),
        "until": until.isoformat(),
        "reason": reason
    })
    cooldowns["items"] = cooldowns["items"][-300:]
    write_json(COOLDOWNS_FILE, cooldowns)


def decide_action(position, cfg):
    suggested = str(position.get("suggested_action") or "HOLD").upper()
    lifecycle = str(position.get("lifecycle") or "").upper()
    pnl = float(position.get("profit_ratio") or 0)
    pair = normalize_pair(position.get("pair"))
    tp = position.get("tp_ladder") or {}

    # Profit lock exits are explicit full exits based on Balance Manager trigger.
    if cfg.get("profit_lock_executor_enabled", True):
        if str(position.get("suggested_action") or "").upper() == "PROFIT_LOCK_EXIT" or position.get("profit_lock_hit") is True or lifecycle == "PROFIT_LOCK":
            return "FULL_EXIT", "PROFIT_LOCK"

    # Emergency exits have highest priority.
    if suggested == "EMERGENCY_EXIT" and cfg.get("emergency_exit_executor_enabled", True):
        if cfg.get("execute_emergency_exit", True):
            return "FULL_EXIT", "EMERGENCY_EXIT"

    # Critical state can exit if enabled.
    if lifecycle == "CRITICAL" and cfg.get("execute_emergency_exit", True):
        return "FULL_EXIT", "CRITICAL_DRAWDOWN"

    # Reduce / exit is disabled by default because partial sizing depends on exchange/Freqtrade mode.
    if suggested == "REDUCE_OR_EXIT" and cfg.get("execute_reduce_or_exit", False):
        return "FULL_EXIT", "REDUCE_OR_EXIT"

    # Partial TP decisions. Freqtrade REST forceexit is full exit in most versions,
    # so v2 records partial TP intent by default unless execute_partial_tp is enabled.
    if cfg.get("partial_tp_executor_enabled", False):
        if tp.get("tp1", {}).get("hit") and cfg.get("tp1_execute_once", True) and not already_executed_once(pair, "TP1_INTENT"):
            return "TP_INTENT", "TP1_INTENT"
        if tp.get("tp2", {}).get("hit") and cfg.get("tp2_execute_once", True) and not already_executed_once(pair, "TP2_INTENT"):
            return "TP_INTENT", "TP2_INTENT"

    # Breakeven/trailing are recorded as protection intent in v2.
    if suggested == "MOVE_SL_BREAKEVEN" and cfg.get("breakeven_executor_enabled", True):
        return "PROTECTION_INTENT", "BREAKEVEN_INTENT"

    if suggested in ["TRAILING", "AGGRESSIVE_TRAILING"] and cfg.get("trailing_executor_enabled", True):
        return "PROTECTION_INTENT", suggested + "_INTENT"

    return "NONE", "HOLD"


def get_trade_id(position):
    return position.get("trade_id") or position.get("id")


def run_once():
    cfg = get_config()
    settings = read_json(SETTINGS_FILE, {"live": False, "auto": False})
    position_state = read_json(POSITION_STATE_FILE, {"open_positions": []})

    can_exec, guard_reason = can_execute_by_mode(settings, cfg)

    client = load_client_from_project(PROJECT_ROOT)

    ping_ok, ping_data = client.ping()
    if not ping_ok:
        mark_state("FREQTRADE_OFFLINE", freqtrade_online=False, executor_enabled=cfg.get("executor_enabled", False), last_error=ping_data)
        append_log(f"freqtrade offline {ping_data}")
        return

    auth_ok, auth_data = client.ensure_auth()
    if not auth_ok:
        mark_state("AUTH_ERROR", freqtrade_online=True, executor_enabled=cfg.get("executor_enabled", False), last_error=auth_data)
        append_log(f"auth error {auth_data}")
        return

    if not can_exec:
        mark_state(guard_reason, freqtrade_online=True, executor_enabled=cfg.get("executor_enabled", False), last_error=None)
        return

    positions = position_state.get("open_positions", [])
    actions_sent = 0
    max_actions = int(cfg.get("max_actions_per_cycle", 1))

    for pos in positions:
        if actions_sent >= max_actions:
            break

        pair = normalize_pair(pos.get("pair"))
        action, reason = decide_action(pos, cfg)

        if action == "NONE":
            continue

        if not action_cooldown_ok(pair, reason, cfg):
            continue

        trade_id = get_trade_id(pos)

        if action == "FULL_EXIT":
            if not trade_id:
                add_event("ERROR", pair, action, "ERROR", "MISSING_TRADE_ID", None)
                continue

            ok, resp = client.force_exit(trade_id)
            if ok:
                actions_sent += 1
                lock_result = None
                if reason == "PROFIT_LOCK":
                    lock_result = update_balance_after_profit_lock(pos, reason, resp, cfg)
                    add_pair_cooldown(pair, cfg.get("profit_lock_cooldown_seconds", 300), "PROFIT_LOCK")
                add_event("EXECUTION", pair, "FULL_EXIT", "SENT", reason, {"freqtrade": resp, "balance_lock": lock_result})
                mark_state("EXIT_SENT", freqtrade_online=True, executor_enabled=True, last_action={"pair": pair, "trade_id": trade_id, "action": "FULL_EXIT", "reason": reason, "balance_lock": lock_result}, actions_sent=actions_sent)
                append_log(f"full exit sent pair={pair} trade_id={trade_id} reason={reason} balance_lock={lock_result}")
            else:
                add_event("ERROR", pair, "FULL_EXIT", "ERROR", reason, resp)
                mark_state("EXIT_ERROR", freqtrade_online=True, executor_enabled=True, last_error=resp, actions_sent=actions_sent)
                append_log(f"full exit error pair={pair} trade_id={trade_id} resp={resp}")

        elif action == "TP_INTENT":
            # Intent only by default. Full partial reduction support depends on exact Freqtrade endpoint/mode.
            add_event("INTENT", pair, reason, "OK", reason, {"note": "partial TP intent recorded; no order sent"})
            actions_sent += 1

        elif action == "PROTECTION_INTENT":
            add_event("INTENT", pair, reason, "OK", reason, {"note": "protection intent recorded; no order sent"})
            actions_sent += 1

    mark_state("ACTIVE", freqtrade_online=True, executor_enabled=True, actions_sent=actions_sent)


def run_loop():
    append_log("Position executor daemon started")
    while True:
        try:
            cfg = get_config()
            run_once()
            time.sleep(float(cfg.get("loop_seconds", 3)))
        except Exception as e:
            append_log(f"ERROR {e}")
            mark_state("ERROR", last_error=str(e))
            time.sleep(3)


if __name__ == "__main__":
    run_loop()
