from settings_manager import load_settings
import json
from datetime import datetime, timezone
from pathlib import Path

from execution.freqtrade_client import load_client_from_project

BASE_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = BASE_DIR.parent
STORAGE_DIR = BASE_DIR / "storage"

POSITION_STATE_FILE = STORAGE_DIR / "position_state.json"
POSITION_CONFIG_FILE = STORAGE_DIR / "position_config.json"
POSITION_EVENTS_FILE = STORAGE_DIR / "position_events.json"
SIGNALS_FILE = STORAGE_DIR / "signals.json"
SETTINGS_FILE = STORAGE_DIR / "settings.json"
BALANCE_MANAGER_FILE = STORAGE_DIR / "balance_manager.json"
LOG_FILE = BASE_DIR / "logs" / "engine.log"

RUNTIME_SETTINGS = load_settings()

DEFAULT_CONFIG = {
    "manager_enabled": False,

    "breakeven_enabled": True,
    "breakeven_profit": 0.005,

    "trailing_enabled": True,
    "trailing_start": 0.012,
    "trailing_aggressive_start": 0.02,

    "partial_tp_enabled": True,
    "tp1_profit": 0.01,
    "tp1_close_ratio": 0.25,
    "tp2_profit": 0.02,
    "tp2_close_ratio": 0.25,

    "recovery_enabled": True,
    "medium_drawdown": -0.012,
    "high_drawdown": -0.025,
    "critical_drawdown": -0.04,

    "emergency_exit_enabled": True,
    "exit_on_low_quality": False,
    "exit_on_funding_risk": False,
    "exit_on_critical_drawdown": True,

    "max_long_exposure": 3,
    "max_short_exposure": 3,

    "profit_lock_enabled": True,
    "loop_seconds": 3
}


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def read_json(path, default):
    path = Path(path)
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    data["updated_at"] = now_iso()
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def append_log(message):
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"[{now_iso()}] POSITION {message}\n")


def normalize_pair(pair):
    return str(pair or "").replace(":USDT", "")


def get_config():
    cfg = read_json(POSITION_CONFIG_FILE, DEFAULT_CONFIG.copy())
    merged = DEFAULT_CONFIG.copy()
    merged.update(cfg)
    return merged


def default_state():
    return {
        "manager_status": "IDLE",
        "freqtrade_online": False,
        "open_positions": [],
        "summary": {
            "open_count": 0,
            "long_count": 0,
            "short_count": 0,
            "profit_count": 0,
            "drawdown_count": 0,
            "danger_count": 0
        },
        "updated_at": None
    }


def default_events():
    return {"events": [], "updated_at": None}


def trade_side(trade):
    # Freqtrade returns different fields by version/mode.
    if trade.get("is_short") is True:
        return "SHORT"
    side = str(trade.get("side") or trade.get("trade_direction") or "").upper()
    if side in ["SHORT", "LONG"]:
        return side
    return "SHORT" if str(trade.get("trading_mode", "")).lower().find("short") >= 0 else "LONG"


def profit_ratio(trade):
    for key in ["profit_ratio", "current_profit", "profit_pct"]:
        if key in trade and trade.get(key) is not None:
            try:
                val = float(trade.get(key))
                if key == "profit_pct":
                    return val / 100
                return val
            except Exception:
                pass
    return 0.0



def balance_manager_config():
    return read_json(BALANCE_MANAGER_FILE, {
        "profit_lock_trigger_pct": 0.4,
        "locked_profit": 0,
        "mode": "profit_only"
    })


def profit_lock_trigger_ratio():
    cfg = balance_manager_config()
    try:
        return float(cfg.get("profit_lock_trigger_pct", 0.4)) / 100.0
    except Exception:
        return 0.004


def find_signal(pair, signals):
    pair = normalize_pair(pair)
    for s in signals:
        if normalize_pair(s.get("pair")) == pair:
            return s
    return None


def lifecycle_for_profit(pnl, cfg):
    if cfg.get("profit_lock_enabled", True) and pnl >= profit_lock_trigger_ratio():
        return "PROFIT_LOCK"
    if pnl >= float(cfg["trailing_aggressive_start"]):
        return "AGGRESSIVE_TRAILING"
    if pnl >= float(cfg["trailing_start"]):
        return "TRAILING"
    if pnl >= float(cfg["breakeven_profit"]):
        return "BREAKEVEN"
    if pnl > 0:
        return "PROFIT"
    if pnl <= float(cfg["critical_drawdown"]):
        return "CRITICAL"
    if pnl <= float(cfg["high_drawdown"]):
        return "DANGER"
    if pnl <= float(cfg["medium_drawdown"]):
        return "RECOVERY"
    return "OPEN"


def recovery_action(pnl, signal, cfg):
    market_state = (signal or {}).get("market_state") or (signal or {}).get("reason") or ""
    if pnl <= float(cfg["critical_drawdown"]):
        return "EMERGENCY_EXIT" if cfg.get("exit_on_critical_drawdown", True) else "CRITICAL_HOLD"
    if pnl <= float(cfg["high_drawdown"]):
        return "REDUCE_OR_EXIT"
    if pnl <= float(cfg["medium_drawdown"]):
        return "WATCH_RECOVERY"
    if market_state in ["LOW_QUALITY", "FUNDING_RISK"]:
        return "PROTECTION_WATCH"
    return "HOLD"


def dynamic_sl_label(pnl, cfg):
    if pnl >= float(cfg["trailing_aggressive_start"]):
        return "AGGRESSIVE_TRAIL"
    if pnl >= float(cfg["trailing_start"]):
        return "TRAILING"
    if pnl >= float(cfg["breakeven_profit"]):
        return "BREAKEVEN"
    return "INITIAL"


def tp_ladder(pnl, cfg):
    tp1 = pnl >= float(cfg["tp1_profit"])
    tp2 = pnl >= float(cfg["tp2_profit"])
    return {
        "tp1": {
            "target": cfg["tp1_profit"],
            "close_ratio": cfg["tp1_close_ratio"],
            "hit": tp1
        },
        "tp2": {
            "target": cfg["tp2_profit"],
            "close_ratio": cfg["tp2_close_ratio"],
            "hit": tp2
        }
    }


def add_event(events, pair, event_type, reason, action):
    events.setdefault("events", []).append({
        "time": now_iso(),
        "pair": normalize_pair(pair),
        "type": event_type,
        "reason": reason,
        "action": action
    })
    events["events"] = events["events"][-200:]


def evaluate_positions():
    cfg = get_config()
    signals_payload = read_json(SIGNALS_FILE, {"signals": []})
    signals = signals_payload.get("signals", [])
    events = read_json(POSITION_EVENTS_FILE, default_events())

    client = load_client_from_project(PROJECT_ROOT)
    ping_ok, ping_data = client.ping()

    if not ping_ok:
        state = default_state()
        state["manager_status"] = "FREQTRADE_OFFLINE"
        state["freqtrade_online"] = False
        write_json(POSITION_STATE_FILE, state)
        append_log(f"freqtrade offline {ping_data}")
        return state

    auth_ok, auth_data = client.ensure_auth()
    if not auth_ok:
        state = default_state()
        state["manager_status"] = "AUTH_ERROR"
        state["freqtrade_online"] = True
        state["last_error"] = auth_data
        write_json(POSITION_STATE_FILE, state)
        append_log(f"auth error {auth_data}")
        return state

    ok, open_trades = client.status()
    if not ok or not isinstance(open_trades, list):
        state = default_state()
        state["manager_status"] = "STATUS_ERROR"
        state["freqtrade_online"] = True
        state["last_error"] = open_trades
        write_json(POSITION_STATE_FILE, state)
        append_log(f"status error {open_trades}")
        return state

    positions = []
    long_count = short_count = profit_count = drawdown_count = danger_count = 0

    for trade in open_trades:
        pair = normalize_pair(trade.get("pair"))
        side = trade_side(trade)
        pnl = profit_ratio(trade)
        signal = find_signal(pair, signals)

        lifecycle = lifecycle_for_profit(pnl, cfg)
        sl_state = dynamic_sl_label(pnl, cfg)
        recovery = recovery_action(pnl, signal, cfg)
        tp = tp_ladder(pnl, cfg)

        if side == "LONG":
            long_count += 1
        else:
            short_count += 1

        if pnl > 0:
            profit_count += 1
        if pnl < 0:
            drawdown_count += 1
        if lifecycle in ["DANGER", "CRITICAL"]:
            danger_count += 1

        action = "HOLD"

        if lifecycle == "PROFIT_LOCK" and cfg.get("profit_lock_enabled", True):
            action = "PROFIT_LOCK_EXIT"
            add_event(events, pair, "PROFIT_LOCK", "PROFIT_LOCK_TRIGGER", action)

        if action == "HOLD" and lifecycle == "BREAKEVEN" and cfg.get("breakeven_enabled", True):
            action = "MOVE_SL_BREAKEVEN"
        if action == "HOLD" and lifecycle in ["TRAILING", "AGGRESSIVE_TRAILING"] and cfg.get("trailing_enabled", True):
            action = lifecycle
        if action == "HOLD" and recovery in ["EMERGENCY_EXIT", "REDUCE_OR_EXIT"]:
            action = recovery

        if cfg.get("emergency_exit_enabled", True):
            if cfg.get("exit_on_low_quality", False) and signal and signal.get("market_state") == "LOW_QUALITY":
                action = "EMERGENCY_EXIT"
                add_event(events, pair, "EMERGENCY", "LOW_QUALITY", action)
            if cfg.get("exit_on_funding_risk", False) and signal and signal.get("market_state") == "FUNDING_RISK":
                action = "EMERGENCY_EXIT"
                add_event(events, pair, "EMERGENCY", "FUNDING_RISK", action)
            if recovery == "EMERGENCY_EXIT":
                add_event(events, pair, "EMERGENCY", "CRITICAL_DRAWDOWN", action)

        positions.append({
            "trade_id": trade.get("trade_id") or trade.get("id"),
            "pair": pair,
            "side": side,
            "open_rate": trade.get("open_rate"),
            "current_rate": trade.get("current_rate"),
            "stake_amount": trade.get("stake_amount"),
            "amount": trade.get("amount"),
            "profit_ratio": round(pnl, 6),
            "profit_pct": round(pnl * 100, 3),
            "profit_lock_trigger_pct": round(profit_lock_trigger_ratio() * 100, 4),
            "profit_lock_hit": lifecycle == "PROFIT_LOCK",
            "lifecycle": lifecycle,
            "dynamic_sl": sl_state,
            "tp_ladder": tp,
            "recovery": recovery,
            "suggested_action": action,
            "signal_score": (signal or {}).get("score"),
            "signal_risk": (signal or {}).get("risk"),
            "signal_reason": (signal or {}).get("reason"),
            "open_date": trade.get("open_date") or trade.get("open_date_utc")
        })

    exposure_state = "OK"
    if long_count > int(cfg["max_long_exposure"]) or short_count > int(cfg["max_short_exposure"]):
        exposure_state = "EXPOSURE_LIMIT"

    state = {
        "manager_status": "ACTIVE" if cfg.get("manager_enabled", False) else "DISABLED",
        "freqtrade_online": True,
        "open_positions": positions,
        "summary": {
            "open_count": len(positions),
            "long_count": long_count,
            "short_count": short_count,
            "profit_count": profit_count,
            "drawdown_count": drawdown_count,
            "danger_count": danger_count,
            "exposure_state": exposure_state
        },
        "config": cfg
    }

    write_json(POSITION_STATE_FILE, state)
    write_json(POSITION_EVENTS_FILE, events)
    append_log(f"cycle positions={len(positions)} danger={danger_count} exposure={exposure_state}")
    return state


if __name__ == "__main__":
    evaluate_positions()
