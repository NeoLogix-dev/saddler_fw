import time
import json
import random
from datetime import datetime, timezone

from config import PAIRS, SCAN_INTERVAL_SECONDS, MIN_SCORE_ENTER, STORAGE_FILE, LOG_FILE
from risk.risk_engine import evaluate_risk

STORAGE_FILE.parent.mkdir(parents=True, exist_ok=True)
LOG_FILE.parent.mkdir(parents=True, exist_ok=True)


def score_pair(pair: str):
    trend = round(random.uniform(35, 92), 2)
    funding = round(random.uniform(30, 90), 2)
    orderflow = round(random.uniform(25, 94), 2)
    onchain = round(random.uniform(30, 95), 2)
    price = round(random.uniform(0.4, 105000), 4)

    score = round((trend * 0.30) + (funding * 0.18) + (orderflow * 0.32) + (onchain * 0.20), 2)
    side = "LONG" if trend + orderflow >= 115 else ("SHORT" if trend + orderflow <= 75 else "WAIT")
    confidence = round(min(95, max(35, score + random.uniform(-3, 6))), 2)

    risk = evaluate_risk(score, trend, funding, orderflow, onchain)
    action = "ENTER" if score >= MIN_SCORE_ENTER and risk["allowed"] and side in ["LONG", "SHORT"] else "WAIT"

    return {
        "pair": pair,
        "price": price,
        "side": side,
        "action": action,
        "score": score,
        "confidence": confidence,
        "trend": trend,
        "funding": funding,
        "orderflow": orderflow,
        "onchain": onchain,
        "risk": risk["risk_score"],
        "allowed": risk["allowed"],
        "reason": risk["reason"],
        "trend_bias": side,
        "funding_bias": "NEUTRAL" if funding > 45 else "DANGER",
        "orderflow_bias": side if orderflow > 55 else "WEAK",
        "onchain_bias": "SUPPORTIVE" if onchain > 60 else "NEUTRAL"
    }


def write_log(msg: str):
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"[{datetime.now(timezone.utc).isoformat()}] {msg}\n")


def write_signals(signals):
    payload = {
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "signals": signals
    }

    with open(STORAGE_FILE, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)


def main():
    write_log("NewTrade engine started")

    while True:
        signals = [score_pair(pair) for pair in PAIRS]
        signals.sort(key=lambda x: x["score"], reverse=True)

        write_signals(signals)

        best = signals[0]
        write_log(
            f"cycle complete best={best['pair']} action={best['action']} "
            f"score={best['score']} risk={best['risk']}"
        )

        time.sleep(SCAN_INTERVAL_SECONDS)


if __name__ == "__main__":
    main()