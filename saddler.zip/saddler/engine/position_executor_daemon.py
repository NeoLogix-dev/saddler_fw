from position.position_executor import run_loop

if __name__ == "__main__":
    run_loop()
