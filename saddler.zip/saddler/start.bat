@echo off
title NewTrade AI System

cd /d C:\xampp\htdocs\newtrade_02

echo =====================================
echo Starting Python VENV...
echo =====================================

call .venv\Scripts\activate.bat


timeout /t 2 >nul

echo.
echo =====================================
echo Starting NGROK...
echo =====================================
call ngrok http 80

timeout /t 2 >nul



echo.
echo =====================================
echo Starting Freqtrade...
echo =====================================

start "Freqtrade" cmd /k "cd /d C:\xampp\htdocs\newtrade_02\freqtrade && freqtrade trade --config user_data\config.json"

timeout /t 5 >nul

echo.
echo =====================================
echo Starting Supervisor...
echo =====================================

start "Supervisor" cmd /k "cd /d C:\xampp\htdocs\newtrade_02 && python supervisor.py"


echo =====================================
echo System Started
echo =====================================

pause