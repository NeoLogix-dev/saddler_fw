LunaTrader Unified Refactor

NEW:
- Central settings system
- Unified web/mobile config
- Settings dashboard
- Runtime config reload
- Strategy profiles
- Legacy config migration
- Live/Paper sync
- Diagnostics template

SETTINGS PANEL:
web/settings/index.php

MAIN CONFIG:
engine/storage/system_settings.json
