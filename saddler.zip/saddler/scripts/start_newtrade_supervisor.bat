@echo off
title NewTrade Supervisor
cd /d C:\xampp\htdocs\newtrade_02\engine
call .venv\Scripts\activate.bat
python supervisor.py
pause
