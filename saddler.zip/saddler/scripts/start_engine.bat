@echo off
cd /d C:\xampp\htdocs\newtrade_v02_full\engine
if not exist .venv (
  py -3.12 -m venv .venv
)
call .venv\Scripts\activate
pip install -r requirements.txt
python main.py
pause
