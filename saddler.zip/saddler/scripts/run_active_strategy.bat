@echo off
REM Generated/updated by Orchestrator.
cd /d C:\xampp\htdocs\newtrade_02\freqtrade
call ..\engine\.venv\Scripts\activate.bat
freqtrade trade --config user_data\config.json --strategy NewTradeStrategy
pause
