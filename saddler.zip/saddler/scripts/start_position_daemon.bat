@echo off
cd /d C:\xampp\htdocs\newtrade_02\engine
call .venv\Scripts\activate.bat
python position_daemon.py
pause
