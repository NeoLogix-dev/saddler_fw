@echo off
cd /d C:\xampp\htdocs\newtrade_v02_full\freqtrade
..\engine\.venv\Scripts\freqtrade.exe trade --config user_data\config.json --strategy NewTradeStrategy
pause
