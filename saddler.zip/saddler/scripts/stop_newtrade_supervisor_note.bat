@echo off
echo To stop NewTrade Supervisor, go to its terminal and press CTRL+C.
pause
