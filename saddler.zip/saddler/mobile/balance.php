<?php ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Balance Manager</title>

<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<link rel="stylesheet" href="../web/assets/css/hud.css">
<link rel="stylesheet" href="assets/css/mobile.css">

<script>
window.API_BASE = "../web/api/";
window.ASSETS_BASE = "../web/assets/";
</script>

<script src="assets/js/mobile-api-fix.js"></script>

</head>
<body>

<div class="page mobile-page">

<header class="page-header">
    <a href="index.php" class="back-btn">
        <span class="material-icons">arrow_back</span>
    </a>

    <div class="settings-title">
        <span class="material-icons">account_balance_wallet</span>
        <div>
            <h1>Balance Manager</h1>
            <p>Manage allocations and locked profit</p>
        </div>
    </div>
</header>

<main class="mobile-content">
    <div class="page-title">Balance Manager</div>

    <div class="balance-cards">
        <div class="balance-card">
            <span class="card-label">Total Balance</span>
            <strong id="totalBalance">--</strong>
        </div>
        <div class="balance-card">
            <span class="card-label">Trading Balance</span>
            <strong id="tradingBalance">--</strong>
        </div>
        <div class="balance-card">
            <span class="card-label">Static Balance</span>
            <strong id="staticBalanceSmall">--</strong>
        </div>
        <div class="balance-card">
            <span class="card-label">Locked Profit</span>
            <strong id="lockedProfit">--</strong>
        </div>
    </div>

    <section class="settings-card">
        <div class="section-title">Balance Settings</div>
        <div class="balance-form">
            <label>Total Balance
                <input id="bmTotalBalance" type="number" step="0.01">
            </label>
            <label>Trading Allocation %
                <input id="bmTradingPct" type="number" step="0.1" min="1" max="100">
            </label>
            <label>Static Allocation %
                <input id="bmStaticPct" type="number" readonly>
            </label>
            <label>Profit Lock Trigger %
                <input id="bmProfitLockPct" type="number" step="0.1" min="0" max="100">
            </label>
            <label>Daily Loss Limit %
                <input id="bmDailyLossPct" type="number" step="0.1" min="0" max="100">
            </label>
            <label>Daily Profit Target %
                <input id="bmDailyTargetPct" type="number" step="0.1" min="0" max="100">
            </label>
            <button id="saveBalanceManager" class="save-btn">Save Settings</button>
        </div>
    </section>

    <section class="balance-summary">
        <div class="section-title">Current Summary</div>
        <div class="summary-grid">
            <div>
                <span>Total Balance</span>
                <strong id="totalBalanceText">--</strong>
            </div>
            <div>
                <span>Trading Balance</span>
                <strong id="tradingBalanceText">--</strong>
            </div>
            <div>
                <span>Static Balance</span>
                <strong id="staticBalanceText">--</strong>
            </div>
            <div>
                <span>Locked Profit</span>
                <strong id="lockedProfitText">--</strong>
            </div>
        </div>
    </section>
</main>

<script src="assets/js/mobile-balance.js"></script>

</div>

</body>
</html>
