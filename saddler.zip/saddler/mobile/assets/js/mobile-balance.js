function safeText(value) {
    if (value === null || value === undefined || value === '') return '--';
    return String(value);
}

function formatMoney(value) {
    if (value === null || value === undefined || value === '') return '--';
    const n = Number(value);
    return Number.isFinite(n) ? '$' + n.toFixed(2) : String(value);
}

function formatPct(value) {
    if (value === null || value === undefined || value === '') return '--';
    const n = Number(value);
    return Number.isFinite(n) ? n.toFixed(2) + '%' : String(value);
}

async function getJson(url) {
    const response = await fetch(url + (url.includes('?') ? '&' : '?') + 't=' + Date.now(), { cache: 'no-store' });
    return await response.json();
}

async function postJson(url, data) {
    const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });
    return await response.json();
}

function setText(id, value) {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = value;
}

function updateStaticAllocation() {
    const trading = document.getElementById('bmTradingPct');
    const staticEl = document.getElementById('bmStaticPct');
    if (!trading || !staticEl) return;
    const tradingVal = Number(trading.value || 0);
    const staticVal = Math.max(0, Math.min(100, 100 - tradingVal));
    staticEl.value = staticVal.toFixed(2);
}

function fillBalanceForm(config) {
    if (!config) return;
    if (document.getElementById('bmTotalBalance')) document.getElementById('bmTotalBalance').value = config.total_balance ?? 1000;
    if (document.getElementById('bmTradingPct')) document.getElementById('bmTradingPct').value = config.trading_allocation_pct ?? 70;
    if (document.getElementById('bmStaticPct')) document.getElementById('bmStaticPct').value = config.static_allocation_pct ?? 30;
    if (document.getElementById('bmProfitLockPct')) document.getElementById('bmProfitLockPct').value = config.profit_lock_trigger_pct ?? 0.4;
    if (document.getElementById('bmDailyLossPct')) document.getElementById('bmDailyLossPct').value = config.daily_loss_limit_pct ?? 3;
    if (document.getElementById('bmDailyTargetPct')) document.getElementById('bmDailyTargetPct').value = config.daily_profit_target_pct ?? 2;
}

function renderSummary(summary) {
    if (!summary) return;
    setText('totalBalance', formatMoney(summary.total_balance));
    setText('tradingBalance', formatMoney(summary.trading_balance));
    setText('staticBalanceSmall', formatMoney(summary.static_balance));
    setText('lockedProfit', formatMoney(summary.locked_profit));

    setText('totalBalanceText', formatMoney(summary.total_balance));
    setText('tradingBalanceText', formatMoney(summary.trading_balance));
    setText('staticBalanceText', formatMoney(summary.static_balance));
    setText('lockedProfitText', formatMoney(summary.locked_profit));
}

async function loadBalanceManager() {
    try {
        const data = await getJson(window.API_BASE + 'balance_manager.php');
        const config = data.config ?? {};
        const summary = data.summary ?? {};

        fillBalanceForm(config);
        renderSummary(summary);
        updateStaticAllocation();
    } catch (error) {
        console.error('Failed loading balance manager', error);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const tradingInput = document.getElementById('bmTradingPct');
    if (tradingInput) {
        tradingInput.addEventListener('input', updateStaticAllocation);
    }

    const saveButton = document.getElementById('saveBalanceManager');
    if (saveButton) {
        saveButton.addEventListener('click', async () => {
            const payload = {
                total_balance: Number(document.getElementById('bmTotalBalance')?.value || 0),
                trading_allocation_pct: Number(document.getElementById('bmTradingPct')?.value || 0),
                profit_lock_trigger_pct: Number(document.getElementById('bmProfitLockPct')?.value || 0),
                daily_loss_limit_pct: Number(document.getElementById('bmDailyLossPct')?.value || 0),
                daily_profit_target_pct: Number(document.getElementById('bmDailyTargetPct')?.value || 0)
            };

            try {
                const result = await postJson(window.API_BASE + 'balance_manager.php?action=save', payload);
                if (result.ok) {
                    await loadBalanceManager();
                    saveButton.textContent = 'Saved';
                    setTimeout(() => { saveButton.textContent = 'Save Settings'; }, 1600);
                } else {
                    alert('Save failed, please try again.');
                }
            } catch (error) {
                console.error('Balance save error', error);
                alert('Save failed, check connection.');
            }
        });
    }

    loadBalanceManager();
});
