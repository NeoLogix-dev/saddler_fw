(function(){

const originalFetch = window.fetch;

window.fetch = function(url, options){

    if(typeof url === "string"){

        if(url.startsWith("api/")){
            url = "../web/" + url;
        }

        if(url.startsWith("/api/")){
            url = "../web" + url;
        }
    }

    return originalFetch(url, options);
};

})();
