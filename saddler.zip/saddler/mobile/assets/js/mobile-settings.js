function safeText(value) {
    if (value === null || value === undefined || value === '') return '--';
    return String(value);
}

function setBadge(el, text, isActive) {
    if (!el) return;
    el.textContent = text;
    el.className = 'badge ' + (isActive ? 'green' : 'danger');
}

function setToggleState(inputId, labelId, activeText, inactiveText, storageKey, onChange) {
    const input = document.getElementById(inputId);
    const label = document.getElementById(labelId);
    if (!input || !label) return;

    const saved = window.localStorage.getItem(storageKey);
    input.checked = saved === 'true';
    updateToggleLabel(label, input.checked, activeText, inactiveText);

    input.addEventListener('change', async () => {
        const active = input.checked;
        updateToggleLabel(label, active, activeText, inactiveText);
        window.localStorage.setItem(storageKey, String(active));
        if (typeof onChange === 'function') {
            await onChange(active);
        }
    });
}

function updateToggleLabel(label, active, activeText, inactiveText) {
    label.textContent = active ? activeText : inactiveText;
    label.style.color = active ? '#19e68c' : '#8fa3c2';
}

async function getJson(url) {
    const response = await fetch(url + (url.includes('?') ? '&' : '?') + 't=' + Date.now(), { cache: 'no-store' });
    return await response.json();
}

async function postJson(url, data) {
    const response = await fetch(url, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(data)
    });
    return await response.json();
}

async function saveBackendSettings(payload) {
    try {
        await postJson(window.API_BASE + 'settings.php', payload);
    } catch (error) {
        console.warn('Settings save failed', error);
    }
}

async function loadSettingsPage() {
    const systemStatus = document.getElementById('systemStatus');
    const freqStatus = document.getElementById('freqStatus');

    const isOnline = navigator.onLine;
    setBadge(systemStatus, isOnline ? 'ONLINE' : 'OFFLINE', isOnline);

    try {
        const [settings, freqData] = await Promise.all([
            getJson(window.API_BASE + 'settings.php'),
            getJson(window.API_BASE + 'freqtrade.php')
        ]);

        const freqOk = freqData?.ok !== false && (freqData?.open_trades !== undefined || (freqData?.status && String(freqData.status).toLowerCase().includes('pong')));
        setBadge(freqStatus, freqOk ? 'ON' : 'OFF', freqOk);

        const liveSwitch = document.getElementById('liveSwitch');
        const autoSwitch = document.getElementById('autoSwitch');
        if (settings) {
            if (liveSwitch) {
                liveSwitch.checked = !!settings.live;
                updateToggleLabel(document.getElementById('liveLabel'), liveSwitch.checked, 'LIVE', 'PAPER');
                window.localStorage.setItem('mobile_live', String(liveSwitch.checked));
            }
            if (autoSwitch) {
                autoSwitch.checked = !!settings.auto;
                updateToggleLabel(document.getElementById('autoLabel'), autoSwitch.checked, 'AUTO ON', 'AUTO OFF');
                window.localStorage.setItem('mobile_auto', String(autoSwitch.checked));
            }
        }
    } catch (error) {
        console.warn('Failed loading settings status', error);
        setBadge(freqStatus, 'OFF', false);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    loadSettingsPage();

    setToggleState('liveSwitch', 'liveLabel', 'LIVE', 'PAPER', 'mobile_live', async (active) => {
        await saveBackendSettings({ live: active });
    });
    setToggleState('autoSwitch', 'autoLabel', 'AUTO ON', 'AUTO OFF', 'mobile_auto', async (active) => {
        await saveBackendSettings({ auto: active });
    });
    setToggleState('adapterHeaderSwitch', 'adapterHeaderLabel', 'ON', 'OFF', 'mobile_adapter');
    setToggleState('pmHeaderSwitch', 'pmHeaderLabel', 'ON', 'OFF', 'mobile_pm');
    setToggleState('pxHeaderSwitch', 'pxHeaderLabel', 'ON', 'OFF', 'mobile_px');

    window.addEventListener('online', () => setBadge(document.getElementById('systemStatus'), 'ONLINE', true));
    window.addEventListener('offline', () => setBadge(document.getElementById('systemStatus'), 'OFFLINE', false));
});
