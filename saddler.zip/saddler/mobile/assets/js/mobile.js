const menuBtn = document.getElementById("menuBtn");
const sidebar = document.getElementById("mobileSidebar");

if (menuBtn) {
    menuBtn.addEventListener("click", () => {
        sidebar.classList.toggle("active");
    });
}

function safeText(value) {
    if (value === null || value === undefined || value === '') return '--';
    return String(value);
}

function formatMoney(value) {
    if (value === null || value === undefined || value === '') return '--';
    const n = Number(value);
    if (!Number.isFinite(n)) return String(value);
    return '$' + n.toFixed(2);
}

function formatPct(value) {
    if (value === null || value === undefined || value === '') return '--';
    const n = Number(value);
    if (!Number.isFinite(n)) return String(value);
    return n.toFixed(2) + '%';
}

async function getJson(url) {
    const fullUrl = url + (url.includes('?') ? '&' : '?') + 't=' + Date.now();
    const response = await fetch(fullUrl, { cache: 'no-store' });
    return await response.json();
}

function renderPositions(positions) {
    const mobilePositions = document.getElementById("mobilePositions");
    if (!mobilePositions) return;

    mobilePositions.innerHTML = '';

    if (!positions || !positions.length) {
        mobilePositions.innerHTML =
            '<div class="position-card empty-card"><div>No open positions.</div></div>';
        return;
    }

    const rows = positions.map(p => {

        const side = safeText(p.side).toUpperCase();

        const pnlPct =
            p.pnl ??
            p.profit_pct ??
            (p.profit_ratio != null
                ? Number(p.profit_ratio) * 100
                : null);

        const pnlUsd =
            p.pnl_usd ??
            p.profit_abs ??
            p.real_profit ??
            null;

        const pnlClass =
            pnlPct !== null && Number(pnlPct) < 0
                ? 'negative'
                : 'positive';

        const sideClass =
            side === 'SHORT'
                ? 'short'
                : 'long';

        return `
            <tr>
                <td>
                    <div class="mobile-pair">
                        ${safeText(p.pair)}
                    </div>

                    <div class="mobile-entry">
                        Entry: ${safeText(p.entry ?? p.open_rate)}
                    </div>
                </td>

                <td>
                    <span class="position-badge ${sideClass}">
                        ${side}
                    </span>
                </td>

                <td class="${pnlClass}">
                    <div>${formatPct(pnlPct)}</div>
                    <div style="font-size:11px;opacity:.8;">
                        ${pnlUsd !== null ? formatMoney(pnlUsd) : '--'}
                    </div>
                </td>

                <td>
                    <div class="mobile-actions">

                        <button
                            class="mobile-close-btn"
                            onclick="manualCloseTrade('${p.trade_id}')">

                            CLOSE
                        </button>

                        <button
                            class="mobile-kill-btn"
                            onclick="emergencyCloseTrade('${p.trade_id}')">

                            KILL
                        </button>

                    </div>
                </td>
            </tr>
        `;
    }).join('');

    mobilePositions.innerHTML = `
        <div class="position-card position-table-card">
            <table class="position-table">
                <thead>
                    <tr>
                        <th>Pair</th>
                        <th>Side</th>
                        <th>Real PnL</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    ${rows}
                </tbody>
            </table>
        </div>
    `;
}
async function manualCloseTrade(tradeId) {

    if (!tradeId) return;

    const ok = confirm("Close trade?");

    if (!ok) return;

    try {

        await fetch(
            window.API_BASE + "manual_close.php",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    trade_id: tradeId
                })
            }
        );

        setTimeout(loadMobileDashboard, 1000);

    } catch (err) {

        console.error(
            "manual close failed",
            err
        );
    }
}

async function emergencyCloseTrade(tradeId) {

    if (!tradeId) return;

    const ok = confirm("EMERGENCY CLOSE trade?");

    if (!ok) return;

    try {

        await fetch(
            window.API_BASE + "emergency_close.php",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    trade_id: tradeId
                })
            }
        );

        setTimeout(loadMobileDashboard, 1000);

    } catch (err) {

        console.error(
            "emergency close failed",
            err
        );
    }
}

function renderSignals(signals) {
    const mobileSignals = document.getElementById("mobileSignals");
    if (!mobileSignals) return;

    mobileSignals.innerHTML = '';
    if (!signals || !signals.length) {
        mobileSignals.innerHTML = '<div class="signal-card empty-card"><div>No signal candidates.</div></div>';
        return;
    }

    const rows = signals.map(s => {
        const action = safeText(s.action ?? s.signal ?? s.type ?? s.order_side ?? s.side).toUpperCase();
        const pair = safeText(s.pair ?? s.market ?? s.symbol ?? s.currency_pair ?? s.instrument);
        const scoreRaw = s.score ?? s.confidence ?? s.strength ?? s.priority ?? s.rating;
        const score = safeText(scoreRaw);
        const actionClass = action.includes('BUY') || action.includes('LONG') ? 'long' : action.includes('SELL') || action.includes('SHORT') ? 'short' : '';
        const scoreClass = Number(scoreRaw) < 0 ? 'negative' : 'positive';

        return `
            <tr>
                <td>${pair}</td>
                <td><span class="position-badge ${actionClass}">${action || '--'}</span></td>
                <td class="${scoreClass}">${score}</td>
            </tr>
        `;
    }).join('');

    mobileSignals.innerHTML = `
        <div class="position-card position-table-card">
            <table class="position-table signal-table">
                <thead>
                    <tr>
                        <th>Pair</th>
                        <th>Action</th>
                        <th>Score</th>
                    </tr>
                </thead>
                <tbody>
                    ${rows}
                </tbody>
            </table>
        </div>
    `;
}

async function loadMobileDashboard() {
    try {
        const [freqData, balanceData, signalData, settingsData] = await Promise.all([
            getJson(window.API_BASE + 'freqtrade.php'),
            getJson(window.API_BASE + 'balance_manager.php'),
            getJson(window.API_BASE + 'signals.php'),
            getJson(window.API_BASE + 'settings.php')
        ]);

        const totalBalance = document.getElementById('totalBalance');
        const staticBalanceEl = document.getElementById('staticBalance');
        const profitDaily = document.getElementById('profitDaily');
        const openTrades = document.getElementById('openTrades');
        const liveLabel = document.getElementById('liveLabel');

        const positions = freqData.positions ?? freqData.open_positions ?? freqData.data ?? [];

        if (totalBalance) {
            totalBalance.textContent = formatMoney(balanceData?.summary?.total_balance ?? balanceData?.total_balance ?? '--');
        }
        if (staticBalanceEl) {
            staticBalanceEl.textContent = formatMoney(balanceData?.summary?.static_balance ?? balanceData?.static_balance ?? '--');
        }
        if (profitDaily) {
            profitDaily.textContent = formatMoney(balanceData?.summary?.realized_daily ?? balanceData?.realized_daily ?? '--');
        }
        if (openTrades) {
            const openCount = freqData?.open_trades ?? freqData?.open_count ?? freqData?.count ?? positions.length;
            openTrades.textContent = safeText(openCount);
        }

        renderPositions(positions);
        renderSignals(signalData.signals ?? []);

        const freqHeaderState = document.getElementById('freqHeaderState');
        if (freqHeaderState) {
            const isOnline = freqData?.ok !== false && (freqData?.open_trades !== undefined || (freqData?.status && String(freqData.status).toLowerCase().includes('ok')));
            freqHeaderState.className = 'badge ' + (isOnline ? 'green' : 'danger');
            freqHeaderState.innerHTML = `<span class="dot"></span>${isOnline ? 'FREQ ONLINE' : 'FREQ OFFLINE'}`;
        }

        if (liveLabel) {
            const isLive = !!settingsData?.live;
            liveLabel.textContent = isLive ? 'LIVE' : 'PAPER';
            liveLabel.className = 'badge ' + (isLive ? 'green' : 'danger');
        }
    } catch (error) {
        console.error('Mobile dashboard load failed:', error);
    }
}

loadMobileDashboard();
setInterval(loadMobileDashboard, 3000);
