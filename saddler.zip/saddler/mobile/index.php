<?php ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>LunaTrade mobile</title>

<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<link rel="stylesheet" href="../web/assets/css/hud.css">
<link rel="stylesheet" href="../web/assets/css/header-switches.css">
<link rel="stylesheet" href="assets/css/mobile.css">

<script>
window.API_BASE = "../web/api/";
window.ASSETS_BASE = "../web/assets/";
</script>

<script src="assets/js/mobile-api-fix.js"></script>

</head>
<body>

<div class="mobile-app">

<header class="mobile-header">
    <button id="menuBtn" class="icon-btn">
        <span class="material-icons">menu</span>
    </button>

    <div class="mobile-logo">
       
        <span style="font-weight: 600; font-size: 22px;">LunaTrade<sup style="font-size:0.55em; vertical-align:super; margin-left:4px;">mobile</sup></span>
    </div>

    <div class="mobile-status">
        <span id="freqHeaderState" class="badge blue">
            <span class="dot"></span>
            FREQ
        </span>

        <span id="liveLabel" class="badge danger">
            PAPER
        </span>
    </div>
</header>

<aside class="mobile-sidebar" id="mobileSidebar">
    <a href="index.php"><span class="material-icons">dashboard</span>Dashboard</a>
    <a href="balance.php"><span class="material-icons">account_balance_wallet</span>Balance Manager</a>
    <a href="settings.php"><span class="material-icons">settings</span>Settings</a>
</aside>

<main class="mobile-content">

<section class="mobile-overview">
    <div class="page-title">Dashboard</div>
    <div class="mobile-cards">
        <div class="mobile-card">
            <span class="card-label">Total Balance</span>
            <strong id="totalBalance">--</strong>
            <span class="card-icon material-icons">account_balance_wallet</span>
        </div>

        <div class="mobile-card">
            <span class="card-label">Static Balance</span>
            <strong id="staticBalance">--</strong>
            <span class="card-icon material-icons">account_balance</span>
        </div>

        <div class="mobile-card">
            <span class="card-label">Daily PnL</span>
            <strong id="profitDaily">--</strong>
            <span class="card-icon material-icons">payments</span>
        </div>

        <div class="mobile-card">
            <span class="card-label">Open Trades</span>
            <strong id="openTrades">--</strong>
            <span class="card-icon material-icons">swap_horiz</span>
        </div>
    </div>
</section>

<section class="mobile-section">
    <div class="section-title">Open Positions</div>
    <div id="mobilePositions"></div>
</section>

<section class="mobile-section">
    <div class="section-title">Signal Candidates</div>
    <div id="mobileSignals"></div>
</section>

</main>

<footer class="mobile-footer">

    <a href="balance.php">
        <div>
            <span class="material-icons">account_balance_wallet</span>
            <div class="footer-label">Balance</div>
        </div>
    </a>

    <button onclick="location.reload()">
        <div>
            <span class="material-icons">refresh</span>
            <div class="footer-label">Refresh</div>
        </div>
    </button>

    <a href="settings.php">
        <div>
            <span class="material-icons">settings</span>
            <div class="footer-label">Settings</div>
        </div>
    </a>

</footer>

</div>

<script src="assets/js/mobile.js"></script>

</body>
</html>
