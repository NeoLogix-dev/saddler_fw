<?php ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Settings</title>

<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<link rel="stylesheet" href="../web/assets/css/hud.css">
<link rel="stylesheet" href="../web/assets/css/header-switches.css">
<link rel="stylesheet" href="assets/css/mobile.css">

<script>
window.API_BASE = "../web/api/";
window.ASSETS_BASE = "../web/assets/";
</script>

<script src="assets/js/mobile-api-fix.js"></script>

</head>
<body>

<div class="page mobile-page">

<header class="page-header">
    <a href="index.php" class="back-btn">
        <span class="material-icons">arrow_back</span>
    </a>

    <div class="settings-title">
        <span class="material-icons">settings</span>
        <div>
            <h1>Settings</h1>
            <p>System and trading toggles</p>
        </div>
    </div>
</header>

<main class="settings-panel">
    <div class="settings-card">
        <div class="settings-row">
            <span>System</span>
            <span id="systemStatus" class="badge danger">OFFLINE</span>
        </div>
        <div class="settings-row">
            <span>Freqtrade</span>
            <span id="freqStatus" class="badge danger">OFF</span>
        </div>
    </div>

    <div class="settings-card">
        <div class="settings-row">
            <span>Live</span>
            <div class="switch-group">
                <span id="liveLabel" class="switch-label">PAPER</span>
                <label class="switch">
                    <input type="checkbox" id="liveSwitch">
                    <span class="slider"></span>
                </label>
            </div>
        </div>
        <div class="settings-row">
            <span>Auto</span>
            <div class="switch-group">
                <span id="autoLabel" class="switch-label">OFF</span>
                <label class="switch">
                    <input type="checkbox" id="autoSwitch">
                    <span class="slider"></span>
                </label>
            </div>
        </div>
        <div class="settings-row">
            <span>Adapter</span>
            <div class="switch-group">
                <span id="adapterHeaderLabel" class="switch-label">OFF</span>
                <label class="switch">
                    <input type="checkbox" id="adapterHeaderSwitch">
                    <span class="slider"></span>
                </label>
            </div>
        </div>
        <div class="settings-row">
            <span>PM</span>
            <div class="switch-group">
                <span id="pmHeaderLabel" class="switch-label">OFF</span>
                <label class="switch">
                    <input type="checkbox" id="pmHeaderSwitch">
                    <span class="slider"></span>
                </label>
            </div>
        </div>
        <div class="settings-row">
            <span>PX</span>
            <div class="switch-group">
                <span id="pxHeaderLabel" class="switch-label">OFF</span>
                <label class="switch">
                    <input type="checkbox" id="pxHeaderSwitch">
                    <span class="slider"></span>
                </label>
            </div>
        </div>
    </div>
</main>

<script src="assets/js/mobile-settings.js"></script>

</body>
</html>
