<?php
// NewTrade Advanced - Mobile Version
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>NewTrade Mobile</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="mobile-web-app-capable" content="yes">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <!-- ISTI CSS KAO U ORIGINALNOM index.php -->
    <link rel="stylesheet" href="assets/css/hud.css">
    <link rel="stylesheet" href="assets/css/header-switches.css">
    <link rel="stylesheet" href="assets/css/modules.css">
    <link rel="stylesheet" href="assets/css/layout-compact.css">
    <link rel="stylesheet" href="assets/css/layout-unified.css">
    <link rel="stylesheet" href="assets/css/dashboard-balance.css">

    <style id="dashboard-override-inline-style">
        .long{color:#19e68c;font-weight:900}
        .short{color:#ff5f6d;font-weight:900}
    </style>

    <style id="index-risk-balance-polish">
        .nt-risk-strip{
            margin:8px 0 14px !important;
            padding:0 !important;
            background:transparent !important;
            border:0 !important;
            box-shadow:none !important;
        }
        .nt-risk-strip .risk-strip-items{
            display:grid !important;
            grid-template-columns:repeat(6,minmax(0,1fr)) !important;
            gap:0 !important;
            background:transparent !important;
            border:0 !important;
        }
        .nt-risk-strip .risk-strip-item{
            padding:7px 14px 8px !important;
            background:transparent !important;
            border-right:1px solid rgba(85,168,255,.30) !important;
            min-width:0;
        }
        .nt-risk-strip .risk-strip-item:last-child{border-right:0 !important;}
        .nt-risk-strip .risk-strip-item span{
            display:block;
            color:#8fa3c2;
            font-size:11px;
            font-weight:900;
            letter-spacing:.04em;
            text-transform:uppercase;
            margin-bottom:5px;
            line-height:1;
        }
        .nt-risk-strip .risk-strip-item strong{
            display:block;
            color:#eef5ff;
            font-size:14px;
            font-weight:900;
            white-space:nowrap;
            overflow:hidden;
            text-overflow:ellipsis;
        }
        .balance-manager-card .balance-form label{
            color:#8fa3c2 !important;
            font-size:12px !important;
            font-weight:900 !important;
            letter-spacing:.02em;
        }
        .balance-manager-card .balance-form input{
            margin-top:7px !important;
        }
        .nt-main-row{
            grid-template-columns:minmax(0,1.55fr) minmax(330px,.75fr) !important;
        }
        @media(max-width:1250px){
            .nt-risk-strip .risk-strip-items{grid-template-columns:repeat(3,minmax(0,1fr)) !important;}
            .nt-main-row{grid-template-columns:1fr !important;}
        }
    </style>
        <style>  
        * {  
            margin: 0;  
            padding: 0;  
            box-sizing: border-box;  
            -webkit-tap-highlight-color: transparent;  
        }  

        body {  
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;  
            background: #0b0f1a;  
            color: #eef5ff;  
            display: flex;  
            flex-direction: column;  
            min-height: 100vh;  
            max-width: 480px;  
            margin: 0 auto;  
            position: relative;  
        }  

        .mobile-header {  
            display: flex;  
            align-items: center;  
            justify-content: space-between;  
            padding: 12px 16px;  
            background: #111827;  
            border-bottom: 1px solid #1e293b;  
            position: sticky;  
            top: 0;  
            z-index: 100;  
        }  

        .header-left {  
            display: flex;  
            align-items: center;  
            gap: 12px;  
        }  

        .menu-icon {  
            font-size: 24px;  
            color: #8fa3c2;  
            cursor: pointer;  
        }  

        .logo {  
            font-size: 18px;  
            font-weight: 800;  
            color: #eef5ff;  
        }  

        .header-right {  
            display: flex;  
            align-items: center;  
            gap: 10px;  
        }  

        .badge-freq {  
            background: #1e3a5f;  
            color: #60a5fa;  
            font-size: 10px;  
            font-weight: 700;  
            padding: 3px 8px;  
            border-radius: 4px;  
        }  

        .badge-live {  
            background: #1a3a2a;  
            color: #19e68c;  
            font-size: 10px;  
            font-weight: 700;  
            padding: 3px 8px;  
            border-radius: 4px;  
        }  

        /* SIDEBAR */  
        .sidebar-overlay {  
            display: none;  
            position: fixed;  
            inset: 0;  
            background: rgba(0,0,0,0.6);  
            z-index: 200;  
        }  
        .sidebar-overlay.active { display: block; }  

        .mobile-sidebar {  
            position: fixed;  
            top: 0;  
            left: -280px;  
            width: 280px;  
            height: 100%;  
            background: #0f172a;  
            border-right: 1px solid #1e293b;  
            z-index: 300;  
            transition: left 0.3s ease;  
            padding: 20px 16px;  
            overflow-y: auto;  
        }  
        .mobile-sidebar.open { left: 0; }  

        .sidebar-brand {  
            display: flex;  
            align-items: center;  
            gap: 10px;  
            margin-bottom: 24px;  
            padding-bottom: 16px;  
            border-bottom: 1px solid #1e293b;  
        }  
        .sidebar-brand .material-icons { font-size: 28px; color: #60a5fa; }  
        .sidebar-brand span { font-size: 18px; font-weight: 800; }  

        .nav-group-title {  
            color: #4b5563;  
            font-size: 10px;  
            font-weight: 700;  
            text-transform: uppercase;  
            letter-spacing: 0.08em;  
            margin: 16px 0 8px 0;  
        }  

        .nav-item {  
            display: flex;  
            align-items: center;  
            gap: 12px;  
            padding: 10px 12px;  
            border-radius: 6px;  
            color: #8fa3c2;  
            text-decoration: none;  
            font-size: 14px;  
            font-weight: 600;  
            transition: background 0.2s;  
        }  
        .nav-item:hover,  
        .nav-item.active {  
            background: #1e293b;  
            color: #eef5ff;  
        }  
        .nav-item .material-icons { font-size: 20px; }  

        /* MAIN CONTENT */  
        .main-content {  
            flex: 1;  
            padding: 16px;  
            padding-bottom: 80px;  
        }  

        /* KARTICE */  
        .cards {  
            display: grid;  
            grid-template-columns: 1fr 1fr;  
            gap: 10px;  
            margin-bottom: 16px;  
        }  
                .card-metric {
            background: #111827;
            border: 1px solid #1e293b;
            border-radius: 10px;
            padding: 14px;
        }
        .card-metric.full { grid-column: 1 / -1; }
        .card-metric span {
            display: block;
            color: #8fa3c2;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            margin-bottom: 6px;
        }
        .card-metric strong { font-size: 22px; font-weight: 900; color: #eef5ff; }
        .card-metric small { display: block; color: #4b5563; font-size: 11px; margin-top: 4px; }

        .section-title {
            font-size: 14px;
            font-weight: 700;
            color: #8fa3c2;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 10px;
            margin-top: 4px;
        }

        .positions-list {
            background: #111827;
            border: 1px solid #1e293b;
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 16px;
        }
        .position-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 12px 14px;
            border-bottom: 1px solid #1e293b;
        }
        .position-item:last-child { border-bottom: none; }
        .pair-info { display: flex; align-items: center; gap: 10px; }
        .pair-info .pair { font-weight: 700; font-size: 14px; }
        .side-tag {
            font-size: 10px;
            font-weight: 800;
            padding: 2px 8px;
            border-radius: 4px;
        }
        .side-tag.long { background: rgba(25,230,140,0.15); color: #19e68c; }
        .side-tag.short { background: rgba(255,95,109,0.15); color: #ff5f6d; }
        .pnl { font-weight: 800; font-size: 14px; }
        .pnl.positive { color: #19e68c; }
        .pnl.negative { color: #ff5f6d; }
                .candidates-list {
            background: #111827;
            border: 1px solid #1e293b;
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 16px;
        }
        .candidate-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 12px 14px;
            border-bottom: 1px solid #1e293b;
        }
        .candidate-item:last-child { border-bottom: none; }
        .candidate-pair { font-weight: 700; font-size: 14px; }
        .candidate-action {
            font-size: 11px;
            font-weight: 700;
            padding: 2px 10px;
            border-radius: 4px;
        }
        .candidate-action.buy { background: rgba(25,230,140,0.15); color: #19e68c; }
        .candidate-action.sell { background: rgba(255,95,109,0.15); color: #ff5f6d; }
        .candidate-score { font-size: 14px; font-weight: 800; color: #fbbf24; }
        .empty-state { padding: 20px; text-align: center; color: #4b5563; font-size: 13px; }

        .page { display: none; }
        .page.active { display: block; }

        /* SETTINGS */
        .settings-card {
            background: #111827;
            border: 1px solid #1e293b;
            border-radius: 10px;
            padding: 16px;
            margin-bottom: 12px;
        }
        .settings-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid #1e293b;
        }
        .settings-item:last-child { border-bottom: none; }
        .settings-item .label { font-size: 13px; font-weight: 600; color: #eef5ff; }
        .settings-item .sub { font-size: 11px; color: #4b5563; }
        .badge { font-size: 10px; font-weight: 700; padding: 3px 10px; border-radius: 20px; }
        .badge.online { background: rgba(25,230,140,0.15); color: #19e68c; }
        .badge.offline { background: rgba(255,95,109,0.15); color: #ff5f6d; }
        .badge.on { background: rgba(25,230,140,0.15); color: #19e68c; }
        .badge.off { background: rgba(255,95,109,0.15); color: #ff5f6d; }

        /* SWITCH */
        .switch { position: relative; width: 44px; height: 24px; display: inline-block; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider {
            position: absolute; cursor: pointer; inset: 0;
            background: #374151; border-radius: 24px; transition: 0.3s;
        }
        .slider::before {
            content: ''; position: absolute; height: 18px; width: 18px;
            left: 3px; bottom: 3px; background: #eef5ff; border-radius: 50%; transition: 0.3s;
        }
        .switch input:checked + .slider { background: #60a5fa; }
        .switch input:checked + .slider::before { transform: translateX(20px); }
        .switch-danger input:checked + .slider { background: #ff5f6d; }
        .switch-success input:checked + .slider { background: #19e68c; }
          /* FOOTER */  
        .mobile-footer {  
            position: fixed;  
            bottom: 0;  
            left: 50%;  
            transform: translateX(-50%);  
            width: 100%;  
            max-width: 480px;  
            background: #111827;  
            border-top: 1px solid #1e293b;  
            display: flex;  
            align-items: center;  
            justify-content: space-around;  
            padding: 10px 16px;  
            z-index: 100;  
        }  
        .footer-btn {  
            display: flex;  
            flex-direction: column;  
            align-items: center;  
            gap: 2px;  
            background: none;  
            border: none;  
            color: #8fa3c2;  
            cursor: pointer;  
            padding: 4px 12px;  
            transition: color 0.2s;  
        }  
        .footer-btn .material-icons { font-size: 22px; }  
        .footer-btn .label {  
            font-size: 9px;  
            font-weight: 600;  
            text-transform: uppercase;  
            letter-spacing: 0.03em;  
        }  
        .footer-btn.active { color: #60a5fa; }  

        /* BALANCE MANAGER */  
        .balance-form {  
            background: #111827;  
            border: 1px solid #1e293b;  
            border-radius: 10px;  
            padding: 16px;  
        }  
        .balance-form label {  
            display: block;  
            color: #8fa3c2;  
            font-size: 12px;  
            font-weight: 700;  
            letter-spacing: 0.02em;  
            margin-bottom: 16px;  
        }  
        .balance-form input {  
            width: 100%;  
            margin-top: 6px;  
            padding: 10px 12px;  
            background: #0b0f1a;  
            border: 1px solid #1e293b;  
            border-radius: 6px;  
            color: #eef5ff;  
            font-size: 14px;  
            font-weight: 600;  
            outline: none;  
        }  
        .balance-form input:focus { border-color: #60a5fa; }  
        .balance-form input[readonly] { opacity: 0.6; }  
        .save-btn {  
            width: 100%;  
            padding: 12px;  
            background: #2563eb;  
            border: none;  
            border-radius: 8px;  
            color: #fff;  
            font-size: 14px;  
            font-weight: 700;  
            cursor: pointer;  
            display: flex;  
            align-items: center;  
            justify-content: center;  
            gap: 8px;  
            margin-top: 8px;  
        }  
        .balance-summary {  
            background: #111827;  
            border: 1px solid #1e293b;  
            border-radius: 10px;  
            padding: 16px;  
            margin-top: 12px;  
        }  
        .balance-summary > div {  
            display: flex;  
            justify-content: space-between;  
            padding: 8px 0;  
            border-bottom: 1px solid #1e293b;  
        }  
        .balance-summary > div:last-child { border-bottom: none; }  
        .balance-summary span { color: #8fa3c2; font-size: 12px; font-weight: 600; }  
        .balance-summary strong { font-size: 14px; font-weight: 800; }  
        .back-btn {  
            display: flex;  
            align-items: center;  
            gap: 6px;  
            background: none;  
            border: none;  
            color: #8fa3c2;  
            font-size: 13px;  
            font-weight: 600;  
            cursor: pointer;  
            margin-bottom: 16px;  
            padding: 4px 0;  
        }  
        .page-header { font-size: 16px; font-weight: 800; margin-bottom: 16px; color: #eef5ff; }  
    </style>  
</head>  
<body>  


    <!-- SIDEBAR OVERLAY -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- SIDEBAR -->
    <div class="mobile-sidebar" id="mobileSidebar">
        <div class="sidebar-brand">
            <span class="material-icons">analytics</span>
            <span>NewTrade</span>
        </div>
        <div class="nav-group-title">Core</div>
        <a href="#" class="nav-item" data-nav="dashboard">
            <span class="material-icons">dashboard</span> Dashboard
        </a>
        <a href="#" class="nav-item" data-nav="positions">
            <span class="material-icons">show_chart</span> Positions
        </a>
        <a href="#" class="nav-item" data-nav="candidates">
            <span class="material-icons">auto_graph</span> Candidates
        </a>
        <div class="nav-group-title">Management</div>
        <a href="#" class="nav-item" data-nav="balance">
            <span class="material-icons">account_balance_wallet</span> Balance
        </a>
        <a href="#" class="nav-item" data-nav="settings">
            <span class="material-icons">settings</span> Settings
        </a>
    </div>
        <!-- MOBILE HEADER -->
    <header class="mobile-header">
        <div class="header-left">
            <span class="menu-icon material-icons" id="menuToggle">menu</span>
            <span class="logo">NewTrade</span>
        </div>
        <div class="header-right">
            <span class="badge-freq">1m</span>
            <span class="badge-live">LIVE</span>
        </div>
    </header>

    <!-- MAIN CONTENT -->
    <div class="main-content">

        <!-- ========================================== -->
        <!-- PAGE: DASHBOARD (default)                    -->
        <!-- ========================================== -->
        <div class="page active" id="page-dashboard">
            <div class="cards">
                <div class="card-metric">
                    <span>Balance</span>
                    <strong id="dash-balance">0.00</strong>
                    <small>USDT</small>
                </div>
                <div class="card-metric">
                    <span>Open P&L</span>
                    <strong id="dash-pnl">0.00</strong>
                    <small>USDT</small>
                </div>
                <div class="card-metric full">
                    <span>Today</span>
                    <strong id="dash-day-pnl">0.00</strong>
                    <small>USDT</small>
                </div>
            </div>

            <div class="section-title">Open Positions</div>
            <div class="positions-list" id="mobile-positions">
                <div class="empty-state">No open positions</div>
            </div>

            <div class="section-title">Top Candidates</div>
            <div class="candidates-list" id="mobile-candidates">
                <div class="empty-state">No candidates yet</div>
            </div>
        </div>