<?php
header('Location: /web/settings/index.php');
exit;
