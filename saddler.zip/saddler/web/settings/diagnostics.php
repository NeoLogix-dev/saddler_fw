<?php

$file =
    realpath(__DIR__ .
    '/../../engine/storage/signal_diagnostics.json');

$data = [];

if ($file && file_exists($file)) {
    $data =
        json_decode(
            file_get_contents($file),
            true
        );
}

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Diagnostics</title>

<style>
body{
background:#111;
color:#fff;
font-family:Arial;
padding:20px;
}
.card{
background:#1c1c1c;
padding:20px;
border-radius:12px;
margin-bottom:20px;
}
.big{
font-size:34px;
font-weight:bold;
}
</style>

</head>
<body>

<h1>Signal Diagnostics</h1>

<div class="card">
<div>Signals Scanned</div>
<div class="big">
<?= intval($data['signals_scanned'] ?? 0) ?>
</div>
</div>

<div class="card">
<div>AI Rejected</div>
<div class="big">
<?= intval($data['ai_rejected'] ?? 0) ?>
</div>
</div>

<div class="card">
<div>Cooldown Rejected</div>
<div class="big">
<?= intval($data['cooldown_rejected'] ?? 0) ?>
</div>
</div>

<div class="card">
<div>Exposure Rejected</div>
<div class="big">
<?= intval($data['exposure_rejected'] ?? 0) ?>
</div>
</div>

<div class="card">
<div>Executed</div>
<div class="big">
<?= intval($data['executed'] ?? 0) ?>
</div>
</div>

</body>
</html>
