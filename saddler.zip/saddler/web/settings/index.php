<?php ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>LunaTrader Settings Center</title>
<style>
body{
background:#0f1117;
color:#fff;
font-family:Arial;
padding:20px;
}
.grid{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(280px,1fr));
gap:20px;
}
.card{
background:#1b2030;
padding:20px;
border-radius:14px;
}
button{
padding:10px 16px;
border:none;
border-radius:8px;
cursor:pointer;
margin:4px;
}
input{
width:100%;
padding:10px;
margin-top:10px;
background:#0d1320;
color:#fff;
border:1px solid #333;
}
pre{
background:#000;
padding:15px;
overflow:auto;
}
</style>
</head>
<body>

<h1>LunaTrader Unified Settings</h1>

<div class="grid">

<div class="card">
<h2>Profiles</h2>

<button onclick="profile('safe')">SAFE</button>
<button onclick="profile('balanced')">BALANCED</button>
<button onclick="profile('aggressive')">AGGRESSIVE</button>

</div>

<div class="card">
<h2>AI Filters</h2>

<label>Min AI Score</label>
<input id="ai_score" type="number">

<label>Cooldown Minutes</label>
<input id="cooldown" type="number">

<button onclick="save()">Save</button>

</div>

<div class="card">
<h2>Risk</h2>

<label>Max Open Trades</label>
<input id="max_trades" type="number">

<label>Risk Per Trade %</label>
<input id="risk_trade" type="number">

</div>

<div class="card">
<h2>Live Mode</h2>

<button onclick="toggleLive(true)">LIVE</button>
<button onclick="toggleLive(false)">PAPER</button>

</div>


<div class="card">
<h2>Diagnostics</h2>

<a href="diagnostics.php">
<button>
Open Diagnostics
</button>
</a>

</div>

</div>

<h2>Runtime Config</h2>
<pre id="out"></pre>

<script>

let current = {};

async function load(){

const r = await fetch('../api/settings_get.php');
current = await r.json();

document.getElementById('out').textContent =
JSON.stringify(current,null,4);

document.getElementById('ai_score').value =
current.filters.min_ai_score;

document.getElementById('cooldown').value =
current.filters.cooldown_minutes;

document.getElementById('max_trades').value =
current.risk.max_open_trades;

document.getElementById('risk_trade').value =
current.risk.risk_per_trade;
}

async function save(){

current.filters.min_ai_score =
parseInt(document.getElementById('ai_score').value);

current.filters.cooldown_minutes =
parseInt(document.getElementById('cooldown').value);

current.risk.max_open_trades =
parseInt(document.getElementById('max_trades').value);

current.risk.risk_per_trade =
parseFloat(document.getElementById('risk_trade').value);

await fetch('../api/settings_save.php',{
method:'POST',
headers:{
'Content-Type':'application/json'
},
body:JSON.stringify(current)
});

load();
}

async function profile(name){

await fetch('../api/settings_profile.php',{
method:'POST',
headers:{
'Content-Type':'application/json'
},
body:JSON.stringify({profile:name})
});

load();
}

async function toggleLive(state){

current.mode.live = state;

await fetch('../api/settings_save.php',{
method:'POST',
headers:{
'Content-Type':'application/json'
},
body:JSON.stringify(current)
});

load();
}

load();

</script>

</body>
</html>
