<?php
// NewTrade Advanced Dashboard
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>NewTrade Advanced</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <!-- everything default and using `weight: 100` -->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
   <link rel="stylesheet" href="assets/css/hud.css">
    <link rel="stylesheet" href="assets/css/header-switches.css">

<link rel="stylesheet" href="assets/css/modules.css">
<link rel="stylesheet" href="assets/css/header-switches.css">
<style id="dashboard-override-inline-style">
.long{color:#19e68c;font-weight:900}
.short{color:#ff5f6d;font-weight:900}
</style>
<link rel="stylesheet" href="assets/css/layout-compact.css">
<link rel="stylesheet" href="assets/css/layout-unified.css">
<link rel="stylesheet" href="assets/css/dashboard-balance.css">




<style id="index-risk-balance-polish">
/* Dashboard risk strip polish */
.nt-risk-strip{
    margin:8px 0 14px !important;
    padding:0 !important;
    background:transparent !important;
    border:0 !important;
    box-shadow:none !important;
}
.nt-risk-strip .risk-strip-items{
    display:grid !important;
    grid-template-columns:repeat(6,minmax(0,1fr)) !important;
    gap:0 !important;
    background:transparent !important;
    border:0 !important;
}
.nt-risk-strip .risk-strip-item{
    padding:7px 14px 8px !important;
    background:transparent !important;
    border-right:1px solid rgba(85,168,255,.30) !important;
    min-width:0;
}
.nt-risk-strip .risk-strip-item:last-child{border-right:0 !important;}
.nt-risk-strip .risk-strip-item span{
    display:block;
    color:#8fa3c2;
    font-size:11px;
    font-weight:900;
    letter-spacing:.04em;
    text-transform:uppercase;
    margin-bottom:5px;
    line-height:1;
}
.nt-risk-strip .risk-strip-item strong{
    display:block;
    color:#eef5ff;
    font-size:14px;
    font-weight:900;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
}
.balance-manager-card .balance-form label{
    color:#8fa3c2 !important;
    font-size:12px !important;
    font-weight:900 !important;
    letter-spacing:.02em;
}
.balance-manager-card .balance-form input{
    margin-top:7px !important;
}
.nt-main-row{
    grid-template-columns:minmax(0,1.55fr) minmax(330px,.75fr) !important;
}
.px-btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;border:1px solid #20385e;background:#0b1424;color:#eef5ff;border-radius:12px;padding:5px 10px;text-decoration:none;cursor:pointer;font-weight:800;font-size:13px}
.px-btn .material-icons{font-size:17px}
.px-btn:hover{border-color:#55a8ff;background:#101c31}
.px-btn.green{border-color:#13694b;color:#19e68c}
.px-btn.red{border-color:#6c2430;color:#ff5f6d}
.px-btn.yellow{border-color:#77571c;color:#ffba3a}

@media(max-width:1250px){
    .nt-risk-strip .risk-strip-items{grid-template-columns:repeat(3,minmax(0,1fr)) !important;}
    .nt-main-row{grid-template-columns:1fr !important;}
}

    .stat-card {
        background: rgba(12,22,38,.88);
        border-radius: 20px;
        padding: 1px 17px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.05);
        display: flex;
        align-items: center;
        justify-content: space-between;
        transition: transform 0.2s ease;
       border: 1px solid rgba(85,168,255,.30);
    }

    .stat-card:hover {
        transform: translateY(-5px);
    }

    .stat-info {
        display: flex;
        flex-direction: column;
    }

    .stat-title {
        font-size: 14px;
        color: #9bb0d0;
        margin-bottom: 15px;
    }

    .stat-value {
        font-size: 24px;
        font-weight: bold;
        color: #eef5ff;
    }

    .stat-icon {
        font-size: 55px;
        color: #9bb0d0;
    /*    background: rgba(76, 175, 80, 0.1);*/
        padding: 0px;
        opacity: 0.1;
       /* border-radius: 50%;*/
    }

</style>

</head>
<body>
<div class="app" id="appRoot">

   <aside class="sidebar" id="sidebar">
    <div class="brand">




        <div class="brand-left">
            <span class="material-icons brand-icon">analytics</span>
      
                
            
               <span class="brand-text" style="font-weight: 600; font-size: 22px;">LunaTrade<sup style="font-size:0.55em; vertical-align:super; margin-left:4px;">desktop</sup></span>
     
            
          
        </div>
          <button class="collapse-btn" id="collapseBtn" title="Collapse sidebar">
            <span class="material-icons">chevron_left</span>
        </button>
      
    </div>

    
    
    <nav class="side-nav compact-nav">

        <div class="nav-group">
            <div class="nav-group-title">Core</div>

            <a href="index.php" data-section="dashboard">
                <span class="material-icons">dashboard</span>
                <span class="nav-label">Dashboard</span>
            </a>

            <a href="modules/supervisor.php" data-section="supervisor">
                <span class="material-icons">settings_power</span>
                <span class="nav-label">Supervisor</span>
            </a>
        </div>

        <div class="nav-group">
            <div class="nav-group-title">Signals</div>

            <a href="modules/signals.php" data-section="signals">
                <span class="material-icons">stacked_line_chart</span>
                <span class="nav-label">Signals</span>
            </a>

            <a href="modules/agents.php" data-section="agents">
                <span class="material-icons">psychology</span>
                <span class="nav-label">Agents</span>
            </a>

            <a href="modules/risk.php" data-section="risk">
                <span class="material-icons">shield</span>
                <span class="nav-label">Risk</span>
            </a>
        </div>

        <div class="nav-group">
            <div class="nav-group-title">Execution</div>

            <a href="modules/strategies.php" data-section="strategies">
                <span class="material-icons">account_tree</span>
                <span class="nav-label">Strategies</span>
            </a>

            <a href="modules/orchestrator.php" data-section="orchestrator">
                <span class="material-icons">hub</span>
                <span class="nav-label">Orchestrator</span>
            </a>

            <a href="modules/execution.php" data-section="execution">
                <span class="material-icons">bolt</span>
                <span class="nav-label">Execution</span>
            </a>

            <a href="modules/adapter.php" data-section="adapter">
                <span class="material-icons">electrical_services</span>
                <span class="nav-label">Adapter</span>
            </a>
        </div>

        <div class="nav-group">
            <div class="nav-group-title">Positions</div>

            <a href="modules/positions.php" data-section="positions">
                <span class="material-icons">show_chart</span>
                <span class="nav-label">Positions</span>
            </a>

            <a href="modules/position_manager.php" data-section="position_manager">
                <span class="material-icons">precision_manufacturing</span>
                <span class="nav-label">Position Manager</span>
            </a>

            <a href="modules/position_executor.php" data-section="position_executor">
                <span class="material-icons">published_with_changes</span>
                <span class="nav-label">Position Executor</span>
            </a>
        </div>

        <div class="nav-group">
            <div class="nav-group-title">System</div>

            <a href="modules/logs.php" data-section="logs">
                <span class="material-icons">terminal</span>
                <span class="nav-label">Logs</span>
            </a>
        </div>

    </nav>


</aside>

    <main class="main" id="dashboard">

   

        <header class="topbar unified-topbar">
   
    <div class="topbar-title">
       <span style="font-weight: 600; font-size: 22px;">LunaTrade<sup style="font-size:0.6em; vertical-align:super; margin-left:4px;">desktop</sup></span>
 

    </div>

    <div class="badges unified-badges">
        <span id="freqHeaderState" class="badge blue">
            <span class="dot"></span>
            FREQT. CHECKING
        </span>

        <span id="engineHeaderState" class="badge blue">
            <span class="dot"></span>
            ENGINE CHECKING
        </span>

        <div class="switch-card adapter-header-switch">
            <span class="switch-label" id="adapterHeaderLabel">ADAPTER OFF</span>
            <label class="switch">
                <input type="checkbox" id="adapterHeaderSwitch">
                <span class="slider"></span>
            </label>
        </div>

        <div class="switch-card pm-header-switch">
            <span class="switch-label" id="pmHeaderLabel">PM OFF</span>
            <label class="switch">
                <input type="checkbox" id="pmHeaderSwitch">
                <span class="slider"></span>
            </label>
        </div>

        <div class="switch-card px-header-switch">
            <span class="switch-label" id="pxHeaderLabel">PX OFF</span>
            <label class="switch">
                <input type="checkbox" id="pxHeaderSwitch">
                <span class="slider"></span>
            </label>
        </div>

        <div class="switch-card danger">
            <span class="switch-label" id="liveLabel">PAPER</span>
            <label class="switch">
                <input type="checkbox" id="liveSwitch">
                <span class="slider"></span>
            </label>
        </div>

        <div class="switch-card">
            <span class="switch-label" id="autoLabel">AUTO OFF</span>
            <label class="switch">
                <input type="checkbox" id="autoSwitch">
                <span class="slider"></span>
            </label>
        </div>
    </div>
</header>

        <section class="cards nt-balance-cards">





<div class="stat-card">
        <div class="stat-info">
            <span class="stat-title">Static Balance</span>
            <span class="stat-value" id="staticBalance">--</span>
        </div>        
        <div class="stat-icon"> <span class="material-icons" style="font-size: 55px; margin-top:25px">account_balance</span></div>
    </div>

<!--
            <div class="card metric">
                <span>Total Balance</span>
                <div>
                    
                        <strong id="staticBalance">--</strong>
                        <small>Static / locked balance</small>
                  
                    
            </div>
            </div>
-->
<div class="stat-card">
        <div class="stat-info">
            <span class="stat-title">Open Trades</span>
            <span class="stat-value" id="openTrades">--</span>
        </div>        
        <div class="stat-icon"> <span class="material-icons" style="font-size: 55px; margin-top:25px">swap_horiz</span></div>
    </div>


    <!--
            <div class="card metric">
                <span>Open Trades</span>
                <strong id="openTrades">--</strong>
                <small id="openTradesSub">Freqtrade</small>
            </div>
-->
<div class="stat-card">
  <div class="stat-info">
            <span class="stat-title">Realized PnL</span>
            <span class="stat-value" id="realizedDailyPnl">--</span>
        </div>        
        <div class="stat-icon"> <span class="material-icons" style="font-size: 55px; margin-top:25px">payments</span></div>
    </div>

    <!--

            <div class="card metric">
                <span>Realized PnL</span>
                <strong id="realizedDailyPnl">--</strong>
                <small>Daily realized</small>
            </div>
-->
            <div class="stat-card">
  <div class="stat-info">
            <span class="stat-title">Realized PnL</span>
            <span class="stat-value" id="realizedTotalPnl">--</span>
         
        </div>        
        <div class="stat-icon"> <span class="material-icons" style="font-size: 55px; margin-top:25px">paid</span></div>
    </div>
    
    <!--



            <div class="card metric">
                <span>Total Realized PnL</span>
                <strong id="realizedTotalPnl">--</strong>
                <small>All-time realized</small>
            </div>
-->


        </section>


<section class="nt-risk-strip">
    <div class="risk-strip-items">
        <div class="risk-strip-item">
            <span>Pair / Direction</span>
            <strong><span id="riskBestPair">--</span>  <span id="riskAction">--</span></strong>
        </div>

        <div class="risk-strip-item">
            <span>Risk Score</span>
            <strong id="riskValue">--</strong>
        </div>

        <div class="risk-strip-item">
            <span>Allowed</span>
            <strong id="riskAllowed">--</strong>
        </div>

        <div class="risk-strip-item">
            <span>Reason</span>
            <strong id="riskReason">--</strong>
        </div>

        <div class="risk-strip-item">
            <span>Signal Score</span>
            <strong id="riskScore">--</strong>
        </div>

        <div class="risk-strip-item">
            <span>Confidence</span>
            <strong id="riskConfidence">--</strong>
        </div>
    </div>
</section>


        <!-- Open Positions moved above AI Signal Candidates because it is more important operational info -->
        <section class="layout nt-main-row">
            <div class="card positions-card" id="positions">
                <div class="card-head">
                    <h2>Open Positions</h2>
                    <span class="mini-status" id="positionsCount">-- active</span>
                </div>
                <table>
                    <thead>
                    <tr>
                        <th>Pair</th>
                        <th>Side</th>
                        <th>Entry</th>
                        <th>Current</th>
                        <th>PnL</th>
                        <th>Stake</th>
                        <th>Opened</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody id="positionsBody">
                    <tr><td colspan="8">Loading positions...</td></tr>
                    </tbody>
                </table>
            </div>

            <div class="card balance-manager-card" id="balanceManager">
                <div class="card-head">
                    <h2>Balance Manager</h2>
                    <span class="mini-status" id="balanceMode">PAPER</span>
                </div>

                <div class="balance-form">
                    <label>
                        Total Balance
                        <input id="bmTotalBalance" type="number" step="0.01" min="0">
                    </label>

                    <label>
                        Trading Allocation %
                        <input id="bmTradingPct" type="number" step="1" min="1" max="100">
                    </label>

                    <label>
                        Static Allocation %
                        <input id="bmStaticPct" type="number" step="1" min="0" max="99" readonly>
                    </label>

                    <label>
                        Profit Lock Trigger %
                        <input id="bmProfitLockPct" type="number" step="0.1" min="0">
                    </label>

                    <label>
                        Daily Loss Limit %
                        <input id="bmDailyLossPct" type="number" step="0.1" min="0">
                    </label>

                    <label>
                        Daily Profit Target %
                        <input id="bmDailyTargetPct" type="number" step="0.1" min="0">
                    </label>

                    <button id="saveBalanceManager" class="nt-btn">
                        <span class="material-icons">save</span>
                        Save settings
                    </button>
                </div>

                <div class="balance-summary">
                    <div><span>Trading Balance</span><strong id="tradingBalance">--</strong></div>
                    <div><span>Static Balance</span><strong id="staticBalanceSmall">--</strong></div>
                    <div><span>Locked Profit</span><strong id="lockedProfit">--</strong></div>
                </div>
            </div>
        </section>

        <section class="layout">
            <div class="card wide" id="signals">
                <div class="card-head">
                    <h2>Signal Candidates</h2>
                    <input id="searchInput" placeholder="Search pair...">
                </div>
                <table>
                    <thead>
                    <tr>
                        <th>Pair</th>
                        <th>Side</th>
                        <th>Action</th>
                        <th>Score</th>
                        <th>Confidence</th>
                        <th>Trend</th>
                        <th>Funding</th>
                        <th>Orderflow</th>
                        <th>Onchain</th>
                        <th>Risk</th>
                    </tr>
                    </thead>
                    <tbody id="signalsBody">
                    <tr><td colspan="10">Loading signals...</td></tr>
                    </tbody>
                </table>
            </div>

            <div class="card" id="agents">
                <h2>AI Consensus</h2>
                <div id="agentsPanel" class="risk-list">
                    <div><b>Trend Agent:</b> waiting</div>
                    <div><b>Funding Agent:</b> waiting</div>
                    <div><b>Orderflow Agent:</b> waiting</div>
                    <div><b>Onchain Agent:</b> waiting</div>
                </div>
            </div>
        </section>

        <section class="card logs" id="logs">
            <h2>Log</h2>
            <pre id="engineLogs">Loading logs...</pre>
        </section>
    </main>
</div>

<script src="assets/js/header-switches.js"></script>
<script src="assets/js/app.js"></script>
<script src="assets/js/dashboard-balance.js"></script>
<script src="assets/js/topbar-controls.js"></script>

</body>
</html>
