
U web/assets/js/execution-module.js:

1. Dodaj JS iz execution_reason_patch.js odmah poslije:
function statusPill(status){ ... }

2. Zamijeni:

<td>${item.reason || '-'}</td>

sa:

<td>${reasonPill(item.reason)}</td>

3. Zamijeni u renderCooldowns():

${c.reason || '-'}

sa:

${reasonPill(c.reason)}

4. Zamijeni u renderEvents():

<td>${e.reason || '-'}</td>

sa:

<td>${reasonPill(e.reason)}</td>


U web/assets/css/execution.css:

dodaj kompletan sadržaj iz execution_reason_patch.css na kraj fajla.
