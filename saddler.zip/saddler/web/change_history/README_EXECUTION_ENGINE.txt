NewTrade Execution Engine update

Kopiraj ZIP preko:
C:\xampp\htdocs\newtrade_02\

Dodano:
- engine/execution/execution_engine.py
- engine/execution_daemon.py
- web/modules/execution.php
- web/api/execution.php
- web/assets/js/execution-module.js
- web/assets/css/execution.css
- JSON state fajlovi:
  engine/storage/trade_queue.json
  engine/storage/cooldowns.json
  engine/storage/execution_state.json
  engine/storage/emergency_events.json
- scripts/start_execution_daemon.bat

Pokretanje:
1. Pokreni AI engine:
   cd C:\xampp\htdocs\newtrade_02\engine
   .\.venv\Scripts\Activate.ps1
   python main.py

2. Pokreni Execution daemon u drugom terminalu:
   cd C:\xampp\htdocs\newtrade_02\engine
   .\.venv\Scripts\Activate.ps1
   python execution_daemon.py

3. Otvori modul:
   http://localhost/newtrade_02/web/modules/execution.php

Šta radi:
- čita AI signale iz signals.json
- čita LIVE/AUTO state iz settings.json
- pravi trade queue
- označava READY / READY_MANUAL / WAIT_CONFIRMATION / BLOCKED / COOLDOWN
- vodi cooldowns
- bilježi protection/emergency events
- ne šalje direktan live trade bez dodatnog execution adaptera

Napomena:
Ovo je siguran execution intelligence sloj. Direktno slanje naloga prema Freqtrade REST API-ju dodajemo kao sljedeći korak kada potvrdiš workflow.
