NewTrade Execution Orchestration v2

Kopiraj ZIP preko:
C:\xampp\htdocs\newtrade_02\

Dodano / izmijenjeno:
- engine/execution/execution_engine.py
- engine/execution_daemon.py
- web/api/execution.php
- web/modules/execution.php
- web/assets/js/execution-module.js
- web/assets/css/execution.css
- web/assets/js/module-common.js
- engine/storage/execution_config.json
- engine/storage/execution_history.json

Nove funkcije:
- Priority score
- Consensus score
- Execution score
- Signal expiry TTL
- Anti-overtrade protection
- Execution history
- Editable execution rules iz UI-ja
- Prošireni Trade Queue prikaz

Pokretanje:
1) AI engine:
cd C:\xampp\htdocs\newtrade_02\engine
.\.venv\Scripts\Activate.ps1
python main.py

2) Execution daemon:
cd C:\xampp\htdocs\newtrade_02\engine
.\.venv\Scripts\Activate.ps1
python execution_daemon.py

3) UI:
http://localhost/newtrade_02/web/modules/execution.php
