NewTrade Orchestrator update

Kopiraj sadržaj ZIP-a preko:
C:\xampp\htdocs\newtrade_02\

Dodano:
- web/modules/orchestrator.php
- web/api/orchestrator.php
- web/assets/js/orchestrator-module.js
- web/assets/css/orchestrator.css
- engine/storage/orchestrator_state.json
- engine/storage/commands.json
- scripts/run_active_strategy.bat

Stranica:
http://localhost/newtrade_02/web/modules/orchestrator.php

Šta radi:
- prikazuje Freqtrade online/offline
- prikazuje aktivnu strategiju
- prikazuje LIVE/PAPER i AUTO state
- čita najbolji AI signal i risk gate
- komande: start, restart, stop request, sync
- generiše BAT za pokretanje aktivne strategije

Važno:
Ovo je sigurni control layer. Ne mijenja Freqtrade dry_run config automatski.
Stop request je state komanda; za pravi stop treba helper service ili ručno gašenje terminala.
