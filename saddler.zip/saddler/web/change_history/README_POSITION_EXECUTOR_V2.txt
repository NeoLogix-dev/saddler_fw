NewTrade Position Executor v2

Kopiraj sadržaj ZIP-a preko:
C:\xampp\htdocs\newtrade_02\

Dodano:
- engine/position/position_executor.py
- engine/position_executor_daemon.py
- engine/storage/position_executor_config.json
- engine/storage/position_executor_state.json
- engine/storage/position_executor_events.json
- web/api/position_executor.php
- web/modules/position_executor.php
- web/assets/js/position-executor-module.js
- web/assets/css/position-executor.css
- scripts/start_position_executor_daemon.bat

Pokretanje:
cd C:\xampp\htdocs\newtrade_02\engine
.\.venv\Scripts\Activate.ps1
python position_executor_daemon.py

UI:
http://localhost/newtrade_02/web/modules/position_executor.php

VAŽNO:
- Executor je default OFF.
- Paper execution je dozvoljen, Live execution je default blokiran.
- FULL EXIT se šalje samo za EMERGENCY/CRITICAL ako je executor ON.
- Breakeven, trailing i partial TP su u v2 intent logovi, bez stvarnog reduce naloga.
