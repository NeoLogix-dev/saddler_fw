NewTrade Smart Position Manager v1

Kopiraj sadržaj ZIP-a preko:
C:\xampp\htdocs\newtrade_02\

Dodano:
- engine/position/position_manager.py
- engine/position_daemon.py
- engine/storage/position_config.json
- engine/storage/position_state.json
- engine/storage/position_events.json
- web/api/positions_manager.php
- web/modules/position_manager.php
- web/assets/js/position-manager-module.js
- web/assets/css/position-manager.css
- scripts/start_position_daemon.bat

Pokretanje:
1) Freqtrade mora biti online.
2) AI engine:
   python main.py
3) Execution daemon:
   python execution_daemon.py
4) Adapter daemon:
   python -m execution.execution_adapter
5) Position manager daemon:
   python position_daemon.py

UI:
http://localhost/newtrade_02/web/modules/position_manager.php

Šta radi v1:
- čita Freqtrade open positions
- računa lifecycle: OPEN, PROFIT, BREAKEVEN, TRAILING, RECOVERY, DANGER, CRITICAL
- dynamic SL state
- TP ladder state
- recovery action
- emergency/protection events
- exposure summary

Važno:
v1 je decision/monitoring layer. Real modify/partial exit komande prema Freqtrade adapteru dodajemo u narednom koraku.
