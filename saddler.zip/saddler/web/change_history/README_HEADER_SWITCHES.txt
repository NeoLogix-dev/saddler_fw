NewTrade header switches update

Kopiraj:
web/assets/css/header-switches.css
web/assets/js/header-switches.js
web/assets/js/module-common.js

u:
C:\xampp\htdocs\newtrade_02\web\assets\css\
C:\xampp\htdocs\newtrade_02\web\assets\js\

Zatim u web/index.php u <head> dodaj:
<link rel="stylesheet" href="assets/css/header-switches.css">

i prije </body> dodaj:
<script src="assets/js/header-switches.js"></script>

U SVIM web/modules/*.php u <head> dodaj:
<link rel="stylesheet" href="../assets/css/header-switches.css">

i prije </body> dodaj:
<script src="../assets/js/header-switches.js"></script>

Zamijeni header <div class="badges">...</div>:
- u web/index.php koristi HEADER_SNIPPET_DASHBOARD.html
- u web/modules/*.php koristi HEADER_SNIPPET_MODULE.html

Napomena:
Switch za LIVE/PAPER i AUTO je trenutno UI state preko localStorage.
Ne šalje naredbe Freqtrade-u i ne pali live trading sam od sebe.
