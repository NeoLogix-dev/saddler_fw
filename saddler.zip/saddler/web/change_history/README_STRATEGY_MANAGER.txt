Kopiraj sadržaj ZIP-a preko:
C:\xampp\htdocs\newtrade_02\

Dodano:
- web/modules/strategies.php
- web/modules/strategy_editor.php
- web/api/strategies.php
- JS/CSS za strategije
- engine/storage/strategy_state.json

Stranice:
http://localhost/newtrade_02/web/modules/strategies.php
http://localhost/newtrade_02/web/modules/strategy_editor.php?new=1

Napomena:
Pokreni snima aktivnu strategiju i generiše scripts/run_freqtrade_strategy.bat.
Ako Apache ne može startovati terminal proces, ručno pokreni BAT.
