Kopiraj fajlove:

web/index.php -> C:\xampp\htdocs\newtrade_02\web\index.php
web/assets/css/hud.css -> C:\xampp\htdocs\newtrade_02\web\assets\css\hud.css
web/assets/js/app.js -> C:\xampp\htdocs\newtrade_02\web\assets\js\app.js

Promjene:
- Freqtrade Status kartica uklonjena.
- Freqtrade indikator prebačen u header.
- Open Positions prebačen na mjesto stare Freqtrade Status kartice.
- Sidebar dobio collapse dugme.
- Ikone zamijenjene Material Icons ikonama.
- Sidebar linkovi za sada vode na sekcije iste stranice:
  #dashboard, #signals, #risk, #positions, #agents, #logs.
