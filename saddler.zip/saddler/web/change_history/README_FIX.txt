Kopiraj fajlove ovako:

engine/main.py  ->  C:\xampp\htdocs\newtrade_02\engine\main.py
web/api/signals.php  ->  C:\xampp\htdocs\newtrade_02\web\api\signals.php

Zatim restartuj engine:
cd C:\xampp\htdocs\newtrade_02\engine
.\.venv\Scripts\Activate.ps1
python main.py

Obavezno otvori tačan dashboard:
http://localhost/newtrade_02/web/

Ako u browseru stoji /newtrade_v01/web/, gledaš stari projekat.
