NewTrade Execution Adapter update

Kopiraj sadržaj ZIP-a preko:
C:\xampp\htdocs\newtrade_02\

Dodano:
- engine/execution/freqtrade_client.py
- engine/execution/execution_adapter.py
- engine/storage/adapter_config.json
- engine/storage/adapter_state.json
- web/api/adapter.php
- web/modules/adapter.php
- web/assets/js/adapter-module.js
- web/assets/css/adapter.css
- scripts/start_execution_adapter.bat

Pokretanje:
1) Freqtrade mora biti online.
2) AI engine:
   python main.py
3) Execution daemon:
   python execution_daemon.py
4) Adapter daemon:
   python -m execution.execution_adapter

Ili:
scripts/start_execution_adapter.bat

Važno:
- Adapter je DEFAULT disabled.
- U UI otvori:
  http://localhost/newtrade_02/web/modules/adapter.php
- Klikni Enable adapter.
- AUTO switch mora biti ON.
- Ako je PAPER, adapter može otvarati dry-run tradeove.
- LIVE execution je blokiran dok u Adapter config ne uključiš live_execution_enabled.

Freqtrade API:
Adapter koristi Freqtrade REST API token/login i forceenter/forceexit.
Ako tvoja Freqtrade verzija ne podržava forceenter, koristi fallback forcebuy.
