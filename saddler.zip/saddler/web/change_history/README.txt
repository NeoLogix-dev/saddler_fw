Kopiraj:

engine/execution/execution_engine.py
u:
C:\xampp\htdocs\newtrade_02\engine\execution\execution_engine.py

Opcionalno, ali preporučeno:
kopiraj engine/storage/execution_history.json
ili ručno obriši sadržaj starog history fajla.

Zašto:
Prethodna verzija je READY/READY_MANUAL signale upisivala u history,
pa je anti-overtrade pogrešno blokirao sve pair-ove.

Nakon kopiranja:
1. Zaustavi execution_daemon
2. Pokreni ga ponovo:
   cd C:\xampp\htdocs\newtrade_02\engine
   .\.venv\Scripts\Activate.ps1
   python execution_daemon.py

Napomena:
AUTO OFF je normalno ako Auto switch nije uključen.
Kada je Auto OFF, dobar signal treba biti READY_MANUAL.
Kada je Auto ON, dobar signal treba biti READY.
