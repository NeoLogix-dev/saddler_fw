Kopiraj web folder preko postojećeg:
C:\xampp\htdocs\newtrade_02\web\

Dodano:
- modules/signals.php: svi signali tabela + pretraga
- modules/positions.php: pozicije tabela + pretraga
- modules/logs.php: logovi tabela + pretraga
- modules/risk.php: risk pravila i risk tabela
- modules/agents.php: objašnjenje agenata i agent score tabela
