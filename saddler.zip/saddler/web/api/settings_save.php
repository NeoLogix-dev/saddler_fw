<?php
header('Content-Type: application/json; charset=utf-8');

$file = realpath(__DIR__ . '/../../engine/storage/system_settings.json');

if (!$file) {
    $file = __DIR__ . '/../../engine/storage/system_settings.json';
}

$current = [];

if (file_exists($file)) {
    $current = json_decode(file_get_contents($file), true);
}

$input = json_decode(file_get_contents('php://input'), true);

if (!is_array($input)) {
    echo json_encode([
        'ok' => false,
        'error' => 'Invalid JSON'
    ]);
    exit;
}

$data = array_replace_recursive($current, $input);

file_put_contents(
    $file,
    json_encode(
        $data,
        JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
    )
);

echo json_encode([
    'ok' => true,
    'settings' => $data
]);
