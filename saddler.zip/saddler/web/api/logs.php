<?php
header('Content-Type: text/plain');
$file = __DIR__ . '/../../engine/logs/engine.log';
if (!file_exists($file)) {
    echo "No logs yet.";
    exit;
}
$lines = file($file);
$last = array_slice($lines, -80);
echo implode('', $last);
