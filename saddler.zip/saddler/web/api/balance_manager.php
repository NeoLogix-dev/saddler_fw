<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$storage = realpath(__DIR__ . '/../../engine/storage');
if (!$storage) {
    $storage = __DIR__ . '/../../engine/storage';
    @mkdir($storage, 0777, true);
}

$configFile = $storage . DIRECTORY_SEPARATOR . 'balance_manager.json';
$statsFile = $storage . DIRECTORY_SEPARATOR . 'balance_stats.json';

function read_json($file, $default) {
    if (!file_exists($file)) return $default;
    $data = json_decode(file_get_contents($file), true);
    return is_array($data) ? $data : $default;
}

function write_json($file, $data) {
    $data['updated_at'] = date('c');
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
}

function out($data) {
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$default = [
    'total_balance' => 1000.00,
    'trading_allocation_pct' => 70,
    'static_allocation_pct' => 30,
    'profit_lock_trigger_pct' => 0.4,
    'daily_loss_limit_pct' => 3.0,
    'daily_profit_target_pct' => 2.0,
    'locked_profit' => 0.0,
    'mode' => 'profit_only'
];

$config = array_merge($default, read_json($configFile, $default));
$stats = read_json($statsFile, [
    'daily' => [],
    'monthly' => [],
    'realized_total' => 0.0,
    'locked_total' => 0.0,
    'events' => []
]);

$action = $_GET['action'] ?? 'state';

if ($action === 'save') {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) out(['ok'=>false, 'error'=>'Invalid JSON']);

    foreach (['total_balance','trading_allocation_pct','profit_lock_trigger_pct','daily_loss_limit_pct','daily_profit_target_pct'] as $k) {
        if (isset($input[$k]) && is_numeric($input[$k])) {
            $config[$k] = floatval($input[$k]);
        }
    }

    $config['trading_allocation_pct'] = max(1, min(100, $config['trading_allocation_pct']));
    $config['static_allocation_pct'] = round(100 - $config['trading_allocation_pct'], 2);

    write_json($configFile, $config);
}

$today = date('Y-m-d');
$month = date('Y-m');

$tradingBalance = round(floatval($config['total_balance']) * (floatval($config['trading_allocation_pct']) / 100), 2);
$staticBalance = round(floatval($config['total_balance']) * (floatval($config['static_allocation_pct']) / 100) + floatval($config['locked_profit']), 2);

out([
    'ok' => true,
    'config' => $config,
    'stats' => $stats,
    'summary' => [
        'total_balance' => round(floatval($config['total_balance']), 2),
        'trading_balance' => $tradingBalance,
        'static_balance' => $staticBalance,
        'locked_profit' => round(floatval($config['locked_profit']), 2),
        'trading_allocation_pct' => floatval($config['trading_allocation_pct']),
        'static_allocation_pct' => floatval($config['static_allocation_pct']),
        'profit_lock_trigger_pct' => floatval($config['profit_lock_trigger_pct']),
        'daily_loss_limit_pct' => floatval($config['daily_loss_limit_pct']),
        'daily_profit_target_pct' => floatval($config['daily_profit_target_pct']),
        'realized_daily' => round(floatval($stats['daily'][$today] ?? 0), 2),
        'realized_monthly' => round(floatval($stats['monthly'][$month] ?? 0), 2),
        'realized_total' => round(floatval($stats['realized_total'] ?? 0), 2),
        'locked_total' => round(floatval($stats['locked_total'] ?? 0), 2)
    ]
]);
