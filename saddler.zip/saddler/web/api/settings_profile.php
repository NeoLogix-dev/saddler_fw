<?php
header('Content-Type: application/json; charset=utf-8');

$file = realpath(__DIR__ . '/../../engine/storage/system_settings.json');

$data = json_decode(file_get_contents($file), true);

$input = json_decode(file_get_contents('php://input'), true);

$profile = $input['profile'] ?? 'balanced';

$profiles = $data['profiles'] ?? [];

if (!isset($profiles[$profile])) {
    echo json_encode([
        'ok' => false,
        'error' => 'Unknown profile'
    ]);
    exit;
}

$p = $profiles[$profile];

$data['profile'] = $profile;

$data['filters']['min_ai_score'] =
    $p['min_ai_score'];

$data['filters']['cooldown_minutes'] =
    $p['cooldown_minutes'];

$data['risk']['max_open_trades'] =
    $p['max_open_trades'];

file_put_contents(
    $file,
    json_encode(
        $data,
        JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
    )
);

echo json_encode([
    'ok' => true,
    'profile' => $profile,
    'settings' => $data
]);
