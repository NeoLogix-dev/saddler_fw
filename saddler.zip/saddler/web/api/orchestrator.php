<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$storage = realpath(__DIR__ . '/../../engine/storage');
if (!$storage) { $storage = __DIR__ . '/../../engine/storage'; @mkdir($storage, 0777, true); }

$settingsFile = $storage . DIRECTORY_SEPARATOR . 'settings.json';
$strategyFile = $storage . DIRECTORY_SEPARATOR . 'strategy_state.json';
$signalsFile = $storage . DIRECTORY_SEPARATOR . 'signals.json';
$orcFile = $storage . DIRECTORY_SEPARATOR . 'orchestrator_state.json';
$commandsFile = $storage . DIRECTORY_SEPARATOR . 'commands.json';

function read_json($file, $default) {
    if (!file_exists($file)) return $default;
    $data = json_decode(file_get_contents($file), true);
    return is_array($data) ? $data : $default;
}
function write_json($file, $data) {
    $data['updated_at'] = date('c');
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
}
function out($data) {
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}
function freqtrade_ping() {
    $ctx = stream_context_create(['http'=>['timeout'=>1.5]]);
    $res = @file_get_contents('http://127.0.0.1:8080/api/v1/ping', false, $ctx);
    return $res !== false && stripos($res, 'pong') !== false;
}

$action = $_GET['action'] ?? 'state';

$settings = read_json($settingsFile, ['live'=>false, 'auto'=>false]);
$strategy = read_json($strategyFile, ['active_strategy'=>null, 'active_file'=>null]);
$signals = read_json($signalsFile, ['signals'=>[]]);
$orc = read_json($orcFile, [
    'desired_state' => 'idle',
    'last_command' => null,
    'last_status' => null,
    'updated_at' => null
]);
$commands = read_json($commandsFile, ['commands'=>[]]);

$best = null;
if (!empty($signals['signals']) && is_array($signals['signals'])) $best = $signals['signals'][0];

$freqOnline = freqtrade_ping();

$gate = [
    'best_pair' => $best['pair'] ?? null,
    'best_action' => $best['action'] ?? null,
    'score' => $best['score'] ?? null,
    'risk' => $best['risk'] ?? null,
    'allowed' => !empty($best['allowed']),
    'reason' => $best['reason'] ?? 'NO_SIGNAL',
    'auto_enabled' => !empty($settings['auto']),
    'live_enabled' => !empty($settings['live']),
    'can_execute_auto' => (!empty($settings['auto']) && !empty($best['allowed']) && (($best['action'] ?? '') === 'ENTER'))
];

if ($action === 'state') {
    out([
        'ok' => true,
        'freqtrade_online' => $freqOnline,
        'settings' => $settings,
        'strategy' => $strategy,
        'orchestrator' => $orc,
        'decision_gate' => $gate,
        'commands' => array_slice(array_reverse($commands['commands'] ?? []), 0, 20)
    ]);
}

if ($action === 'command') {
    $input = json_decode(file_get_contents('php://input'), true);
    $cmd = $input['command'] ?? '';

    $allowed = ['start', 'restart', 'stop', 'sync'];
    if (!in_array($cmd, $allowed, true)) out(['ok'=>false, 'error'=>'Invalid command']);

    $activeStrategy = $strategy['active_strategy'] ?? 'NewTradeStrategy';

    $message = '';
    $status = 'queued';

    if ($cmd === 'start' || $cmd === 'restart') {
        $projectRoot = realpath(__DIR__ . '/../..');
        $batDir = $projectRoot . DIRECTORY_SEPARATOR . 'scripts';
        @mkdir($batDir, 0777, true);

        $bat = $batDir . DIRECTORY_SEPARATOR . 'run_active_strategy.bat';
        $batContent = "@echo off\r\n";
        $batContent .= "cd /d " . $projectRoot . "\\freqtrade\r\n";
        $batContent .= "call ..\\engine\\.venv\\Scripts\\activate.bat\r\n";
        $batContent .= "freqtrade trade --config user_data\\config.json --strategy " . $activeStrategy . "\r\n";
        $batContent .= "pause\r\n";
        file_put_contents($bat, $batContent);

        @pclose(@popen('start "NewTrade Active Strategy" /MIN "' . $bat . '"', 'r'));

        $orc['desired_state'] = 'running';
        $message = "Start requested for strategy {$activeStrategy}. BAT generated: scripts/run_active_strategy.bat";
    }

    if ($cmd === 'stop') {
        $orc['desired_state'] = 'stopped';
        $message = 'Stop requested. Safe stop should be handled manually or by helper service.';
    }

    if ($cmd === 'sync') {
        $orc['desired_state'] = $freqOnline ? 'running_detected' : 'offline_detected';
        $message = 'State synchronized.';
    }

    $entry = [
        'time' => date('c'),
        'command' => $cmd,
        'status' => $status,
        'message' => $message
    ];

    $commands['commands'][] = $entry;
    $commands['commands'] = array_slice($commands['commands'], -100);

    $orc['last_command'] = $cmd;
    $orc['last_status'] = $status;
    $orc['last_message'] = $message;

    write_json($orcFile, $orc);
    write_json($commandsFile, $commands);

    out(['ok'=>true, 'entry'=>$entry, 'orchestrator'=>$orc]);
}

out(['ok'=>false, 'error'=>'Unknown action']);
