<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$file = realpath(__DIR__ . '/../../engine/storage/signals.json');

if (!$file || !file_exists($file)) {
    echo json_encode([
        "updated_at" => null,
        "signals" => [],
        "error" => "signals.json not found",
        "expected_path" => __DIR__ . '/../../engine/storage/signals.json'
    ]);
    exit;
}

$raw = file_get_contents($file);
$data = json_decode($raw, true);

if ($data === null) {
    echo json_encode([
        "updated_at" => null,
        "signals" => [],
        "error" => "invalid json",
        "path" => $file,
        "raw_start" => substr($raw, 0, 200)
    ]);
    exit;
}

/*
Supports both formats:

1) New format:
{
  "updated_at": "...",
  "signals": [...]
}

2) Old format:
[
  {...},
  {...}
]
*/
if (is_array($data) && array_keys($data) === range(0, count($data) - 1)) {
    $data = [
        "updated_at" => date('c', filemtime($file)),
        "signals" => $data
    ];
}

if (!isset($data["signals"]) || !is_array($data["signals"])) {
    $data["signals"] = [];
}

echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
