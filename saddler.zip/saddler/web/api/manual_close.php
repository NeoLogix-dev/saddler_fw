<?php

header('Content-Type: application/json');

$data = json_decode(
    file_get_contents("php://input"),
    true
);

$tradeId = $data["trade_id"] ?? null;

if (!$tradeId) {

    echo json_encode([
        "success" => false,
        "error" => "missing trade id"
    ]);

    exit;
}

$payload = json_encode([
    "tradeid" => intval($tradeId)
]);

$url = "http://127.0.0.1:8080/api/v1/forceexit";

$ch = curl_init($url);

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

curl_setopt($ch, CURLOPT_POST, true);

curl_setopt(
    $ch,
    CURLOPT_USERPWD,
    "newtrade:newtrade123"
);

curl_setopt(
    $ch,
    CURLOPT_HTTPHEADER,
    [
        "Content-Type: application/json"
    ]
);

curl_setopt(
    $ch,
    CURLOPT_POSTFIELDS,
    $payload
);

$response = curl_exec($ch);
file_put_contents(
    "manual_close_debug.txt",
    print_r($response, true)
);

$error = curl_error($ch);

curl_close($ch);

echo json_encode([
    "success" => $error ? false : true,
    "response" => $response,
    "error" => $error
]);