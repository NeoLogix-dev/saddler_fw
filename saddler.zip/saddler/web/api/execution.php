<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$storage = realpath(__DIR__ . '/../../engine/storage');
if (!$storage) {
    $storage = __DIR__ . '/../../engine/storage';
    @mkdir($storage, 0777, true);
}

$files = [
    'queue' => $storage . DIRECTORY_SEPARATOR . 'trade_queue.json',
    'cooldowns' => $storage . DIRECTORY_SEPARATOR . 'cooldowns.json',
    'state' => $storage . DIRECTORY_SEPARATOR . 'execution_state.json',
    'emergency' => $storage . DIRECTORY_SEPARATOR . 'emergency_events.json',
    'config' => $storage . DIRECTORY_SEPARATOR . 'execution_config.json',
    'history' => $storage . DIRECTORY_SEPARATOR . 'execution_history.json',
];

function read_json($file, $default) {
    if (!file_exists($file)) return $default;
    $data = json_decode(file_get_contents($file), true);
    return is_array($data) ? $data : $default;
}

function write_json($file, $data) {
    $data['updated_at'] = date('c');
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
}

function out($data) {
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$action = $_GET['action'] ?? 'state';

$queue = read_json($files['queue'], ['queue' => []]);
$cooldowns = read_json($files['cooldowns'], ['pairs' => []]);
$state = read_json($files['state'], []);
$emergency = read_json($files['emergency'], ['events' => []]);
$config = read_json($files['config'], []);
$history = read_json($files['history'], ['items' => []]);

if ($action === 'state') {
    out([
        'ok' => true,
        'state' => $state,
        'queue' => $queue['queue'] ?? [],
        'cooldowns' => $cooldowns['pairs'] ?? [],
        'emergency' => $emergency['events'] ?? [],
        'config' => $config,
        'history' => $history['items'] ?? []
    ]);
}

if ($action === 'save_config') {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) out(['ok'=>false, 'error'=>'Invalid JSON']);

    foreach ($input as $key => $value) {
        if (is_numeric($value)) $config[$key] = $value + 0;
    }

    write_json($files['config'], $config);
    out(['ok'=>true, 'config'=>$config]);
}

if ($action === 'cooldown') {
    $input = json_decode(file_get_contents('php://input'), true);
    $pair = $input['pair'] ?? '';
    $minutes = intval($input['minutes'] ?? ($config['cooldown_minutes'] ?? 15));
    $reason = $input['reason'] ?? 'MANUAL_COOLDOWN';

    if (!$pair) out(['ok'=>false, 'error'=>'Missing pair']);

    $until = (new DateTime('now', new DateTimeZone('UTC')))->modify("+{$minutes} minutes")->format(DateTime::ATOM);
    $cooldowns['pairs'][$pair] = [
        'cooldown_until' => $until,
        'reason' => $reason,
        'created_at' => date('c')
    ];

    write_json($files['cooldowns'], $cooldowns);
    out(['ok'=>true, 'message'=>'Cooldown set', 'pair'=>$pair, 'until'=>$until]);
}

if ($action === 'clear_cooldown') {
    $input = json_decode(file_get_contents('php://input'), true);
    $pair = $input['pair'] ?? '';

    if (!$pair) out(['ok'=>false, 'error'=>'Missing pair']);

    unset($cooldowns['pairs'][$pair]);
    write_json($files['cooldowns'], $cooldowns);
    out(['ok'=>true, 'message'=>'Cooldown cleared', 'pair'=>$pair]);
}

if ($action === 'cancel') {
    $input = json_decode(file_get_contents('php://input'), true);
    $pair = $input['pair'] ?? '';

    if (!$pair) out(['ok'=>false, 'error'=>'Missing pair']);

    foreach ($queue['queue'] as &$item) {
        if (($item['pair'] ?? '') === $pair) {
            $item['status'] = 'CANCELLED';
            $item['reason'] = 'MANUAL_CANCEL';
            $item['updated_at'] = date('c');
        }
    }

    write_json($files['queue'], $queue);
    out(['ok'=>true, 'message'=>'Queue item cancelled', 'pair'=>$pair]);
}

out(['ok'=>false, 'error'=>'Unknown action']);
