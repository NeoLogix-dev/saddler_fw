<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

/*
 * NewTrade Freqtrade bridge
 * - Health check: /api/v1/ping only.
 * - Open positions: SQLite DB.
 * - Current prices/PnL: Binance futures public ticker with local cache.
 * - Does not call /api/v1/status.
 */

$root = realpath(__DIR__ . '/../..');
$storage = realpath(__DIR__ . '/../../engine/storage');
if (!$storage) {
    $storage = __DIR__ . '/../../engine/storage';
    @mkdir($storage, 0777, true);
}

$cacheFile = $storage . DIRECTORY_SEPARATOR . 'freqtrade_status_cache.json';
$priceCacheFile = $storage . DIRECTORY_SEPARATOR . 'market_prices_cache.json';
$configFile = realpath(__DIR__ . '/../../freqtrade/user_data/config.json');

$host = '127.0.0.1';
$port = 8080;
$dbUrl = null;

if ($configFile && file_exists($configFile)) {
    $cfg = json_decode(file_get_contents($configFile), true);
    if (is_array($cfg)) {
        if (isset($cfg['api_server'])) {
            $api = $cfg['api_server'];
            $host = $api['listen_ip_address'] ?? $host;
            if ($host === '0.0.0.0') $host = '127.0.0.1';
            $port = intval($api['listen_port'] ?? $port);
        }
        $dbUrl = $cfg['db_url'] ?? null;
    }
}

$base = "http://{$host}:{$port}/api/v1";

function read_json($file, $default) {
    if (!file_exists($file)) return $default;
    $data = json_decode(file_get_contents($file), true);
    return is_array($data) ? $data : $default;
}

function write_json($file, $data) {
    $data['updated_at'] = date('c');
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
}

function http_get_json($url, $timeout = 2) {
    $ctx = stream_context_create([
        'http' => [
            'method' => 'GET',
            'timeout' => $timeout,
            'ignore_errors' => true,
            'header' => "User-Agent: NewTrade/1.0\r\n"
        ]
    ]);

    $raw = @file_get_contents($url, false, $ctx);
    if ($raw === false || $raw === '') return null;
    $json = json_decode($raw, true);
    return is_array($json) ? $json : null;
}

function http_ping($url, $timeout = 2) {
    $json = http_get_json($url, $timeout);
    return is_array($json) && strtolower((string)($json['status'] ?? '')) === 'pong';
}

function resolve_db_path($root, $dbUrl) {
    $candidates = [];

    if ($dbUrl && strpos($dbUrl, 'sqlite:///') === 0) {
        $p = substr($dbUrl, strlen('sqlite:///'));
        $p = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $p);

        if (preg_match('/^[A-Za-z]:[\\\\\/]/', $p)) {
            $candidates[] = $p;
        } else {
            $candidates[] = $root . DIRECTORY_SEPARATOR . 'freqtrade' . DIRECTORY_SEPARATOR . $p;
            $candidates[] = $root . DIRECTORY_SEPARATOR . $p;
        }
    }

    $candidates[] = $root . DIRECTORY_SEPARATOR . 'freqtrade' . DIRECTORY_SEPARATOR . 'tradesv3.dryrun.sqlite';
    $candidates[] = $root . DIRECTORY_SEPARATOR . 'freqtrade' . DIRECTORY_SEPARATOR . 'tradesv3.sqlite';
    $candidates[] = $root . DIRECTORY_SEPARATOR . 'tradesv3.dryrun.sqlite';
    $candidates[] = $root . DIRECTORY_SEPARATOR . 'tradesv3.sqlite';

    foreach ($candidates as $c) {
        if ($c && file_exists($c)) return $c;
    }

    return null;
}

function table_columns($pdo, $table) {
    $cols = [];
    try {
        $stmt = $pdo->query("PRAGMA table_info({$table})");
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $cols[] = $row['name'];
        }
    } catch (Exception $e) {}
    return $cols;
}

function first_col($cols, $options, $fallback = null) {
    foreach ($options as $o) {
        if (in_array($o, $cols, true)) return $o;
    }
    return $fallback;
}

function pair_to_binance_symbol($pair) {
    $p = str_replace(':USDT', '', (string)$pair);
    $p = str_replace('/', '', $p);
    return strtoupper($p);
}

function get_market_prices($positions, $priceCacheFile) {
    $cache = read_json($priceCacheFile, ['prices' => [], 'updated_at_ts' => 0]);
    $now = time();
    $prices = $cache['prices'] ?? [];

    // Cache price calls for 10s.
    if (($cache['updated_at_ts'] ?? 0) > ($now - 10)) {
        return $prices;
    }

    foreach ($positions as $p) {
        $pair = $p['pair'] ?? '';
        $symbol = pair_to_binance_symbol($pair);
        if (!$symbol) continue;

        $url = 'https://fapi.binance.com/fapi/v1/ticker/price?symbol=' . urlencode($symbol);
        $json = http_get_json($url, 2);

        if (is_array($json) && isset($json['price'])) {
            $prices[$pair] = floatval($json['price']);
        }
    }

    write_json($priceCacheFile, [
        'updated_at_ts' => $now,
        'prices' => $prices
    ]);

    return $prices;
}

function read_positions_from_sqlite($dbPath) {
    if (!$dbPath || !file_exists($dbPath)) {
        return ['ok' => false, 'error' => 'DB not found', 'positions' => [], 'open_trades' => 0, 'db_path' => $dbPath];
    }

    try {
        $pdo = new PDO('sqlite:' . $dbPath, null, null, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_TIMEOUT => 2
        ]);

        $cols = table_columns($pdo, 'trades');
        if (!$cols) {
            return ['ok' => false, 'error' => 'trades table not found', 'positions' => [], 'open_trades' => 0, 'db_path' => $dbPath];
        }

        $idCol = first_col($cols, ['id', 'trade_id'], 'id');
        $pairCol = first_col($cols, ['pair'], 'pair');
        $openRateCol = first_col($cols, ['open_rate'], null);
        $amountCol = first_col($cols, ['amount'], null);
        $stakeCol = first_col($cols, ['stake_amount'], null);
        $openDateCol = first_col($cols, ['open_date', 'open_date_utc'], null);
        $isShortCol = first_col($cols, ['is_short'], null);

        $select = ["{$idCol} AS trade_id", "{$pairCol} AS pair"];
        if ($openRateCol) $select[] = "{$openRateCol} AS open_rate";
        if ($amountCol) $select[] = "{$amountCol} AS amount";
        if ($stakeCol) $select[] = "{$stakeCol} AS stake_amount";
        if ($openDateCol) $select[] = "{$openDateCol} AS open_date";
        if ($isShortCol) $select[] = "{$isShortCol} AS is_short";

        $sql = "SELECT " . implode(", ", $select) . " FROM trades WHERE is_open = 1 ORDER BY {$idCol} DESC";
        $rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

        $positions = [];

        foreach ($rows as $r) {
            $side = 'LONG';
            if (isset($r['is_short'])) {
                $side = intval($r['is_short']) === 1 ? 'SHORT' : 'LONG';
            }

            $positions[] = [
                'trade_id' => $r['trade_id'] ?? null,
                'id' => $r['trade_id'] ?? null,
                'pair' => $r['pair'] ?? '-',
                'side' => $side,
                'open_rate' => isset($r['open_rate']) ? floatval($r['open_rate']) : null,
                'entry' => isset($r['open_rate']) ? floatval($r['open_rate']) : null,
                'current_rate' => null,
                'current' => null,
                'amount' => isset($r['amount']) ? floatval($r['amount']) : null,
                'stake_amount' => isset($r['stake_amount']) ? floatval($r['stake_amount']) : null,
                'stake' => isset($r['stake_amount']) ? floatval($r['stake_amount']) : null,
                'profit_ratio' => null,
                'profit_pct' => null,
                'pnl' => null,
                'open_date' => $r['open_date'] ?? null,
                'opened' => $r['open_date'] ?? null
            ];
        }

        return ['ok' => true, 'positions' => $positions, 'open_trades' => count($positions), 'db_path' => $dbPath];

    } catch (Exception $e) {
        return ['ok' => false, 'error' => $e->getMessage(), 'positions' => [], 'open_trades' => 0, 'db_path' => $dbPath];
    }
}

function enrich_positions_with_profit($positions, $prices) {
    $total = 0.0;
    $count = 0;

    foreach ($positions as &$p) {
        $pair = $p['pair'] ?? '';
        $current = $prices[$pair] ?? null;
        $entry = $p['entry'] ?? $p['open_rate'] ?? null;

        if ($current !== null) {
            $p['current_rate'] = $current;
            $p['current'] = $current;
        }

        if ($current !== null && $entry && floatval($entry) > 0) {
            $entry = floatval($entry);
            $current = floatval($current);
            $side = strtoupper((string)($p['side'] ?? 'LONG'));

            if ($side === 'SHORT') {
                $ratio = ($entry - $current) / $entry;
            } else {
                $ratio = ($current - $entry) / $entry;
            }

            $p['profit_ratio'] = round($ratio, 6);
            $p['profit_pct'] = round($ratio * 100, 3);
            $p['pnl'] = round($ratio * 100, 3);

            $total += $ratio;
            $count++;
        }
    }

    return [$positions, $count ? round($total * 100, 3) : null];
}

function output($data) {
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/* Health */
$cache = read_json($cacheFile, ['online' => false, 'fail_count' => 0, 'last_success_at' => null, 'last_error_at' => null]);

$pingOk = http_ping($base . '/ping', 2);

if ($pingOk) {
    $cache['online'] = true;
    $cache['fail_count'] = 0;
    $cache['last_success_at'] = date('c');
} else {
    $cache['fail_count'] = intval($cache['fail_count'] ?? 0) + 1;
    $cache['last_error_at'] = date('c');
    if ($cache['fail_count'] >= 10) $cache['online'] = false;
}

write_json($cacheFile, $cache);

/* Positions + PnL */
$dbPath = resolve_db_path($root, $dbUrl);
$dbResult = read_positions_from_sqlite($dbPath);
$positions = $dbResult['positions'];

$prices = get_market_prices($positions, $priceCacheFile);
[$positions, $totalProfit] = enrich_positions_with_profit($positions, $prices);
$openTrades = count($positions);

$positionStateFile = $storage . DIRECTORY_SEPARATOR . 'position_state.json';
$positionState = read_json($positionStateFile, []);
if ($dbResult['ok']) {
    $positionState['open_positions'] = $positions;
    $positionState['summary'] = [
        'open_count' => $openTrades,
        'long_count' => count(array_filter($positions, fn($p) => ($p['side'] ?? '') === 'LONG')),
        'short_count' => count(array_filter($positions, fn($p) => ($p['side'] ?? '') === 'SHORT')),
        'profit_count' => count(array_filter($positions, fn($p) => ($p['profit_ratio'] ?? 0) > 0)),
        'drawdown_count' => count(array_filter($positions, fn($p) => ($p['profit_ratio'] ?? 0) < 0)),
        'danger_count' => 0,
        'exposure_state' => 'OK',
        'total_profit_pct' => $totalProfit
    ];
    $positionState['manager_status'] = $positionState['manager_status'] ?? 'CACHE';
    write_json($positionStateFile, $positionState);
}

output([
    'online' => boolval($cache['online']),
    'ok' => boolval($cache['online']),
    'message' => $cache['online'] ? 'Freqtrade API connected' : 'Freqtrade API offline',
    'base_url' => $base,
    'open_trades' => $openTrades,
    'open_count' => $openTrades,
    'count' => $openTrades,
    'profit' => $totalProfit,
    'total_profit' => $totalProfit,
    'total_profit_pct' => $totalProfit,
    'positions' => $positions,
    'trades' => $positions,
    'open_positions' => $positions,
    'fail_count' => intval($cache['fail_count'] ?? 0),
    'last_success_at' => $cache['last_success_at'] ?? null,
    'last_error_at' => $cache['last_error_at'] ?? null,
    'details' => [
        'health_mode' => 'ping_only',
        'status_endpoint_disabled' => true,
        'positions_source' => 'sqlite',
        'price_source' => 'binance_futures_public_ticker_cached',
        'db_ok' => $dbResult['ok'],
        'db_error' => $dbResult['error'] ?? null,
        'db_path' => $dbResult['db_path'],
        'prices' => $prices
    ]
]);
