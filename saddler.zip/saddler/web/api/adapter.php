<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$storage = realpath(__DIR__ . '/../../engine/storage');
if (!$storage) {
    $storage = __DIR__ . '/../../engine/storage';
    @mkdir($storage, 0777, true);
}

$configFile = $storage . DIRECTORY_SEPARATOR . 'adapter_config.json';
$stateFile = $storage . DIRECTORY_SEPARATOR . 'adapter_state.json';
$historyFile = $storage . DIRECTORY_SEPARATOR . 'execution_history.json';

function read_json($file, $default) {
    if (!file_exists($file)) return $default;
    $data = json_decode(file_get_contents($file), true);
    return is_array($data) ? $data : $default;
}

function write_json($file, $data) {
    $data['updated_at'] = date('c');
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
}

function out($data) {
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$action = $_GET['action'] ?? 'state';

$config = read_json($configFile, []);
$state = read_json($stateFile, []);
$history = read_json($historyFile, ['items'=>[]]);

if ($action === 'state') {
    out([
        'ok' => true,
        'config' => $config,
        'state' => $state,
        'history' => array_slice(array_reverse($history['items'] ?? []), 0, 50)
    ]);
}

if ($action === 'save_config') {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) out(['ok'=>false, 'error'=>'Invalid JSON']);

    foreach ($input as $key => $value) {
        if (is_bool($value) || is_numeric($value) || is_string($value)) {
            $config[$key] = $value;
        }
    }

    write_json($configFile, $config);
    out(['ok'=>true, 'config'=>$config]);
}

if ($action === 'enable') {
    $config['execution_enabled'] = true;
    write_json($configFile, $config);
    out(['ok'=>true, 'config'=>$config]);
}

if ($action === 'disable') {
    $config['execution_enabled'] = false;
    write_json($configFile, $config);
    out(['ok'=>true, 'config'=>$config]);
}

out(['ok'=>false, 'error'=>'Unknown action']);
