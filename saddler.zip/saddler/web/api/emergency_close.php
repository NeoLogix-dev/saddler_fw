<?php

header('Content-Type: application/json');

set_time_limit(0);

$data = json_decode(
    file_get_contents("php://input"),
    true
);

$tradeId = $data["trade_id"] ?? null;

if (!$tradeId) {

    echo json_encode([
        "success" => false,
        "error" => "missing trade id"
    ]);

    exit;
}

$payload = json_encode([
    "tradeid" => intval($tradeId)
]);

$url = "http://127.0.0.1:8080/api/v1/forceexit";

$ch = curl_init($url);

curl_setopt(
    $ch,
    CURLOPT_RETURNTRANSFER,
    true
);

curl_setopt(
    $ch,
    CURLOPT_POST,
    true
);

curl_setopt(
    $ch,
    CURLOPT_USERPWD,
    "newtrade:newtrade123"
);

/*
PROMIJENI GORE:
"freqtrade:freqtrade"

u svoj:
username:password
*/

curl_setopt(
    $ch,
    CURLOPT_HTTPHEADER,
    [
        "Content-Type: application/json"
    ]
);

curl_setopt(
    $ch,
    CURLOPT_POSTFIELDS,
    $payload
);

$response = null;

for ($i = 0; $i < 3; $i++) {

    $response = curl_exec($ch);

    if ($response) {
        break;
    }

    usleep(300000);
}

$error = curl_error($ch);

curl_close($ch);

file_put_contents(
    "manual_close_debug.txt",
    print_r(
        [
            "trade_id" => $tradeId,
            "payload" => $payload,
            "response" => $response,
            "error" => $error
        ],
        true
    )
);

echo json_encode([
    "success" => $error ? false : true,
    "response" => $response,
    "error" => $error
]);