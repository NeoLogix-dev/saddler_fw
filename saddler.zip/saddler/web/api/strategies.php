<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$strategyDir = realpath(__DIR__ . '/../../freqtrade/user_data/strategies');
if (!$strategyDir) { $strategyDir = __DIR__ . '/../../freqtrade/user_data/strategies'; @mkdir($strategyDir, 0777, true); }
$stateDir = realpath(__DIR__ . '/../../engine/storage');
if (!$stateDir) { $stateDir = __DIR__ . '/../../engine/storage'; @mkdir($stateDir, 0777, true); }
$stateFile = $stateDir . DIRECTORY_SEPARATOR . 'strategy_state.json';

function out($d){ echo json_encode($d, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT); exit; }
function valid_file($f){ return preg_match('/^[A-Za-z_][A-Za-z0-9_]*\.py$/', $f); }
function cls($code,$file){ if(preg_match('/class\s+([A-Za-z_][A-Za-z0-9_]*)\s*[\(:]/',$code,$m)) return $m[1]; return preg_replace('/\.py$/','',$file); }
function state($file){ $d=["active_strategy"=>null,"active_file"=>null,"last_action"=>null,"updated_at"=>null]; if(file_exists($file)){ $j=json_decode(file_get_contents($file),true); if(is_array($j)) $d=array_merge($d,$j); } return $d; }
function write_state($file,$s){ $s["updated_at"]=date('c'); file_put_contents($file,json_encode($s,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES)); }

$action = $_GET['action'] ?? 'list';
$st = state($stateFile);

if($action==='list'){
  $items=[];
  foreach(glob($strategyDir.DIRECTORY_SEPARATOR.'*.py') as $p){
    $file=basename($p); $code=file_get_contents($p); $class=cls($code,$file);
    $items[]=["strategy"=>$class,"file"=>$file,"active"=>($st["active_file"]===$file || $st["active_strategy"]===$class),"modified"=>date('Y-m-d H:i:s',filemtime($p)),"size"=>filesize($p)];
  }
  usort($items, fn($a,$b)=>strcmp($a["strategy"],$b["strategy"]));
  out(["ok"=>true,"state"=>$st,"strategies"=>$items]);
}

if($action==='read'){
  $file=$_GET['file']??''; if(!valid_file($file)) out(["ok"=>false,"error"=>"Invalid file"]);
  $p=$strategyDir.DIRECTORY_SEPARATOR.$file; if(!file_exists($p)) out(["ok"=>false,"error"=>"Strategy not found"]);
  $code=file_get_contents($p); out(["ok"=>true,"file"=>$file,"strategy"=>cls($code,$file),"code"=>$code]);
}

if($action==='template'){
  $name=$_GET['name']??'NewTradeCustomStrategy'; $name=preg_replace('/[^A-Za-z0-9_]/','',$name); if(!$name)$name='NewTradeCustomStrategy';
  $code="from freqtrade.strategy import IStrategy\nfrom pandas import DataFrame\nimport talib.abstract as ta\n\n\nclass {$name}(IStrategy):\n    timeframe = '5m'\n    can_short = True\n\n    minimal_roi = {'0': 0.012, '30': 0.006, '90': 0}\n    stoploss = -0.018\n    trailing_stop = True\n    trailing_stop_positive = 0.006\n    trailing_stop_positive_offset = 0.012\n    trailing_only_offset_is_reached = True\n    startup_candle_count = 50\n    process_only_new_candles = True\n\n    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:\n        dataframe['ema_fast'] = ta.EMA(dataframe, timeperiod=12)\n        dataframe['ema_slow'] = ta.EMA(dataframe, timeperiod=26)\n        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)\n        return dataframe\n\n    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:\n        dataframe.loc[(dataframe['ema_fast'] > dataframe['ema_slow']) & (dataframe['rsi'] > 50) & (dataframe['volume'] > 0), ['enter_long', 'enter_tag']] = (1, 'custom_long')\n        dataframe.loc[(dataframe['ema_fast'] < dataframe['ema_slow']) & (dataframe['rsi'] < 45) & (dataframe['volume'] > 0), ['enter_short', 'enter_tag']] = (1, 'custom_short')\n        return dataframe\n\n    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:\n        dataframe.loc[(dataframe['ema_fast'] < dataframe['ema_slow']) | (dataframe['rsi'] < 42), ['exit_long', 'exit_tag']] = (1, 'exit_long_signal')\n        dataframe.loc[(dataframe['ema_fast'] > dataframe['ema_slow']) | (dataframe['rsi'] > 58), ['exit_short', 'exit_tag']] = (1, 'exit_short_signal')\n        return dataframe\n";
  out(["ok"=>true,"file"=>$name.".py","strategy"=>$name,"code"=>$code]);
}

if($action==='save'){
  $in=json_decode(file_get_contents('php://input'),true); if(!is_array($in)) out(["ok"=>false,"error"=>"Invalid JSON"]);
  $file=$in['file']??''; $code=$in['code']??''; if(!valid_file($file)) out(["ok"=>false,"error"=>"Invalid filename"]); if(trim($code)==='') out(["ok"=>false,"error"=>"Empty code"]);
  if(stripos($code,'class ')===false || stripos($code,'IStrategy')===false) out(["ok"=>false,"error"=>"Strategy must contain class and IStrategy"]);
  $p=$strategyDir.DIRECTORY_SEPARATOR.$file; if(file_exists($p)) @copy($p,$p.'.bak_'.date('Ymd_His'));
  file_put_contents($p,$code); out(["ok"=>true,"file"=>$file,"strategy"=>cls($code,$file),"message"=>"Saved"]);
}

if($action==='delete'){
  $in=json_decode(file_get_contents('php://input'),true); $file=$in['file']??''; if(!valid_file($file)) out(["ok"=>false,"error"=>"Invalid file"]);
  if($st["active_file"]===$file) out(["ok"=>false,"error"=>"Cannot delete active strategy"]);
  $p=$strategyDir.DIRECTORY_SEPARATOR.$file; if(!file_exists($p)) out(["ok"=>false,"error"=>"Strategy not found"]);
  rename($p,$p.'.deleted_'.date('Ymd_His')); out(["ok"=>true,"message"=>"Deleted"]);
}

if($action==='run'){
  $in=json_decode(file_get_contents('php://input'),true); $file=$in['file']??''; if(!valid_file($file)) out(["ok"=>false,"error"=>"Invalid file"]);
  $p=$strategyDir.DIRECTORY_SEPARATOR.$file; if(!file_exists($p)) out(["ok"=>false,"error"=>"Strategy not found"]);
  $code=file_get_contents($p); $strategy=cls($code,$file);
  $st["active_strategy"]=$strategy; $st["active_file"]=$file; $st["last_action"]="run_requested"; write_state($stateFile,$st);
  $projectRoot=realpath(__DIR__.'/../..'); $bat=$projectRoot.DIRECTORY_SEPARATOR.'scripts'.DIRECTORY_SEPARATOR.'run_freqtrade_strategy.bat'; @mkdir(dirname($bat),0777,true);
  $batContent="@echo off\r\ncd /d ".$projectRoot."\\freqtrade\r\ncall ..\\engine\\.venv\\Scripts\\activate.bat\r\nfreqtrade trade --config user_data\\config.json --strategy ".$strategy."\r\npause\r\n";
  file_put_contents($bat,$batContent);
  @pclose(@popen('start "NewTrade Freqtrade" /MIN "'.$bat.'"','r'));
  out(["ok"=>true,"message"=>"Run requested","strategy"=>$strategy,"file"=>$file,"bat"=>"scripts/run_freqtrade_strategy.bat","note"=>"Ako Apache ne može startovati proces, pokreni BAT ručno."]);
}

out(["ok"=>false,"error"=>"Unknown action"]);
