<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$storage = realpath(__DIR__ . '/../../engine/storage');
if (!$storage) {
    $storage = __DIR__ . '/../../engine/storage';
    @mkdir($storage, 0777, true);
}

$stateFile = $storage . DIRECTORY_SEPARATOR . 'position_state.json';
$configFile = $storage . DIRECTORY_SEPARATOR . 'position_config.json';
$eventsFile = $storage . DIRECTORY_SEPARATOR . 'position_events.json';

function read_json($file, $default) {
    if (!file_exists($file)) return $default;
    $data = json_decode(file_get_contents($file), true);
    return is_array($data) ? $data : $default;
}

function write_json($file, $data) {
    $data['updated_at'] = date('c');
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
}

function out($data) {
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$action = $_GET['action'] ?? 'state';

$state = read_json($stateFile, []);
$config = read_json($configFile, []);
$events = read_json($eventsFile, ['events'=>[]]);

if ($action === 'state') {
    out([
        'ok' => true,
        'state' => $state,
        'config' => $config,
        'events' => array_slice(array_reverse($events['events'] ?? []), 0, 100)
    ]);
}

if ($action === 'save_config') {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) out(['ok'=>false, 'error'=>'Invalid JSON']);

    foreach ($input as $key => $value) {
        if (is_bool($value) || is_numeric($value)) {
            $config[$key] = $value;
        }
    }

    write_json($configFile, $config);
    out(['ok'=>true, 'config'=>$config]);
}

if ($action === 'enable') {
    $config['manager_enabled'] = true;
    write_json($configFile, $config);
    out(['ok'=>true, 'config'=>$config]);
}

if ($action === 'disable') {
    $config['manager_enabled'] = false;
    write_json($configFile, $config);
    out(['ok'=>true, 'config'=>$config]);
}

out(['ok'=>false, 'error'=>'Unknown action']);
