<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$file = realpath(__DIR__ . '/../../engine/storage');
if (!$file) {
    $file = __DIR__ . '/../../engine/storage';
    @mkdir($file, 0777, true);
}
$settingsFile = $file . DIRECTORY_SEPARATOR . 'settings.json';

$default = [
    "live" => false,
    "auto" => false,
    "updated_at" => date('c')
];

function read_settings($settingsFile, $default) {
    if (!file_exists($settingsFile)) {
        file_put_contents($settingsFile, json_encode($default, JSON_PRETTY_PRINT));
        return $default;
    }
    $raw = file_get_contents($settingsFile);
    $data = json_decode($raw, true);
    if (!is_array($data)) return $default;
    return array_merge($default, $data);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $current = read_settings($settingsFile, $default);

    if (isset($input['live'])) $current['live'] = (bool)$input['live'];
    if (isset($input['auto'])) $current['auto'] = (bool)$input['auto'];

    $current['updated_at'] = date('c');
    file_put_contents($settingsFile, json_encode($current, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    echo json_encode($current);
    exit;
}

echo json_encode(read_settings($settingsFile, $default));
