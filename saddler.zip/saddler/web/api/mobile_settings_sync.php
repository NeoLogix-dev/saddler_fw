<?php
header('Content-Type: application/json');

$file =
    realpath(__DIR__ .
    '/../../engine/storage/system_settings.json');

if (!$file || !file_exists($file)) {

    echo json_encode([
        'ok' => false,
        'error' => 'Settings not found'
    ]);

    exit;
}

$data =
    json_decode(
        file_get_contents($file),
        true
    );

echo json_encode([
    'ok' => true,
    'settings' => $data
]);
