<?php
header('Content-Type: application/json; charset=utf-8');

$file = realpath(__DIR__ . '/../../engine/storage/system_settings.json');

if (!$file || !file_exists($file)) {
    echo json_encode([
        'ok' => false,
        'error' => 'Settings file missing'
    ]);
    exit;
}

echo file_get_contents($file);
