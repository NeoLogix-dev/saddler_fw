<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$storage = realpath(__DIR__ . '/../../engine/storage');
if (!$storage) {
    $storage = __DIR__ . '/../../engine/storage';
    @mkdir($storage, 0777, true);
}

$stateFile = $storage . DIRECTORY_SEPARATOR . 'supervisor_state.json';
$configFile = $storage . DIRECTORY_SEPARATOR . 'supervisor_config.json';

function read_json($file, $default) {
    if (!file_exists($file)) return $default;
    $data = json_decode(file_get_contents($file), true);
    return is_array($data) ? $data : $default;
}

function write_json($file, $data) {
    $data['updated_at'] = date('c');
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
}

function out($data) {
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$defaultConfig = [
    'restart_delay_seconds' => 3,
    'services' => [
        'signal_engine' => ['enabled'=>true, 'restart'=>true],
        'execution_daemon' => ['enabled'=>true, 'restart'=>true],
        'execution_adapter' => ['enabled'=>true, 'restart'=>true],
        'position_manager' => ['enabled'=>true, 'restart'=>true],
        'position_executor' => ['enabled'=>true, 'restart'=>true],
    ]
];

$action = $_GET['action'] ?? 'state';

$state = read_json($stateFile, ['supervisor_status'=>'OFFLINE', 'services'=>[]]);
$config = read_json($configFile, $defaultConfig);

if ($action === 'state') {
    out(['ok'=>true, 'state'=>$state, 'config'=>$config]);
}

if ($action === 'save_config') {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) out(['ok'=>false, 'error'=>'Invalid JSON']);

    foreach (($input['services'] ?? []) as $key => $svc) {
        if (!isset($config['services'][$key])) $config['services'][$key] = ['enabled'=>true, 'restart'=>true];
        if (isset($svc['enabled'])) $config['services'][$key]['enabled'] = (bool)$svc['enabled'];
        if (isset($svc['restart'])) $config['services'][$key]['restart'] = (bool)$svc['restart'];
    }

    if (isset($input['restart_delay_seconds'])) {
        $config['restart_delay_seconds'] = (int)$input['restart_delay_seconds'];
    }

    write_json($configFile, $config);
    out(['ok'=>true, 'config'=>$config]);
}

out(['ok'=>false, 'error'=>'Unknown action']);
