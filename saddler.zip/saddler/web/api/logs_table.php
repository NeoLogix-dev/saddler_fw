<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
$file = realpath(__DIR__ . '/../../engine/logs/engine.log');
if (!$file || !file_exists($file)) { echo json_encode(["logs" => []]); exit; }
$lines = file($file, FILE_IGNORE_NEW_LINES);
$rows = [];
foreach ($lines as $line) {
    $time = '';
    $message = $line;
    $level = 'INFO';
    if (preg_match('/^\[(.*?)\]\s*(.*)$/', $line, $m)) { $time = $m[1]; $message = $m[2]; }
    if (stripos($message, 'error') !== false) $level = 'ERROR';
    elseif (stripos($message, 'warning') !== false || stripos($message, 'risk') !== false) $level = 'WARN';
    $rows[] = ["time"=>$time, "message"=>$message, "level"=>$level];
}
echo json_encode(["logs" => array_reverse($rows)], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
