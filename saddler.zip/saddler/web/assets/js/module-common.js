function initModuleShell(activeName){
 const app=document.getElementById('appRoot'),btn=document.getElementById('collapseBtn');
 if(localStorage.getItem('newtrade_sidebar')==='collapsed') app.classList.add('sidebar-collapsed');
 if(btn){btn.addEventListener('click',()=>{app.classList.toggle('sidebar-collapsed');localStorage.setItem('newtrade_sidebar',app.classList.contains('sidebar-collapsed')?'collapsed':'open');});}
 document.querySelectorAll('.side-nav a').forEach(a=>{a.classList.toggle('active',a.dataset.section===activeName);});
}
async function getJson(url){const r=await fetch(url+'?t='+Date.now(),{cache:'no-store'});return await r.json();}
function bindTableSearch(inputId, tableSelector){const input=document.getElementById(inputId);if(!input)return;input.addEventListener('input',()=>{const q=input.value.toLowerCase();document.querySelectorAll(tableSelector+' tr').forEach(tr=>{tr.style.display=tr.textContent.toLowerCase().includes(q)?'':'none';});});}
async function updateFreqtradeHeader(){try{const data=await getJson('../api/freqtrade.php');const el=document.getElementById('freqHeaderState');if(!el)return;el.innerHTML=`<span class="dot"></span>${data.online?'FREQTRADE ONLINE':'FREQTRADE OFFLINE'}`;el.className='badge '+(data.online?'green':'red');}catch(e){const el=document.getElementById('freqHeaderState');if(el){el.innerHTML='<span class="dot"></span>FREQTRADE OFFLINE';el.className='badge red';}}}
async function updateEngineHeader(){try{const data=await getJson('../api/signals.php');const el=document.getElementById('engineHeaderState');if(!el)return;const hasSignals=data.signals&&data.signals.length>0;el.innerHTML=`<span class="dot"></span>${hasSignals?'RUNNING':'ENGINE OFF'}`;el.className='badge '+(hasSignals?'green':'red');}catch(e){const el=document.getElementById('engineHeaderState');if(el){el.innerHTML='<span class="dot"></span>ENGINE OFF';el.className='badge red';}}}
setInterval(updateFreqtradeHeader,2000);updateFreqtradeHeader();setInterval(updateEngineHeader,2000);updateEngineHeader();
