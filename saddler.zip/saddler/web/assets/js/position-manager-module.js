document.addEventListener('DOMContentLoaded', () => {
    initModuleShell('position_manager');
    bindTableSearch('pmSearch', '#pmPositions');
    bindTableSearch('pmEventSearch', '#pmEvents');

    const pmSwitch = document.getElementById('pmHeaderSwitch');
    if(pmSwitch){
        pmSwitch.addEventListener('change', async () => {
            if(pmSwitch.checked){
                await pmApi('enable', {});
            }else{
                await pmApi('disable', {});
            }
            cfgLoaded = false;
            loadPositionManager();
        });
    }

    loadPositionManager();
    setInterval(loadPositionManager, 3000);
});

async function pmApi(action='state', body=null){
    const options = body ? {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)} : {cache:'no-store'};
    const r = await fetch('../api/positions_manager.php?action=' + encodeURIComponent(action) + '&t=' + Date.now(), options);
    return await r.json();
}

let cfgLoaded = false;

function pill(icon, label, cls){
    return `<span class="pm-pill ${cls}"><span class="material-icons">${icon}</span><span>${label}</span></span>`;
}

function lifecyclePill(v){
    v = String(v || '').toUpperCase();
    const map = {
        'OPEN': ['radio_button_checked','OPEN','pm-info'],
        'PROFIT': ['trending_up','PROFIT','pm-good'],
        'BREAKEVEN': ['balance','BREAKEVEN','pm-good'],
        'TRAILING': ['moving','TRAILING','pm-good'],
        'AGGRESSIVE_TRAILING': ['rocket_launch','AGGRESSIVE','pm-good'],
        'RECOVERY': ['healing','RECOVERY','pm-warn'],
        'DANGER': ['warning','DANGER','pm-bad'],
        'CRITICAL': ['report','CRITICAL','pm-bad']
    };
    const m = map[v] || ['help_outline', v || '-', 'pm-neutral'];
    return pill(m[0], m[1], m[2]);
}

function actionPill(v){
    v = String(v || '').toUpperCase();
    if(v.includes('EMERGENCY')) return pill('warning','EMERGENCY','pm-bad');
    if(v.includes('REDUCE')) return pill('call_split','REDUCE','pm-warn');
    if(v.includes('TRAIL')) return pill('moving','TRAIL','pm-good');
    if(v.includes('BREAKEVEN')) return pill('balance','BREAKEVEN','pm-good');
    if(v.includes('WATCH')) return pill('visibility','WATCH','pm-warn');
    return pill('pause_circle','HOLD','pm-neutral');
}

function updatePmHeaderSwitch(enabled){
    const sw = document.getElementById('pmHeaderSwitch');
    const label = document.getElementById('pmHeaderLabel');

    if(!sw || !label) return;

    sw.checked = !!enabled;

    if(enabled){
        label.textContent = 'PM ON';
        label.style.color = '#19e68c';
    }else{
        label.textContent = 'PM OFF';
        label.style.color = '#8fa3c2';
    }
}

async function loadPositionManager(){
    try{
        const data = await pmApi('state');
        const state = data.state || {};
        const config = data.config || {};
        const s = state.summary || {};

        updatePmHeaderSwitch(!!config.manager_enabled);

        document.getElementById('pmStatus').textContent = state.manager_status || '--';
        document.getElementById('pmOpen').textContent = s.open_count ?? '--';
        document.getElementById('pmProfit').textContent = s.profit_count ?? '--';
        document.getElementById('pmDrawdown').textContent = s.drawdown_count ?? '--';
        document.getElementById('pmDanger').textContent = s.danger_count ?? '--';
        document.getElementById('pmLong').textContent = s.long_count ?? '--';
        document.getElementById('pmShort').textContent = s.short_count ?? '--';
        document.getElementById('pmExposure').textContent = s.exposure_state || '--';

        if(!cfgLoaded){
            fillConfig(config);
            cfgLoaded = true;
        }

        renderPositions(state.open_positions || []);
        renderEvents(data.events || []);
    }catch(e){
        console.error(e);
    }
}

function renderPositions(items){
    const body = document.getElementById('pmPositions');
    body.innerHTML = '';

    if(!items.length){
        body.innerHTML = '<tr><td colspan="10">No open positions.</td></tr>';
        return;
    }

    items.forEach(p => {
        const pnlClass = p.profit_ratio >= 0 ? 'long' : 'short';
        const tp = p.tp_ladder || {};
        const tpText = `TP1 ${tp.tp1?.hit ? '✓' : '-'} / TP2 ${tp.tp2?.hit ? '✓' : '-'}`;

        body.innerHTML += `
            <tr>
                <td><b>${p.pair || '-'}</b></td>
                <td class="${String(p.side || '').toLowerCase()}">${p.side || '-'}</td>
                <td class="${pnlClass}">${p.profit_pct ?? '-'}%</td>
                <td>${lifecyclePill(p.lifecycle)}</td>
                <td>${p.dynamic_sl || '-'}</td>
                <td>${tpText}</td>
                <td>${p.recovery || '-'}</td>
                <td>${actionPill(p.suggested_action)}</td>
                <td>${p.signal_score ?? '-'} / ${p.signal_risk ?? '-'}</td>
                <td>${formatTime(p.open_date)}</td>
            </tr>
        `;
    });
}

function renderEvents(events){
    const body = document.getElementById('pmEvents');
    body.innerHTML = '';

    if(!events.length){
        body.innerHTML = '<tr><td colspan="5">No position events.</td></tr>';
        return;
    }

    events.forEach(e => {
        body.innerHTML += `
            <tr>
                <td>${formatTime(e.time)}</td>
                <td><b>${e.pair || '-'}</b></td>
                <td>${e.type || '-'}</td>
                <td>${e.reason || '-'}</td>
                <td>${actionPill(e.action)}</td>
            </tr>
        `;
    });
}

function fillConfig(cfg){
    const bools = [
        'breakeven_enabled','trailing_enabled','partial_tp_enabled',
        'emergency_exit_enabled','exit_on_critical_drawdown','exit_on_low_quality'
    ];

    bools.forEach(k => {
        const el = document.getElementById('cfg_' + k);
        if(el) el.checked = !!cfg[k];
    });

    const nums = [
        'breakeven_profit','trailing_start','trailing_aggressive_start',
        'medium_drawdown','high_drawdown','critical_drawdown'
    ];

    nums.forEach(k => {
        const el = document.getElementById('cfg_' + k);
        if(el && cfg[k] !== undefined) el.value = cfg[k];
    });
}

function readConfig(){
    const payload = {};

    ['breakeven_enabled','trailing_enabled','partial_tp_enabled','emergency_exit_enabled','exit_on_critical_drawdown','exit_on_low_quality'].forEach(k => {
        const el = document.getElementById('cfg_' + k);
        if(el) payload[k] = el.checked;
    });

    ['breakeven_profit','trailing_start','trailing_aggressive_start','medium_drawdown','high_drawdown','critical_drawdown'].forEach(k => {
        const el = document.getElementById('cfg_' + k);
        if(el) payload[k] = parseFloat(el.value);
    });

    return payload;
}

async function saveManagerConfig(){
    const res = await pmApi('save_config', readConfig());
    alert(res.ok ? 'Position manager config saved.' : 'Save error.');
    cfgLoaded = false;
    loadPositionManager();
}

async function enableManager(){
    await pmApi('enable', {});
    cfgLoaded = false;
    loadPositionManager();
}

async function disableManager(){
    await pmApi('disable', {});
    cfgLoaded = false;
    loadPositionManager();
}

function formatTime(value){
    if(!value) return '-';
    try{
        const d = new Date(value);
        if(Number.isNaN(d.getTime())) return value;
        return d.toLocaleString();
    }catch(e){ return value; }
}
