document.addEventListener('DOMContentLoaded', () => {
    initModuleShell('orchestrator');
    loadOrchestrator();
    setInterval(loadOrchestrator, 3000);
});

async function orcApi(action, body=null){
    const options = body ? {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify(body)
    } : {cache:'no-store'};

    const r = await fetch('../api/orchestrator.php?action=' + encodeURIComponent(action) + '&t=' + Date.now(), options);
    return await r.json();
}

async function loadOrchestrator(){
    try{
        const data = await orcApi('state');
        const s = data.settings || {};
        const st = data.strategy || {};
        const gate = data.decision_gate || {};

        document.getElementById('orcFreqtrade').textContent = data.freqtrade_online ? 'ONLINE' : 'OFFLINE';
        document.getElementById('orcStrategy').textContent = st.active_strategy || '-';
        document.getElementById('orcMode').textContent = s.live ? 'LIVE' : 'PAPER';
        document.getElementById('orcAuto').textContent = s.auto ? 'AUTO ON' : 'AUTO OFF';

        document.getElementById('decisionGate').innerHTML = `
            <div><b>Best pair:</b> ${gate.best_pair || '-'}</div>
            <div><b>Best action:</b> ${gate.best_action || '-'}</div>
            <div><b>Score:</b> ${gate.score ?? '-'}</div>
            <div><b>Risk:</b> ${gate.risk ?? '-'}</div>
            <div><b>Allowed:</b> ${gate.allowed ? 'YES' : 'NO'}</div>
            <div><b>Auto can execute:</b> ${gate.can_execute_auto ? 'YES' : 'NO'}</div>
            <div><b>Reason:</b> ${gate.reason || '-'}</div>
        `;

        document.getElementById('stateBox').textContent = JSON.stringify(data, null, 2);

        const body = document.getElementById('commandsTable');
        const commands = data.commands || [];
        body.innerHTML = '';

        if(!commands.length){
            body.innerHTML = '<tr><td colspan="4">No commands yet.</td></tr>';
            return;
        }

        commands.forEach(c => {
            body.innerHTML += `
                <tr>
                    <td>${c.time || '-'}</td>
                    <td>${c.command || '-'}</td>
                    <td>${c.status || '-'}</td>
                    <td>${c.message || '-'}</td>
                </tr>
            `;
        });

    }catch(e){
        console.error(e);
    }
}

async function sendCommand(command){
    if(!confirm('Send command: ' + command + '?')) return;
    const res = await orcApi('command', {command});
    if(!res.ok){
        alert('Error: ' + res.error);
        return;
    }
    loadOrchestrator();
}
