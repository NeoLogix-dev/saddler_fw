// NewTrade global sidebar fix.
// Ensures Strategies link exists in dashboard and all modules.

document.addEventListener('DOMContentLoaded', () => {
    const nav = document.querySelector('.side-nav');
    if (!nav) return;

    const isModule = window.location.pathname.includes('/modules/');
    const prefix = isModule ? '' : 'modules/';
    const dashboardHref = isModule ? '../index.php' : 'index.php';

    const items = [
        {section:'dashboard', icon:'dashboard', label:'Dashboard', href:dashboardHref},
        {section:'signals', icon:'stacked_line_chart', label:'Signals', href:prefix + 'signals.php'},
        {section:'strategies', icon:'account_tree', label:'Strategies', href:prefix + 'strategies.php'},
        {section:'risk', icon:'shield', label:'Risk', href:prefix + 'risk.php'},
        {section:'positions', icon:'show_chart', label:'Positions', href:prefix + 'positions.php'},
        {section:'agents', icon:'psychology', label:'Agents', href:prefix + 'agents.php'},
        {section:'logs', icon:'terminal', label:'Logs', href:prefix + 'logs.php'}
    ];

    const current = window.location.pathname.toLowerCase();
    nav.innerHTML = items.map(item => {
        let active = '';
        if (item.section === 'dashboard' && current.endsWith('/web/index.php')) active = 'active';
        if (item.section !== 'dashboard' && current.includes('/' + item.section + '.php')) active = 'active';
        if (item.section === 'strategies' && current.includes('strategy_editor.php')) active = 'active';

        return `
            <a href="${item.href}" data-section="${item.section}" class="${active}">
                <span class="material-icons">${item.icon}</span>
                <span class="nav-label">${item.label}</span>
            </a>
        `;
    }).join('');
});
