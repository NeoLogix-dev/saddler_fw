// Functional NewTrade header switches.
// Persists to web/api/settings.php so dashboard and modules share same state.

(function(){
    function apiBase(){
        const isModule = window.location.pathname.includes('/modules/');
        return isModule ? '../api/settings.php' : 'api/settings.php';
    }

    async function loadSettings(){
        const r = await fetch(apiBase() + '?t=' + Date.now(), {cache:'no-store'});
        return await r.json();
    }

    async function saveSettings(payload){
        const r = await fetch(apiBase(), {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify(payload)
        });
        return await r.json();
    }

    function setLabels(liveSwitch, liveLabel, autoSwitch, autoLabel){
        if(liveSwitch && liveLabel){
            if(liveSwitch.checked){
                liveLabel.textContent = 'LIVE';
                liveLabel.style.color = '#19e68c';
            }else{
                liveLabel.textContent = 'PAPER';
                liveLabel.style.color = '#8fa3c2';
            }
        }

        if(autoSwitch && autoLabel){
            if(autoSwitch.checked){
                autoLabel.textContent = 'AUTO ON';
                autoLabel.style.color = '#19e68c';
            }else{
                autoLabel.textContent = 'AUTO OFF';
                autoLabel.style.color = '#8fa3c2';
            }
        }
    }

    async function initHeaderSwitches(){
        const liveSwitch = document.getElementById('liveSwitch');
        const liveLabel = document.getElementById('liveLabel');
        const autoSwitch = document.getElementById('autoSwitch');
        const autoLabel = document.getElementById('autoLabel');

        if(!liveSwitch && !autoSwitch) return;

        try{
            const s = await loadSettings();
            if(liveSwitch) liveSwitch.checked = !!s.live;
            if(autoSwitch) autoSwitch.checked = !!s.auto;
        }catch(e){
            console.warn('Settings API unavailable, using local switch state.', e);
        }

        setLabels(liveSwitch, liveLabel, autoSwitch, autoLabel);

        if(liveSwitch){
            liveSwitch.addEventListener('change', async () => {
                setLabels(liveSwitch, liveLabel, autoSwitch, autoLabel);
                await saveSettings({live: liveSwitch.checked});
            });
        }

        if(autoSwitch){
            autoSwitch.addEventListener('change', async () => {
                setLabels(liveSwitch, liveLabel, autoSwitch, autoLabel);
                await saveSettings({auto: autoSwitch.checked});
            });
        }
    }

    document.addEventListener('DOMContentLoaded', initHeaderSwitches);
})();
