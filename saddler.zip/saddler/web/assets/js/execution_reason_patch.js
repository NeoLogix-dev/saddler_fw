function reasonMeta(reason){
    const r = String(reason || '').toUpperCase();

    const map = {
        'ACTION_NOT_ENTER': {
            icon:'pause_circle',
            label:'WAIT',
            cls:'reason-neutral'
        },
        'AUTO_OFF': {
            icon:'toggle_off',
            label:'AUTO OFF',
            cls:'reason-warning'
        },
        'EXECUTION_ALLOWED': {
            icon:'verified',
            label:'ALLOWED',
            cls:'reason-success'
        },
        'ORDERFLOW_CONFIRMATION_NEEDED': {
            icon:'water_drop',
            label:'ORDERFLOW',
            cls:'reason-warning'
        },
        'RISK_SCORE_LOW': {
            icon:'shield',
            label:'RISK LOW',
            cls:'reason-danger'
        },
        'FUNDING_RISK': {
            icon:'paid',
            label:'FUNDING',
            cls:'reason-danger'
        },
        'COOLDOWN_ACTIVE': {
            icon:'timer',
            label:'COOLDOWN',
            cls:'reason-info'
        },
        'MANUAL_CANCEL': {
            icon:'close',
            label:'CANCELLED',
            cls:'reason-danger'
        },
        'SIGNAL_EXPIRED': {
            icon:'schedule',
            label:'EXPIRED',
            cls:'reason-neutral'
        },
        'SIDE_NOT_VALID': {
            icon:'swap_horiz',
            label:'SIDE',
            cls:'reason-warning'
        },
        'SCORE_LOW': {
            icon:'speed',
            label:'LOW SCORE',
            cls:'reason-warning'
        },
        'CONFIDENCE_LOW': {
            icon:'psychology',
            label:'LOW CONF',
            cls:'reason-warning'
        },
        'RISK_NOT_ALLOWED': {
            icon:'block',
            label:'BLOCKED',
            cls:'reason-danger'
        },
        'QUICK_COOLDOWN': {
            icon:'timer',
            label:'QUICK CD',
            cls:'reason-info'
        },
        'MANUAL_COOLDOWN': {
            icon:'timer',
            label:'MANUAL CD',
            cls:'reason-info'
        }
    };

    return map[r] || {
        icon:'info',
        label:r || '-',
        cls:'reason-neutral'
    };
}

function reasonPill(reason){
    const m = reasonMeta(reason);

    return `
        <span class="reason-pill ${m.cls}">
            <span class="material-icons">${m.icon}</span>
            <span>${m.label}</span>
        </span>
    `;
}
