document.addEventListener('DOMContentLoaded', () => {
    initModuleShell('adapter');
    bindTableSearch('adapterHistorySearch', '#adapterHistory');

    const adapterSwitch = document.getElementById('adapterHeaderSwitch');
    if(adapterSwitch){
        adapterSwitch.addEventListener('change', async () => {
            if(adapterSwitch.checked){
                await adapterApi('enable', {});
            }else{
                await adapterApi('disable', {});
            }
            configLoaded = false;
            loadAdapter();
        });
    }

    loadAdapter();
    setInterval(loadAdapter, 2000);
});

async function adapterApi(action='state', body=null){
    const options = body ? {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify(body)
    } : {cache:'no-store'};

    const r = await fetch('../api/adapter.php?action=' + encodeURIComponent(action) + '&t=' + Date.now(), options);
    return await r.json();
}

let configLoaded = false;

function updateAdapterHeaderSwitch(enabled){
    const sw = document.getElementById('adapterHeaderSwitch');
    const label = document.getElementById('adapterHeaderLabel');

    if(!sw || !label) return;

    sw.checked = !!enabled;

    if(enabled){
        label.textContent = 'ADAPTER ON';
        label.style.color = '#19e68c';
    }else{
        label.textContent = 'ADAPTER OFF';
        label.style.color = '#8fa3c2';
    }
}

async function loadAdapter(){
    const data = await adapterApi('state');
    const state = data.state || {};
    const config = data.config || {};

    updateAdapterHeaderSwitch(!!config.execution_enabled);

    document.getElementById('adapterStatus').textContent = state.adapter_status || '--';
    document.getElementById('adapterFreqtrade').textContent = state.freqtrade_online ? 'ONLINE' : 'OFFLINE';
    document.getElementById('adapterEnabled').textContent = config.execution_enabled ? 'YES' : 'NO';
    document.getElementById('adapterOpenTrades').textContent = state.open_trades_count ?? '--';

    document.getElementById('adapterLast').textContent = JSON.stringify({
        last_entry: state.last_entry || null,
        last_exit: state.last_exit || null
    }, null, 2);

    document.getElementById('adapterError').textContent = JSON.stringify(state.last_error || null, null, 2);

    if(!configLoaded){
        fillConfig(config);
        configLoaded = true;
    }

    renderHistory(data.history || []);
}

function fillConfig(config){
    const boolKeys = [
        'force_entry_enabled',
        'force_exit_enabled',
        'paper_execution_enabled',
        'live_execution_enabled',
        'exit_on_blocked_pair',
        'exit_profit_guard_enabled'
    ];

    boolKeys.forEach(k => {
        const el = document.getElementById('cfg_' + k);
        if(el) el.checked = !!config[k];
    });

    const numKeys = ['max_entries_per_cycle', 'exit_profit_below', 'loop_seconds'];
    numKeys.forEach(k => {
        const el = document.getElementById('cfg_' + k);
        if(el && config[k] !== undefined) el.value = config[k];
    });
}

function readConfig(){
    const payload = {};

    ['force_entry_enabled','force_exit_enabled','paper_execution_enabled','live_execution_enabled','exit_on_blocked_pair','exit_profit_guard_enabled'].forEach(k => {
        const el = document.getElementById('cfg_' + k);
        if(el) payload[k] = el.checked;
    });

    ['max_entries_per_cycle','exit_profit_below','loop_seconds'].forEach(k => {
        const el = document.getElementById('cfg_' + k);
        if(el) payload[k] = parseFloat(el.value);
    });

    return payload;
}

async function saveAdapterConfig(){
    const res = await adapterApi('save_config', readConfig());
    alert(res.ok ? 'Adapter config saved.' : 'Config save error.');
    configLoaded = false;
    loadAdapter();
}

async function enableAdapter(){
    if(!confirm('Enable execution adapter? In PAPER mode this can open dry-run trades.')) return;
    await adapterApi('enable', {});
    configLoaded = false;
    loadAdapter();
}

async function disableAdapter(){
    await adapterApi('disable', {});
    configLoaded = false;
    loadAdapter();
}

function renderHistory(history){
    const body = document.getElementById('adapterHistory');
    body.innerHTML = '';

    if(!history.length){
        body.innerHTML = '<tr><td colspan="6">No adapter history.</td></tr>';
        return;
    }

    history.forEach(h => {
        body.innerHTML += `
            <tr>
                <td>${formatTime(h.time)}</td>
                <td>${h.event || '-'}</td>
                <td>${h.pair || '-'}</td>
                <td>${h.side || '-'}</td>
                <td>${h.status || '-'}</td>
                <td>${h.reason || '-'}</td>
            </tr>
        `;
    });
}

function formatTime(value){
    if(!value) return '-';
    try{
        const d = new Date(value);
        if(Number.isNaN(d.getTime())) return value;
        return d.toLocaleString();
    }catch(e){
        return value;
    }
}
