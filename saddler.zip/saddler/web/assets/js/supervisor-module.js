document.addEventListener('DOMContentLoaded', () => {
    initModuleShell('supervisor');
    loadSupervisor();
    setInterval(loadSupervisor, 3000);
});

let currentConfig = null;

async function supApi(action='state', body=null){
    const options = body ? {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify(body)
    } : {cache:'no-store'};

    const r = await fetch('../api/supervisor.php?action=' + encodeURIComponent(action) + '&t=' + Date.now(), options);
    return await r.json();
}

async function loadSupervisor(){
    const data = await supApi('state');
    const state = data.state || {};
    const config = data.config || {};
    currentConfig = config;

    const services = state.services || [];
    const running = services.filter(s => s.running).length;
    const stopped = services.length - running;

    document.getElementById('supStatus').textContent = state.supervisor_status || 'OFFLINE';
    document.getElementById('supRunning').textContent = running;
    document.getElementById('supStopped').textContent = stopped;
    document.getElementById('supDelay').textContent = (config.restart_delay_seconds ?? '-') + 's';

    renderServices(services, config);
}

function renderServices(services, config){
    const body = document.getElementById('supServices');
    body.innerHTML = '';

    if(!services.length){
        body.innerHTML = '<tr><td colspan="6">Supervisor not running or no state yet.</td></tr>';
        return;
    }

    services.forEach(s => {
        const cfg = (config.services || {})[s.key] || {};
        body.innerHTML += `
            <tr>
                <td><b>${s.name}</b><br><small>${s.key}</small></td>
                <td>${s.pid || '-'}</td>
                <td class="${s.running ? 'sup-ok' : 'sup-bad'}">${s.running ? 'RUNNING' : 'STOPPED'}</td>
                <td><input type="checkbox" data-key="${s.key}" data-field="enabled" ${cfg.enabled ? 'checked' : ''}></td>
                <td><input type="checkbox" data-key="${s.key}" data-field="restart" ${cfg.restart ? 'checked' : ''}></td>
                <td><code>${s.cmd || '-'}</code></td>
            </tr>
        `;
    });
}

async function saveSupervisorConfig(){
    const services = {};
    document.querySelectorAll('#supServices input[type="checkbox"]').forEach(el => {
        const key = el.dataset.key;
        const field = el.dataset.field;
        if(!services[key]) services[key] = {};
        services[key][field] = el.checked;
    });

    const payload = {
        restart_delay_seconds: currentConfig?.restart_delay_seconds || 3,
        services
    };

    const res = await supApi('save_config', payload);
    alert(res.ok ? 'Supervisor config saved.' : 'Save error.');
    loadSupervisor();
}
