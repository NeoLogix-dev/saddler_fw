// Dashboard Freqtrade override.
// Do not replace index.php/sidebar. Include this script after app.js only.

(function(){
    const API_URL = 'api/freqtrade.php';

    function qs(id){ return document.getElementById(id); }

    function setFreqBadge(online){
        document.querySelectorAll('.badge').forEach(el => {
            const txt = (el.textContent || '').toUpperCase();
            if(txt.includes('FREQTRADE')){
                el.innerHTML = `<span class="dot"></span>${online ? 'FREQTRADE ONLINE' : 'FREQTRADE OFFLINE'}`;
                el.className = 'badge ' + (online ? 'green' : 'red');
            }
        });

        const el = qs('freqHeaderState');
        if(el){
            el.innerHTML = `<span class="dot"></span>${online ? 'FREQTRADE ONLINE' : 'FREQTRADE OFFLINE'}`;
            el.className = 'badge ' + (online ? 'green' : 'red');
        }
    }

    function pct(v){
        if(v === null || v === undefined || v === '') return '--';
        const n = Number(v);
        if(Number.isNaN(n)) return '--';
        return n.toFixed(2) + '%';
    }

    function num(v){
        if(v === null || v === undefined || v === '') return '--';
        const n = Number(v);
        if(Number.isNaN(n)) return String(v);
        return n.toFixed(4).replace(/\.?0+$/,'');
    }

    function time(v){
        if(!v) return '-';
        try{
            const d = new Date(String(v).replace(' ', 'T'));
            if(Number.isNaN(d.getTime())) return v;
            return d.toLocaleString();
        }catch(e){ return v; }
    }

    function findOpenPositionsBody(){
        const byId = ['openPositionsBody','positionsBody','openPositions','freqtradePositions','positionsTableBody'];
        for(const id of byId){
            const el = qs(id);
            if(el && el.tagName.toLowerCase() === 'tbody') return el;
        }

        const heads = Array.from(document.querySelectorAll('h2,h3,.card-title'));
        const h = heads.find(x => (x.textContent || '').toLowerCase().includes('open positions'));
        if(h){
            const card = h.closest('.card,.module-card,section,div');
            if(card){
                const tb = card.querySelector('tbody');
                if(tb) return tb;
            }
        }

        return Array.from(document.querySelectorAll('tbody')).find(tb => (tb.textContent || '').includes('Loading positions')) || null;
    }

    function updateCards(data){
        const open = data.open_trades ?? data.open_count ?? data.count ?? '--';
        const profit = data.total_profit_pct ?? data.total_profit ?? data.profit;

        document.querySelectorAll('.card,.stat-card,.metric-card').forEach(card => {
            const txt = (card.textContent || '').toLowerCase();
            const values = card.querySelectorAll('strong,h2,.value,.metric-value');
            const target = values.length ? values[values.length - 1] : null;
            if(!target) return;

            if(txt.includes('open trades')){
                target.textContent = String(open);
            }

            if(txt.includes('total profit')){
                target.textContent = pct(profit);
            }
        });

        ['openTradesValue','openTrades','openTradeCount','freqOpenTrades'].forEach(id => {
            const el = qs(id); if(el) el.textContent = String(open);
        });

        ['totalProfitValue','totalProfit','freqProfit'].forEach(id => {
            const el = qs(id); if(el) el.textContent = pct(profit);
        });

        document.querySelectorAll('.active-count,[id*="active"]').forEach(el => {
            if((el.textContent || '').includes('active')) el.textContent = `${open} active`;
        });
    }

    function renderPositions(data){
        const positions = data.positions || data.open_positions || data.trades || [];
        const body = findOpenPositionsBody();
        if(!body) return;

        body.innerHTML = '';

        if(!positions.length){
            body.innerHTML = '<tr><td colspan="7">No open positions.</td></tr>';
            return;
        }

        positions.forEach(p => {
            const pnl = p.pnl ?? p.profit_pct;
            const pnlClass = Number(pnl) >= 0 ? 'long' : 'short';
            body.innerHTML += `
                <tr>
                    <td><b>${p.pair || '-'}</b></td>
                    <td>${p.side || '-'}</td>
                    <td>${num(p.entry ?? p.open_rate)}</td>
                    <td>${num(p.current ?? p.current_rate)}</td>
                    <td class="${pnlClass}">${pct(pnl)}</td>
                    <td>${num(p.stake ?? p.stake_amount)}</td>
                    <td>${time(p.opened ?? p.open_date)}</td>
                    <td >
                    <button class="px-btn red" onclick="manualCloseTrade('${p.trade_id}')" >
                    <span class="material-icons">stop</span>
                    </button>
                    <button class="px-btn yellow" onclick="emergencyCloseTrade('${p.trade_id}')">
                    <span class="material-icons">power_off</span>
                    </button>
                    </td>
                    </tr>
            `;
        });
    }
    async function emergencyCloseTrade(tradeId) {

    if (!tradeId) {
        return;
    }

    const ok = confirm(
        "EMERGENCY CLOSE trade?"
    );

    if (!ok) {
        return;
    }

    try {

        await fetch(
            "api/emergency_close.php",
            {
                method: "POST",
                headers: {
                    "Content-Type":
                        "application/json"
                },
                body: JSON.stringify({
                    trade_id: tradeId
                })
            }
        );

        setTimeout(
            loadFreqtrade,
            800
        );

    } catch(err) {

        console.error(
            "emergency close failed",
            err
        );
    }
}
async function manualCloseTrade(tradeId) {

    if (!tradeId) {
        return;
    }

    const ok = confirm(
        "Close trade?"
    );

    if (!ok) {
        return;
    }

    try {

        await fetch(
            "api/manual_close.php",
            {
                method: "POST",
                headers: {
                    "Content-Type":
                        "application/json"
                },
                body: JSON.stringify({
                    trade_id: tradeId
                })
            }
        );

        setTimeout(
            loadFreqtrade,
            800
        );

    } catch(err) {

        console.error(
            "manual close failed",
            err
        );
    }
}
    async function refresh(){
        try{
            const res = await fetch(API_URL + '?t=' + Date.now(), {cache:'no-store'});
            const data = await res.json();
            setFreqBadge(!!(data.online || data.ok));
            updateCards(data);
            renderPositions(data);
        }catch(e){
            console.warn('dashboard-freqtrade-override failed', e);
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        refresh();
        setTimeout(refresh, 1000);
        setTimeout(refresh, 2500);
        setInterval(refresh, 5000);
    });
})();
