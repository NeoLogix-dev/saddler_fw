// Dashboard Balance Manager + final Risk strip.
// Does not touch freqHeaderState.

(function(){
    function $(id){return document.getElementById(id);}
    function money(v){ if(v===null||v===undefined||v==='') return '--'; const n=Number(v); return Number.isFinite(n)?'$'+n.toFixed(2):String(v); }
    function num(v,d=4){ if(v===null||v===undefined||v==='') return '--'; const n=Number(v); return Number.isFinite(n)?String(Number(n.toFixed(d))):String(v); }
    function pct(v){ if(v===null||v===undefined||v==='') return '--'; const n=Number(v); return Number.isFinite(n)?n.toFixed(2)+'%':'--'; }
    function set(id,val){ const el=$(id); if(el) el.textContent=val; }

    async function getJson(url){
        const r=await fetch(url+(url.includes('?')?'&':'?')+'t='+Date.now(),{cache:'no-store'});
        return await r.json();
    }

    async function postJson(url,data){
        const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
        return await r.json();
    }

    function renderPositions(data){
        const positions=data.positions||data.open_positions||[];
        const body=$('positionsBody');
        if(!body) return;
        body.innerHTML='';
        if(!positions.length){
            body.innerHTML='<tr><td colspan="7">No open trades.</td></tr>';
            return;
        }

        positions.forEach(p=>{
            const pnl=p.pnl??p.profit_pct;
            const cls=Number(pnl)>=0?'long':'short';
            body.innerHTML+=`<tr>
                <td><b>${p.pair||'-'}</b></td>
                <td>${p.side||'-'}</td>
                <td>${num(p.entry??p.open_rate)}</td>
                <td>${num(p.current??p.current_rate)}</td>
                <td class="${cls}">${pct(pnl)}</td>
                <td>${money(p.stake??p.stake_amount)}</td>
                <td>${p.opened||p.open_date||'-'}</td>
                <td >
                <button class="px-btn red" onclick="manualCloseTrade('${p.trade_id}')" >
                <span class="material-icons">stop</span>
                </button>
                <button class="px-btn yellow" onclick="emergencyCloseTrade('${p.trade_id}')">
                <span class="material-icons">power_off</span>
                </button>
                </td>
            </tr>`;
        });
    }

    function fillBalanceForm(cfg){
        if($('bmTotalBalance')) $('bmTotalBalance').value=cfg.total_balance ?? 1000;
        if($('bmTradingPct')) $('bmTradingPct').value=cfg.trading_allocation_pct ?? 70;
        if($('bmStaticPct')) $('bmStaticPct').value=cfg.static_allocation_pct ?? 30;
        if($('bmProfitLockPct')) $('bmProfitLockPct').value=cfg.profit_lock_trigger_pct ?? 0.8;
        if($('bmDailyLossPct')) $('bmDailyLossPct').value=cfg.daily_loss_limit_pct ?? 3;
        if($('bmDailyTargetPct')) $('bmDailyTargetPct').value=cfg.daily_profit_target_pct ?? 2;
    }

    function renderBalance(balance, ft){
        const s=balance.summary||{};
        set('totalBalance', money(s.total_balance));
        set('staticBalance', money(s.static_balance));
        set('tradingBalance', money(s.trading_balance));
        set('staticBalanceSmall', money(s.static_balance));
        set('lockedProfit', money(s.locked_profit));

        set('tradingBalanceText', money(s.trading_balance));
        set('staticBalanceText', money(s.static_balance));
        set('lockedProfitText', money(s.locked_profit));

        set('openTrades', String(ft.open_trades ?? ft.open_count ?? 0));
        set('openTradesSub', `${ft.open_trades ?? 0} active`);
        set('positionsCount', `${ft.open_trades ?? 0} active`);

        set('realizedDailyPnl', money(s.realized_daily ?? ft.realized_daily ?? 0));
        set('realizedTotalPnl', money(s.realized_total ?? ft.realized_total ?? 0));
    }

    function renderRiskFromSignals(signals){
        const best=(signals||[])[0]||null;

        if(!best){
            set('riskBestPair','--');
            set('riskAction','--');
            set('riskValue','--');
            set('riskAllowed','--');
            set('riskReason','--');
            set('riskScore','--');
            set('riskConfidence','--');
            return;
        }

        const direction = best.side || best.trend_bias || '--';
        const action = best.action || '--';
        const allowed = best.allowed === false ? 'NO' : (best.allowed === true ? 'YES' : '--');

        set('riskBestPair', best.pair || '--');
        set('riskAction', `${direction} / ${action}`);
        set('riskValue', best.risk !== undefined ? Number(best.risk).toFixed(2) : '--');
        set('riskAllowed', allowed);
        set('riskReason', best.reason || (allowed === 'NO' ? 'BLOCKED' : 'OK'));
        set('riskScore', best.score !== undefined ? Number(best.score).toFixed(2) : '--');
        set('riskConfidence', best.confidence !== undefined ? Number(best.confidence).toFixed(2) : '--');
    }

    async function refresh(){
        try{
            const [ft,bm,sg] = await Promise.all([
                getJson('api/freqtrade.php'),
                getJson('api/balance_manager.php'),
                getJson('api/signals.php')
            ]);

            renderBalance(bm,ft);
            renderPositions(ft);
            renderRiskFromSignals(sg.signals||[]);

            if(!window.__bmFormFilled){
                fillBalanceForm(bm.config||{});
                window.__bmFormFilled=true;
            }
        }catch(e){
            console.warn('dashboard refresh failed', e);
        }
    }

    document.addEventListener('DOMContentLoaded',()=>{
        const trading=$('bmTradingPct'), stat=$('bmStaticPct');
        if(trading&&stat){
            trading.addEventListener('input',()=>stat.value=Math.max(0,100-Number(trading.value||0)));
        }

        const save=$('saveBalanceManager');
        if(save){
            save.addEventListener('click', async()=>{
                const payload={
                    total_balance:Number($('bmTotalBalance')?.value||0),
                    trading_allocation_pct:Number($('bmTradingPct')?.value||70),
                    profit_lock_trigger_pct:Number($('bmProfitLockPct')?.value||0.8),
                    daily_loss_limit_pct:Number($('bmDailyLossPct')?.value||3),
                    daily_profit_target_pct:Number($('bmDailyTargetPct')?.value||2)
                };

                const res=await postJson('api/balance_manager.php?action=save',payload);
                if(res.ok){
                    window.__bmFormFilled=false;
                    refresh();
                }else{
                    alert('Balance settings save failed.');
                }
            });
        }

        refresh();
        setInterval(refresh,5000);
    });
})();
