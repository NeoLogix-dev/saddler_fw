// NewTrade sidebar module link fix
// This converts old dashboard anchor links (#signals, #risk...) into real module page links.

document.addEventListener('DOMContentLoaded', () => {
    const links = {
        '#dashboard': 'index.php',
        '#signals': 'modules/signals.php',
        '#risk': 'modules/risk.php',
        '#positions': 'modules/positions.php',
        '#agents': 'modules/agents.php',
        '#logs': 'modules/logs.php'
    };

    document.querySelectorAll('.side-nav a, nav a').forEach(a => {
        const href = a.getAttribute('href');
        if (links[href]) {
            a.setAttribute('href', links[href]);
        }

        const section = a.dataset.section;
        if (section === 'dashboard') a.setAttribute('href', 'index.php');
        if (section === 'signals') a.setAttribute('href', 'modules/signals.php');
        if (section === 'risk') a.setAttribute('href', 'modules/risk.php');
        if (section === 'positions') a.setAttribute('href', 'modules/positions.php');
        if (section === 'agents') a.setAttribute('href', 'modules/agents.php');
        if (section === 'logs') a.setAttribute('href', 'modules/logs.php');
    });
});
