async function getJson(url){
    const sep = url.includes('?') ? '&' : '?';
    const r = await fetch(url + sep + 't=' + Date.now(), {cache: 'no-store'});
    return await r.json();
}
function el(id){ return document.getElementById(id); }
function setText(id, value){ const x = el(id); if(x) x.textContent = value; }
function clsAction(a){
    if(!a) return '';
    a = String(a).toLowerCase();
    if(a.includes('enter')) return 'enter';
    if(a.includes('wait')) return 'wait';
    if(a.includes('short')) return 'short';
    if(a.includes('long')) return 'long';
    return '';
}
function fmtPct(v){
    if(v === null || v === undefined || v === '') return '--';
    const n = Number(v);
    if(!Number.isFinite(n)) return String(v);
    return n.toFixed(2) + '%';
}
function fmtNum(v, d=4){
    if(v === null || v === undefined || v === '') return '--';
    const n = Number(v);
    if(!Number.isFinite(n)) return String(v);
    return String(Number(n.toFixed(d)));
}
function initSidebar(){
    const app = el('appRoot');
    const btn = el('collapseBtn');
    if(app && localStorage.getItem('newtrade_sidebar') === 'collapsed') app.classList.add('sidebar-collapsed');
    if(btn && app){
        btn.addEventListener('click', () => {
            app.classList.toggle('sidebar-collapsed');
            localStorage.setItem('newtrade_sidebar', app.classList.contains('sidebar-collapsed') ? 'collapsed' : 'open');
        });
    }
}
async function loadSignals(){
    const body = el('signalsBody');
    if(!body) return;
    try {
        const data = await getJson('api/signals.php');
        const signals = data.signals || [];
        body.innerHTML = '';
        if (!signals.length) {
            body.innerHTML = '<tr><td colspan="10">No signals found in JSON.</td></tr>';
            setText('bestPair','--'); setText('bestScore','--'); setText('bestAction','waiting');
            return;
        }
        signals.forEach(s => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${s.pair ?? '-'}</td>
                <td class="${String(s.side ?? '').toLowerCase()}">${s.side ?? '-'}</td>
                <td class="${clsAction(s.action)}">${s.action ?? '-'}</td>
                <td>${s.score ?? '-'}</td>
                <td>${s.confidence ?? '-'}</td>
                <td>${s.trend ?? '-'}</td>
                <td>${s.funding ?? '-'}</td>
                <td>${s.orderflow ?? '-'}</td>
                <td>${s.onchain ?? '-'}</td>
                <td>${s.risk ?? '-'}</td>`;
            body.appendChild(tr);
        });
        const best = signals[0] || {};
        setText('bestPair', best.pair ?? '--');
        setText('bestScore', best.score ?? '--');
        setText('bestAction', best.action ?? 'waiting');
        const riskPanel = el('riskPanel');
        if(riskPanel){
            riskPanel.innerHTML = `<div><b>${best.pair ?? '-'}</b> / ${best.side ?? '-'}</div><div>Risk score: <b>${best.risk ?? '-'}</b></div><div>Allowed: <b>${best.allowed ? 'YES' : 'NO'}</b></div><div>Reason: ${best.reason ?? 'OK'}</div>`;
        }
        const agentsPanel = el('agentsPanel');
        if(agentsPanel){
            agentsPanel.innerHTML = `<div><b>Trend Agent:</b> ${best.trend_bias ?? best.side ?? '-'}</div><div><b>Funding Agent:</b> ${best.funding_bias ?? '-'}</div><div><b>Orderflow Agent:</b> ${best.orderflow_bias ?? '-'}</div><div><b>Onchain Agent:</b> ${best.onchain_bias ?? '-'}</div>`;
        }
    } catch (e) {
        console.error('SIGNALS ERROR:', e);
        body.innerHTML = '<tr><td colspan="10">Signals JS error. Check console.</td></tr>';
    }
}
async function loadFreqtrade(){
    try{
        const data = await getJson('api/freqtrade.php');
        const open = data.open_trades ?? data.open_count ?? data.count ?? '--';
        const profit = data.total_profit_pct ?? data.total_profit ?? data.profit ?? data.profit_total;
        setText('openTrades', open);
        setText('profitTotal', fmtPct(profit));
        const positions = data.positions || data.open_positions || data.trades || [];
        setText('positionsCount', `${positions.length} active`);
        const pos = el('positionsBody');
        if(!pos) return;
        pos.innerHTML = '';
        if(positions.length){
            positions.forEach(p=>{
                const pnl = p.pnl ?? p.profit_pct ?? (p.profit_ratio != null ? Number(p.profit_ratio) * 100 : null);
                const pnlClass = Number(pnl) < 0 ? 'short' : 'long';
                const tr = document.createElement('tr');
                tr.innerHTML = `<td>${p.pair ?? '-'}</td><td>${p.side ?? '-'}</td><td>${fmtNum(p.entry ?? p.open_rate)}</td><td>${fmtNum(p.current ?? p.current_rate)}</td><td class="${pnlClass}">${fmtPct(pnl)}</td><td>${fmtNum(p.stake ?? p.stake_amount,2)}</td><td>${p.opened ?? p.open_date ?? '-'}</td>
                <td >
                <button class="px-btn red" onclick="manualCloseTrade('${p.trade_id}')" >
                <span class="material-icons">stop</span>
                </button>
                <button class="px-btn yellow" onclick="emergencyCloseTrade('${p.trade_id}')">
                <span class="material-icons">power_off</span>
                </button>
                </td>`;
                pos.appendChild(tr);
            });
        }else{
            pos.innerHTML = '<tr><td colspan="7">No open positions.</td></tr>';
        }
    }catch(e){ console.error('FREQTRADE DATA ERROR:', e); }
}
async function emergencyCloseTrade(tradeId) {

    if (!tradeId) {
        return;
    }

    const ok = confirm(
        "EMERGENCY CLOSE trade?"
    );

    if (!ok) {
        return;
    }

    try {

        await fetch(
            "api/emergency_close.php",
            {
                method: "POST",
                headers: {
                    "Content-Type":
                        "application/json"
                },
                body: JSON.stringify({
                    trade_id: tradeId
                })
            }
        );

        setTimeout(
            loadFreqtrade,
            800
        );

    } catch(err) {

        console.error(
            "emergency close failed",
            err
        );
    }
}
async function manualCloseTrade(tradeId) {

    if (!tradeId) {
        return;
    }

    const ok = confirm(
        "Close trade?"
    );

    if (!ok) {
        return;
    }

    try {

        await fetch(
            "api/manual_close.php",
            {
                method: "POST",
                headers: {
                    "Content-Type":
                        "application/json"
                },
                body: JSON.stringify({
                    trade_id: tradeId
                })
            }
        );

        setTimeout(
            loadFreqtrade,
            800
        );

    } catch(err) {

        console.error(
            "manual close failed",
            err
        );
    }
}
async function loadLogs(){
    try{
        const r = await fetch('api/logs.php?t=' + Date.now(), {cache: 'no-store'});
        const logs = el('engineLogs');
        if(logs) logs.textContent = await r.text();
    }catch(e){}
}
document.addEventListener('DOMContentLoaded', () => {
    initSidebar();
    const search = el('searchInput');
    if(search){
        search.addEventListener('input', e=>{
            const q = e.target.value.toLowerCase();
            document.querySelectorAll('#signalsBody tr').forEach(tr=>{ tr.style.display = tr.textContent.toLowerCase().includes(q) ? '' : 'none'; });
        });
    }
    function tick(){ loadSignals(); loadFreqtrade(); loadLogs(); }
    tick();
    setInterval(tick, 2000);
});
