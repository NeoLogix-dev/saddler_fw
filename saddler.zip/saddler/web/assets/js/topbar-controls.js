// NewTrade unified topbar controls.
// Single owner of Freqtrade indicator. Dashboard scripts must not touch freqHeaderState.
(function(){
    const isModule = window.location.pathname.includes('/modules/');
    const apiPrefix = isModule ? '../api/' : 'api/';

    async function api(path, action='state', body=null){
        const options = body ? {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)} : {cache:'no-store'};
        const r = await fetch(apiPrefix + path + '?action=' + encodeURIComponent(action) + '&t=' + Date.now(), options);
        return await r.json();
    }

    function badge(id,text,cls){
        const el=document.getElementById(id);
        if(!el) return;
        el.innerHTML='<span class="dot"></span>'+text;
        el.className='badge '+cls;
    }

    function switchState(id,labelId,on,onText,offText){
        const s=document.getElementById(id), l=document.getElementById(labelId);
        if(!s||!l) return;
        s.checked=!!on;
        l.textContent=on?onText:offText;
        l.style.color=on?'#19e68c':'#8fa3c2';
    }

    async function loadFreq(){
        try{
            const d=await api('freqtrade.php');
            const online=!!(d.online||d.ok);
            if(online){
                localStorage.setItem('newtrade_freq_last_ok', String(Date.now()));
                badge('freqHeaderState','FREQTRADE ONLINE','green');
                return;
            }
            const lastOk=parseInt(localStorage.getItem('newtrade_freq_last_ok')||'0',10);
            if(lastOk && Date.now()-lastOk < 180000){
                badge('freqHeaderState','FREQTRADE ONLINE','green');
            }else{
                badge('freqHeaderState','FREQTRADE OFFLINE','red');
            }
        }catch(e){
            const lastOk=parseInt(localStorage.getItem('newtrade_freq_last_ok')||'0',10);
            if(lastOk && Date.now()-lastOk < 180000){
                badge('freqHeaderState','FREQTRADE ONLINE','green');
            }else{
                badge('freqHeaderState','FREQTRADE OFFLINE','red');
            }
        }
    }

    async function loadEngine(){
        try{
            const d=await api('signals.php');
            const ok=Array.isArray(d.signals)&&d.signals.length>0;
            badge('engineHeaderState',ok?'RUNNING':'ENGINE OFF',ok?'green':'red');
        }catch(e){ badge('engineHeaderState','ENGINE OFF','red'); }
    }

    async function loadAdapter(){try{const d=await api('adapter.php'); switchState('adapterHeaderSwitch','adapterHeaderLabel',!!(d.config&&d.config.execution_enabled),'ADAPTER ON','ADAPTER OFF');}catch(e){}}
    async function loadPm(){try{const d=await api('positions_manager.php'); switchState('pmHeaderSwitch','pmHeaderLabel',!!(d.config&&d.config.manager_enabled),'PM ON','PM OFF');}catch(e){}}
    async function loadPx(){try{const d=await api('position_executor.php'); switchState('pxHeaderSwitch','pxHeaderLabel',!!(d.config&&d.config.executor_enabled),'PX ON','PX OFF');}catch(e){}}

    function bind(id,file,fn){
        const el=document.getElementById(id);
        if(!el||el.dataset.boundUnified==='1') return;
        el.dataset.boundUnified='1';
        el.addEventListener('change', async()=>{try{await api(file,el.checked?'enable':'disable',{});}catch(e){} fn();});
    }

    function active(){
        const path=location.pathname.toLowerCase();
        let key='dashboard';
        if(path.includes('supervisor.php')) key='supervisor';
        else if(path.includes('signals.php')) key='signals';
        else if(path.includes('agents.php')) key='agents';
        else if(path.includes('risk.php')) key='risk';
        else if(path.includes('strategies.php')||path.includes('strategy_editor.php')) key='strategies';
        else if(path.includes('orchestrator.php')) key='orchestrator';
        else if(path.includes('execution.php')) key='execution';
        else if(path.includes('adapter.php')) key='adapter';
        else if(path.includes('position_manager.php')) key='position_manager';
        else if(path.includes('position_executor.php')) key='position_executor';
        else if(path.includes('positions.php')) key='positions';
        else if(path.includes('logs.php')) key='logs';
        document.querySelectorAll('.side-nav a').forEach(a=>a.classList.toggle('active',a.dataset.section===key));
    }

    document.addEventListener('DOMContentLoaded',()=>{
        active();
        bind('adapterHeaderSwitch','adapter.php',loadAdapter);
        bind('pmHeaderSwitch','positions_manager.php',loadPm);
        bind('pxHeaderSwitch','position_executor.php',loadPx);
        loadFreq(); loadEngine(); loadAdapter(); loadPm(); loadPx();
        setInterval(loadFreq,15000);
        setInterval(loadEngine,8000);
        setInterval(loadAdapter,8000);
        setInterval(loadPm,8000);
        setInterval(loadPx,8000);
    });
})();
