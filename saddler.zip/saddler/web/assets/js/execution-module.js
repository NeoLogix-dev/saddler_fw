document.addEventListener('DOMContentLoaded', () => {
    initModuleShell('execution');
    bindTableSearch('queueSearch', '#queueTable');
    bindTableSearch('cooldownSearch', '#cooldownTable');
    bindTableSearch('eventSearch', '#eventsTable');
    bindTableSearch('historySearch', '#historyTable');
    loadExecution();
    setInterval(loadExecution, 2000);
});

async function executionApi(action='state', body=null){
    const options = body ? {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)} : {cache:'no-store'};
    const r = await fetch('../api/execution.php?action=' + encodeURIComponent(action) + '&t=' + Date.now(), options);
    return await r.json();
}

function statusMeta(status){
    const s = String(status || '').toUpperCase();
    const map = {
        'ACTIVE': {icon:'radio_button_checked', label:'ACTIVE', cls:'status-open'},
        'IDLE': {icon:'radio_button_unchecked', label:'IDLE', cls:'status-neutral'},
        'NO_SIGNALS': {icon:'sensors_off', label:'NO SIGNAL', cls:'status-neutral'},
        'READY': {icon:'play_circle', label:'READY', cls:'status-ready'},
        'READY_MANUAL': {icon:'touch_app', label:'MANUAL', cls:'status-manual'},
        'WAIT_CONFIRMATION': {icon:'hourglass_top', label:'WAIT', cls:'status-wait'},
        'BLOCKED': {icon:'block', label:'BLOCKED', cls:'status-blocked'},
        'COOLDOWN': {icon:'timer', label:'COOLDOWN', cls:'status-cooldown'},
        'EXECUTING': {icon:'sync', label:'EXECUTING', cls:'status-executing'},
        'OPEN': {icon:'trending_up', label:'OPEN', cls:'status-open'},
        'PARTIAL_EXIT': {icon:'call_split', label:'PARTIAL', cls:'status-partial'},
        'EMERGENCY_EXIT': {icon:'warning', label:'EMERGENCY', cls:'status-emergency'},
        'CANCELLED': {icon:'close', label:'CANCELLED', cls:'status-cancelled'}
    };
    return map[s] || {icon:'radio_button_unchecked', label:s || '-', cls:'status-neutral'};
}

function marketMeta(state){
    const s = String(state || 'UNKNOWN').toUpperCase();
    if(s.includes('TRENDING')) return {icon:'trending_up', label:'TRENDING', cls:'market-trending'};
    if(s.includes('RANGING')) return {icon:'ssid_chart', label:'RANGING', cls:'market-ranging'};
    if(s.includes('FUNDING')) return {icon:'paid', label:'FUNDING', cls:'market-warning'};
    if(s.includes('LOW_QUALITY')) return {icon:'report', label:'LOW QUALITY', cls:'market-danger'};
    if(s.includes('NORMAL')) return {icon:'monitor_heart', label:'NORMAL', cls:'market-normal'};
    return {icon:'help_outline', label:s || 'UNKNOWN', cls:'market-neutral'};
}

function reasonMeta(reason){
    const r = String(reason || '').toUpperCase();
    const map = {
        'ACTION_NOT_ENTER': {icon:'pause_circle', label:'WAIT', cls:'reason-neutral'},
        'AUTO_OFF': {icon:'toggle_off', label:'AUTO OFF', cls:'reason-warning'},
        'EXECUTION_ALLOWED': {icon:'verified', label:'ALLOWED', cls:'reason-success'},
        'ORDERFLOW_CONFIRMATION_NEEDED': {icon:'water_drop', label:'ORDERFLOW', cls:'reason-warning'},
        'RISK_SCORE_LOW': {icon:'shield', label:'RISK LOW', cls:'reason-danger'},
        'FUNDING_RISK': {icon:'paid', label:'FUNDING', cls:'reason-danger'},
        'COOLDOWN_ACTIVE': {icon:'timer', label:'COOLDOWN', cls:'reason-info'},
        'MANUAL_CANCEL': {icon:'close', label:'CANCELLED', cls:'reason-danger'},
        'SIGNAL_EXPIRED': {icon:'schedule', label:'EXPIRED', cls:'reason-neutral'},
        'SIDE_NOT_VALID': {icon:'swap_horiz', label:'SIDE', cls:'reason-warning'},
        'SCORE_LOW': {icon:'speed', label:'LOW SCORE', cls:'reason-warning'},
        'CONFIDENCE_LOW': {icon:'psychology', label:'LOW CONF', cls:'reason-warning'},
        'RISK_NOT_ALLOWED': {icon:'block', label:'BLOCKED', cls:'reason-danger'},
        'QUICK_COOLDOWN': {icon:'timer', label:'QUICK CD', cls:'reason-info'},
        'MANUAL_COOLDOWN': {icon:'timer', label:'MANUAL CD', cls:'reason-info'},
        'NO_SIGNAL': {icon:'sensors_off', label:'NO SIGNAL', cls:'reason-neutral'},
        'ANTI_OVERTRADE': {icon:'front_hand', label:'OVERTRADE', cls:'reason-danger'},
        'CONSENSUS_LOW': {icon:'groups', label:'CONS LOW', cls:'reason-warning'},
        'EXECUTION_SCORE_LOW': {icon:'bolt', label:'EXEC LOW', cls:'reason-warning'}
    };
    return map[r] || {icon:'info', label:r || '-', cls:'reason-neutral'};
}

function hudPill(meta, type='status'){
    return `<span class="hud-pill ${type}-pill ${meta.cls}"><span class="material-icons ${meta.cls === 'status-executing' ? 'spin-icon' : ''}">${meta.icon}</span><span>${meta.label}</span></span>`;
}
function cardInline(meta){
    return `<span class="card-inline ${meta.cls}"><span class="material-icons ${meta.cls === 'status-executing' ? 'spin-icon' : ''}">${meta.icon}</span><span>${meta.label}</span></span>`;
}
function statusPill(status){ return hudPill(statusMeta(status), 'status'); }
function marketPill(state){ return hudPill(marketMeta(state), 'market'); }
function reasonPill(reason){ return hudPill(reasonMeta(reason), 'reason'); }
function statusCard(status){ return cardInline(statusMeta(status)); }
function marketCard(state){ return cardInline(marketMeta(state)); }

async function loadExecution(){
    try{
        const data = await executionApi('state');
        const state = data.state || {};

        document.getElementById('execStatus').innerHTML = statusCard(state.engine_status || 'IDLE');
        document.getElementById('marketState').innerHTML = marketCard(state.market_state || 'UNKNOWN');
        document.getElementById('readyCount').textContent = state.ready_count ?? '--';
        document.getElementById('blockedCount').textContent = state.blocked_count ?? '--';
        document.getElementById('waitCount').textContent = state.wait_count ?? '--';
        document.getElementById('queueCount').textContent = state.queue_count ?? '--';
        document.getElementById('cooldownCount').textContent = state.cooldown_count ?? '--';
        document.getElementById('topPriority').textContent = state.top_priority?.priority ?? '--';

        fillConfig(data.config || {});
        renderQueue(data.queue || []);
        renderCooldowns(data.cooldowns || {});
        renderEvents(data.emergency || []);
        renderHistory(data.history || []);
    }catch(e){ console.error(e); }
}

let configFilled = false;
function fillConfig(config){
    if(configFilled) return;
    const keys = ['entry_score_min','confidence_min','orderflow_min','risk_min','consensus_min','execution_score_min','signal_ttl_minutes','anti_overtrade_minutes'];
    keys.forEach(k => {
        const el = document.getElementById('cfg_' + k);
        if(el && config[k] !== undefined) el.value = config[k];
    });
    configFilled = true;
}

function renderQueue(queue){
    const body = document.getElementById('queueTable');
    body.innerHTML = '';
    if(!queue.length){ body.innerHTML = '<tr><td colspan="12">No queue items.</td></tr>'; return; }

    queue.slice().reverse().forEach(item => {
        body.innerHTML += `
            <tr>
                <td><b>${item.pair || '-'}</b></td>
                <td class="${String(item.side || '').toLowerCase()}">${item.side || '-'}</td>
                <td>${statusPill(item.status)}</td>
                <td>${reasonPill(item.reason)}</td>
                <td>${item.score ?? '-'}</td>
                <td>${item.risk ?? '-'}</td>
                <td>${item.consensus ?? '-'}</td>
                <td>${item.execution_score ?? '-'}</td>
                <td>${item.priority ?? '-'}</td>
                <td>${marketPill(item.market_state)}</td>
                <td>${formatTime(item.expires_at)}</td>
                <td>
                    <button class="exec-btn red" onclick="cancelQueue('${item.pair}')"><span class="material-icons">close</span>Cancel</button>
                    <button class="exec-btn yellow" onclick="quickCooldown('${item.pair}')"><span class="material-icons">timer</span>Cooldown</button>
                </td>
            </tr>`;
    });
}

function renderCooldowns(cooldowns){
    const body = document.getElementById('cooldownTable');
    body.innerHTML = '';
    const pairs = Object.keys(cooldowns || {});
    if(!pairs.length){ body.innerHTML = '<tr><td colspan="4">No cooldowns.</td></tr>'; return; }
    pairs.forEach(pair => {
        const c = cooldowns[pair];
        body.innerHTML += `<tr><td><b>${pair}</b></td><td>${formatTime(c.cooldown_until)}</td><td>${reasonPill(c.reason || 'COOLDOWN_ACTIVE')}</td><td><button class="exec-btn" onclick="clearCooldown('${pair}')"><span class="material-icons">check_circle</span>Clear</button></td></tr>`;
    });
}

function renderEvents(events){
    const body = document.getElementById('eventsTable');
    body.innerHTML = '';
    if(!events.length){ body.innerHTML = '<tr><td colspan="5">No emergency/protection events.</td></tr>'; return; }
    events.slice().reverse().forEach(e => {
        const eventType = String(e.type || '').toUpperCase();
        let typeMeta = {icon:'info', label:eventType || '-', cls:'reason-neutral'};
        if(eventType.includes('EMERGENCY')) typeMeta = {icon:'warning', label:'EMERGENCY', cls:'status-emergency'};
        else if(eventType.includes('PROTECTION')) typeMeta = {icon:'health_and_safety', label:'PROTECTION', cls:'reason-warning'};
        body.innerHTML += `<tr><td>${formatTime(e.time)}</td><td><b>${e.pair || '-'}</b></td><td>${hudPill(typeMeta, 'event')}</td><td>${reasonPill(e.reason || e.type)}</td><td>${e.action || '-'}</td></tr>`;
    });
}

function renderHistory(history){
    const body = document.getElementById('historyTable');
    body.innerHTML = '';
    if(!history.length){ body.innerHTML = '<tr><td colspan="7">No execution history.</td></tr>'; return; }
    history.slice().reverse().forEach(h => {
        body.innerHTML += `<tr><td>${formatTime(h.time)}</td><td><b>${h.pair || '-'}</b></td><td>${h.side || '-'}</td><td>${statusPill(h.status)}</td><td>${reasonPill(h.reason)}</td><td>${h.execution_score ?? '-'}</td><td>${h.priority ?? '-'}</td></tr>`;
    });
}

async function saveConfig(){
    const keys = ['entry_score_min','confidence_min','orderflow_min','risk_min','consensus_min','execution_score_min','signal_ttl_minutes','anti_overtrade_minutes'];
    const payload = {};
    keys.forEach(k => {
        const el = document.getElementById('cfg_' + k);
        if(el) payload[k] = parseFloat(el.value);
    });
    const res = await executionApi('save_config', payload);
    alert(res.ok ? 'Execution rules saved.' : 'Error saving rules.');
    configFilled = false;
    loadExecution();
}

async function cancelQueue(pair){
    if(!confirm('Cancel queue item for ' + pair + '?')) return;
    await executionApi('cancel', {pair});
    loadExecution();
}

async function quickCooldown(pair){
    if(!confirm('Set cooldown for ' + pair + '?')) return;
    await executionApi('cooldown', {pair, minutes:15, reason:'QUICK_COOLDOWN'});
    loadExecution();
}

async function setCooldown(){
    const pair = document.getElementById('cooldownPair').value.trim();
    const minutes = parseInt(document.getElementById('cooldownMinutes').value || '15', 10);
    const reason = document.getElementById('cooldownReason').value.trim() || 'MANUAL_COOLDOWN';
    if(!pair){ alert('Unesi pair.'); return; }
    await executionApi('cooldown', {pair, minutes, reason});
    loadExecution();
}

async function clearCooldown(pair){
    await executionApi('clear_cooldown', {pair});
    loadExecution();
}

function formatTime(value){
    if(!value) return '-';
    try{
        const d = new Date(value);
        if(Number.isNaN(d.getTime())) return value;
        return d.toLocaleString();
    }catch(e){ return value; }
}
