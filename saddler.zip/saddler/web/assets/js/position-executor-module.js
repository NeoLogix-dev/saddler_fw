document.addEventListener('DOMContentLoaded', () => {
    initModuleShell('position_executor');
    bindTableSearch('pxSearch', '#pxEvents');

    const sw = document.getElementById('pxHeaderSwitch');
    if(sw){
        sw.addEventListener('change', async () => {
            if(sw.checked) await pxApi('enable', {});
            else await pxApi('disable', {});
            configLoaded = false;
            loadExecutor();
        });
    }

    loadExecutor();
    setInterval(loadExecutor, 3000);
});

async function pxApi(action='state', body=null){
    const options = body ? {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)} : {cache:'no-store'};
    const r = await fetch('../api/position_executor.php?action=' + encodeURIComponent(action) + '&t=' + Date.now(), options);
    return await r.json();
}

let configLoaded = false;

function updateSwitch(enabled){
    const sw = document.getElementById('pxHeaderSwitch');
    const label = document.getElementById('pxHeaderLabel');
    if(!sw || !label) return;
    sw.checked = !!enabled;
    label.textContent = enabled ? 'PX ON' : 'PX OFF';
    label.style.color = enabled ? '#19e68c' : '#8fa3c2';
}

async function loadExecutor(){
    const data = await pxApi('state');
    const state = data.state || {};
    const config = data.config || {};

    updateSwitch(!!config.executor_enabled);

    document.getElementById('pxStatus').textContent = state.executor_status || '--';
    document.getElementById('pxFreqtrade').textContent = state.freqtrade_online ? 'ONLINE' : 'OFFLINE';
    document.getElementById('pxEnabled').textContent = config.executor_enabled ? 'YES' : 'NO';
    document.getElementById('pxActions').textContent = state.actions_sent ?? '--';

    document.getElementById('pxLastAction').textContent = JSON.stringify(state.last_action || null, null, 2);
    document.getElementById('pxLastError').textContent = JSON.stringify(state.last_error || null, null, 2);

    if(!configLoaded){
        fillConfig(config);
        configLoaded = true;
    }

    renderEvents(data.events || []);
}

function fillConfig(cfg){
    [
        'paper_execution_enabled','live_execution_enabled','breakeven_executor_enabled',
        'trailing_executor_enabled','partial_tp_executor_enabled','emergency_exit_executor_enabled',
        'execute_emergency_exit','execute_reduce_or_exit'
    ].forEach(k => {
        const el = document.getElementById('cfg_' + k);
        if(el) el.checked = !!cfg[k];
    });

    ['min_seconds_between_actions','max_actions_per_cycle','loop_seconds'].forEach(k => {
        const el = document.getElementById('cfg_' + k);
        if(el && cfg[k] !== undefined) el.value = cfg[k];
    });
}

function readConfig(){
    const payload = {};
    [
        'paper_execution_enabled','live_execution_enabled','breakeven_executor_enabled',
        'trailing_executor_enabled','partial_tp_executor_enabled','emergency_exit_executor_enabled',
        'execute_emergency_exit','execute_reduce_or_exit'
    ].forEach(k => {
        const el = document.getElementById('cfg_' + k);
        if(el) payload[k] = el.checked;
    });

    ['min_seconds_between_actions','max_actions_per_cycle','loop_seconds'].forEach(k => {
        const el = document.getElementById('cfg_' + k);
        if(el) payload[k] = parseFloat(el.value);
    });

    return payload;
}

async function saveExecutorConfig(){
    const res = await pxApi('save_config', readConfig());
    alert(res.ok ? 'Position executor config saved.' : 'Save error.');
    configLoaded = false;
    loadExecutor();
}

async function enableExecutor(){
    await pxApi('enable', {});
    configLoaded = false;
    loadExecutor();
}

async function disableExecutor(){
    await pxApi('disable', {});
    configLoaded = false;
    loadExecutor();
}

function renderEvents(events){
    const body = document.getElementById('pxEvents');
    body.innerHTML = '';

    if(!events.length){
        body.innerHTML = '<tr><td colspan="6">No executor events.</td></tr>';
        return;
    }

    events.forEach(e => {
        const cls = e.status === 'ERROR' ? 'short' : 'long';
        body.innerHTML += `
            <tr>
                <td>${formatTime(e.time)}</td>
                <td>${e.type || '-'}</td>
                <td><b>${e.pair || '-'}</b></td>
                <td>${e.action || '-'}</td>
                <td class="${cls}">${e.status || '-'}</td>
                <td>${e.reason || '-'}</td>
            </tr>
        `;
    });
}

function formatTime(value){
    if(!value) return '-';
    try{
        const d = new Date(value);
        if(Number.isNaN(d.getTime())) return value;
        return d.toLocaleString();
    }catch(e){ return value; }
}
