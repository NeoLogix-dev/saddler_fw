// NewTrade Freqtrade Indicator Lock
// Prevents blinking ONLINE/OFFLINE caused by old dashboard intervals.

(function(){
    const API_URL = 'api/freqtrade.php';
    let lockedOnline = null;
    let lastOkAt = Number(localStorage.getItem('newtrade_freq_last_ok') || '0');

    function badges(){
        const out = [];

        ['freqHeaderState','freqState','freqtradeState','freqtradeStatus'].forEach(id => {
            const el = document.getElementById(id);
            if(el) out.push(el);
        });

        document.querySelectorAll('.badge').forEach(el => {
            const txt = (el.textContent || '').toUpperCase();
            if(txt.includes('FREQTRADE') && !out.includes(el)){
                out.push(el);
            }
        });

        return out;
    }

    function render(online){
        lockedOnline = !!online;

        if(lockedOnline){
            lastOkAt = Date.now();
            localStorage.setItem('newtrade_freq_online', '1');
            localStorage.setItem('newtrade_freq_last_ok', String(lastOkAt));
        }

        const label = lockedOnline ? 'FREQTRADE ONLINE' : 'FREQTRADE OFFLINE';
        const cls = lockedOnline ? 'badge green' : 'badge red';

        badges().forEach(el => {
            el.innerHTML = `<span class="dot"></span>${label}`;
            el.className = cls;
        });
    }

    function stickyDecision(){
        const age = Date.now() - lastOkAt;

        // Keep ONLINE for 5 minutes after last successful ping.
        if(lastOkAt && age < 300000){
            render(true);
        }else{
            render(false);
        }
    }

    async function refresh(){
        try{
            const res = await fetch(API_URL + '?t=' + Date.now(), {cache:'no-store'});
            const data = await res.json();

            if(data.online || data.ok){
                render(true);
            }else{
                stickyDecision();
            }
        }catch(e){
            stickyDecision();
        }
    }

    function mutationGuard(){
        const observer = new MutationObserver(() => {
            if(lockedOnline === true){
                render(true);
            }
        });

        badges().forEach(el => {
            observer.observe(el, {
                childList:true,
                subtree:true,
                characterData:true,
                attributes:true
            });
        });
    }

    document.addEventListener('DOMContentLoaded', () => {
        if(localStorage.getItem('newtrade_freq_online') === '1'){
            render(true);
        }

        refresh();
        mutationGuard();

        setTimeout(refresh, 1000);
        setTimeout(refresh, 3000);
        setInterval(refresh, 30000);
    });
})();
