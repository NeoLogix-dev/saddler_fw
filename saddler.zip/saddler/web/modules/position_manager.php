<?php
$pageTitle='Position Manager';
$pageSubtitle='Lifecycle, dynamic SL, TP ladder, recovery, exposure and emergency protection.';
$moduleScript='position-manager-module.js';
$extraCss='position-manager.css';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?php echo htmlspecialchars($pageTitle); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/hud.css">
<link rel="stylesheet" href="../assets/css/modules.css">
<link rel="stylesheet" href="../assets/css/header-switches.css">
<link rel="stylesheet" href="../assets/css/position-manager.css">
<link rel="stylesheet" href="../assets/css/layout-compact.css">
<link rel="stylesheet" href="../assets/css/layout-unified.css">
</head>
<body>
<div class="app" id="appRoot">
<aside class="sidebar" id="sidebar">
    <div class="brand">
        <div class="brand-left">
            <span class="material-icons brand-icon">analytics</span>
            <span class="brand-text">NewTrade</span>
        </div>
        <button class="collapse-btn" id="collapseBtn" title="Collapse sidebar">
            <span class="material-icons">chevron_left</span>
        </button>
    </div>

    
    
    <nav class="side-nav compact-nav">

        <div class="nav-group">
            <div class="nav-group-title">Core</div>

            <a href="../index.php" data-section="dashboard">
                <span class="material-icons">dashboard</span>
                <span class="nav-label">Dashboard</span>
            </a>

            <a href="supervisor.php" data-section="supervisor">
                <span class="material-icons">settings_power</span>
                <span class="nav-label">Supervisor</span>
            </a>
        </div>

        <div class="nav-group">
            <div class="nav-group-title">Signals</div>

            <a href="signals.php" data-section="signals">
                <span class="material-icons">stacked_line_chart</span>
                <span class="nav-label">Signals</span>
            </a>

            <a href="agents.php" data-section="agents">
                <span class="material-icons">psychology</span>
                <span class="nav-label">Agents</span>
            </a>

            <a href="risk.php" data-section="risk">
                <span class="material-icons">shield</span>
                <span class="nav-label">Risk</span>
            </a>
        </div>

        <div class="nav-group">
            <div class="nav-group-title">Execution</div>

            <a href="strategies.php" data-section="strategies">
                <span class="material-icons">account_tree</span>
                <span class="nav-label">Strategies</span>
            </a>

            <a href="orchestrator.php" data-section="orchestrator">
                <span class="material-icons">hub</span>
                <span class="nav-label">Orchestrator</span>
            </a>

            <a href="execution.php" data-section="execution">
                <span class="material-icons">bolt</span>
                <span class="nav-label">Execution</span>
            </a>

            <a href="adapter.php" data-section="adapter">
                <span class="material-icons">electrical_services</span>
                <span class="nav-label">Adapter</span>
            </a>
        </div>

        <div class="nav-group">
            <div class="nav-group-title">Positions</div>

            <a href="positions.php" data-section="positions">
                <span class="material-icons">show_chart</span>
                <span class="nav-label">Positions</span>
            </a>

            <a href="position_manager.php" data-section="position_manager">
                <span class="material-icons">precision_manufacturing</span>
                <span class="nav-label">Position Manager</span>
            </a>

            <a href="position_executor.php" data-section="position_executor">
                <span class="material-icons">published_with_changes</span>
                <span class="nav-label">Position Executor</span>
            </a>
        </div>

        <div class="nav-group">
            <div class="nav-group-title">System</div>

            <a href="logs.php" data-section="logs">
                <span class="material-icons">terminal</span>
                <span class="nav-label">Logs</span>
            </a>
        </div>

    </nav>


</aside>

<main class="main">
<header class="topbar unified-topbar">
    <div class="topbar-title">
        <h1><?php echo htmlspecialchars($pageTitle); ?></h1>
        <p><?php echo htmlspecialchars($pageSubtitle); ?></p>
    </div>

    <div class="badges unified-badges">
        <span id="freqHeaderState" class="badge blue">
            <span class="dot"></span>
            FREQTRADE CHECKING
        </span>

        <span id="engineHeaderState" class="badge blue">
            <span class="dot"></span>
            ENGINE CHECKING
        </span>

        <div class="switch-card adapter-header-switch">
            <span class="switch-label" id="adapterHeaderLabel">ADAPTER OFF</span>
            <label class="switch">
                <input type="checkbox" id="adapterHeaderSwitch">
                <span class="slider"></span>
            </label>
        </div>

        <div class="switch-card pm-header-switch">
            <span class="switch-label" id="pmHeaderLabel">PM OFF</span>
            <label class="switch">
                <input type="checkbox" id="pmHeaderSwitch">
                <span class="slider"></span>
            </label>
        </div>

        <div class="switch-card px-header-switch">
            <span class="switch-label" id="pxHeaderLabel">PX OFF</span>
            <label class="switch">
                <input type="checkbox" id="pxHeaderSwitch">
                <span class="slider"></span>
            </label>
        </div>

        <div class="switch-card danger">
            <span class="switch-label" id="liveLabel">PAPER</span>
            <label class="switch">
                <input type="checkbox" id="liveSwitch">
                <span class="slider"></span>
            </label>
        </div>

        <div class="switch-card">
            <span class="switch-label" id="autoLabel">AUTO OFF</span>
            <label class="switch">
                <input type="checkbox" id="autoSwitch">
                <span class="slider"></span>
            </label>
        </div>
    </div>
</header>

<section class="pm-grid">
    <div class="pm-card"><span>Status</span><strong id="pmStatus">--</strong></div>
    <div class="pm-card"><span>Open</span><strong id="pmOpen">--</strong></div>
    <div class="pm-card"><span>Profit</span><strong id="pmProfit">--</strong></div>
    <div class="pm-card"><span>Drawdown</span><strong id="pmDrawdown">--</strong></div>
    <div class="pm-card"><span>Danger</span><strong id="pmDanger">--</strong></div>
    <div class="pm-card"><span>Long</span><strong id="pmLong">--</strong></div>
    <div class="pm-card"><span>Short</span><strong id="pmShort">--</strong></div>
    <div class="pm-card"><span>Exposure</span><strong id="pmExposure">--</strong></div>
</section>

<section class="card module-card">
    <div class="card-head">
        <h2>Position Lifecycle</h2>
        <input id="pmSearch" placeholder="Search positions...">
    </div>
    <table class="module-table">
        <thead>
        <tr>
            <th>Pair</th><th>Side</th><th>PnL</th><th>Lifecycle</th><th>Dynamic SL</th>
            <th>TP Ladder</th><th>Recovery</th><th>Action</th><th>Signal</th><th>Opened</th>
        </tr>
        </thead>
        <tbody id="pmPositions"><tr><td colspan="10">Loading...</td></tr></tbody>
    </table>
</section>

<section class="layout">
    <div class="card module-card">
        <h2>Position Manager Control</h2>
        <div class="pm-actions">
            <button class="pm-btn green" onclick="enableManager()"><span class="material-icons">power_settings_new</span>Enable manager</button>
            <button class="pm-btn red" onclick="disableManager()"><span class="material-icons">power_off</span>Disable manager</button>
        </div>
        <div class="notice">
            Position Manager se sada može paliti i iz header switch-a. U v1 je monitoring/decision layer; real partial exit/SL modify ide u narednom executor update-u.
        </div>
    </div>

    <div class="card module-card">
        <h2>Protection Config</h2>
        <div class="pm-config">
            <label><input type="checkbox" id="cfg_breakeven_enabled"> Breakeven</label>
            <label><input type="checkbox" id="cfg_trailing_enabled"> Trailing</label>
            <label><input type="checkbox" id="cfg_partial_tp_enabled"> Partial TP</label>
            <label><input type="checkbox" id="cfg_emergency_exit_enabled"> Emergency</label>
            <label><input type="checkbox" id="cfg_exit_on_critical_drawdown"> Exit critical DD</label>
            <label><input type="checkbox" id="cfg_exit_on_low_quality"> Exit low quality</label>

            <label>Breakeven profit <input type="number" step="0.001" id="cfg_breakeven_profit"></label>
            <label>Trailing start <input type="number" step="0.001" id="cfg_trailing_start"></label>
            <label>Aggressive trailing <input type="number" step="0.001" id="cfg_trailing_aggressive_start"></label>
            <label>Medium drawdown <input type="number" step="0.001" id="cfg_medium_drawdown"></label>
            <label>High drawdown <input type="number" step="0.001" id="cfg_high_drawdown"></label>
            <label>Critical drawdown <input type="number" step="0.001" id="cfg_critical_drawdown"></label>

            <button class="pm-btn yellow config-save" onclick="saveManagerConfig()">Save config</button>
        </div>
    </div>
</section>

<section class="card module-card">
    <div class="card-head">
        <h2>Position Events</h2>
        <input id="pmEventSearch" placeholder="Search events...">
    </div>
    <table class="module-table">
        <thead><tr><th>Time</th><th>Pair</th><th>Type</th><th>Reason</th><th>Action</th></tr></thead>
        <tbody id="pmEvents"><tr><td colspan="5">Loading...</td></tr></tbody>
    </table>
</section>

</main>
</div>
<script src="../assets/js/header-switches.js"></script>
<script src="../assets/js/module-common.js"></script>
<script src="../assets/js/topbar-controls.js"></script>

<script src="../assets/js/position-manager-module.js"></script>
</body>
</html>
