<?php
$pageTitle='Supervisor';
$pageSubtitle='Master process za pokretanje i nadzor svih NewTrade engine servisa.';
$moduleScript='supervisor-module.js';
$extraCss='supervisor.css';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?php echo htmlspecialchars($pageTitle); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/hud.css">
<link rel="stylesheet" href="../assets/css/modules.css">
<link rel="stylesheet" href="../assets/css/header-switches.css">
<link rel="stylesheet" href="../assets/css/supervisor.css">
<link rel="stylesheet" href="../assets/css/layout-unified.css">
</head>
<body>
<div class="app" id="appRoot">
<aside class="sidebar" id="sidebar">
    <div class="brand">
        <div class="brand-left">
            <span class="material-icons brand-icon">analytics</span>
            <span class="brand-text">NewTrade</span>
        </div>
        <button class="collapse-btn" id="collapseBtn"><span class="material-icons">chevron_left</span></button>
    </div>

    
    <nav class="side-nav compact-nav">

        <div class="nav-group">
            <div class="nav-group-title">Core</div>

            <a href="../index.php" data-section="dashboard">
                <span class="material-icons">dashboard</span>
                <span class="nav-label">Dashboard</span>
            </a>

            <a href="supervisor.php" data-section="supervisor">
                <span class="material-icons">settings_power</span>
                <span class="nav-label">Supervisor</span>
            </a>
        </div>

        <div class="nav-group">
            <div class="nav-group-title">Signals</div>

            <a href="signals.php" data-section="signals">
                <span class="material-icons">stacked_line_chart</span>
                <span class="nav-label">Signals</span>
            </a>

            <a href="agents.php" data-section="agents">
                <span class="material-icons">psychology</span>
                <span class="nav-label">Agents</span>
            </a>

            <a href="risk.php" data-section="risk">
                <span class="material-icons">shield</span>
                <span class="nav-label">Risk</span>
            </a>
        </div>

        <div class="nav-group">
            <div class="nav-group-title">Execution</div>

            <a href="strategies.php" data-section="strategies">
                <span class="material-icons">account_tree</span>
                <span class="nav-label">Strategies</span>
            </a>

            <a href="orchestrator.php" data-section="orchestrator">
                <span class="material-icons">hub</span>
                <span class="nav-label">Orchestrator</span>
            </a>

            <a href="execution.php" data-section="execution">
                <span class="material-icons">bolt</span>
                <span class="nav-label">Execution</span>
            </a>

            <a href="adapter.php" data-section="adapter">
                <span class="material-icons">electrical_services</span>
                <span class="nav-label">Adapter</span>
            </a>
        </div>

        <div class="nav-group">
            <div class="nav-group-title">Positions</div>

            <a href="positions.php" data-section="positions">
                <span class="material-icons">show_chart</span>
                <span class="nav-label">Positions</span>
            </a>

            <a href="position_manager.php" data-section="position_manager">
                <span class="material-icons">precision_manufacturing</span>
                <span class="nav-label">Position Manager</span>
            </a>

            <a href="position_executor.php" data-section="position_executor">
                <span class="material-icons">published_with_changes</span>
                <span class="nav-label">Position Executor</span>
            </a>
        </div>

        <div class="nav-group">
            <div class="nav-group-title">System</div>

            <a href="logs.php" data-section="logs">
                <span class="material-icons">terminal</span>
                <span class="nav-label">Logs</span>
            </a>
        </div>

    </nav>

</aside>

<main class="main">
<header class="topbar unified-topbar">
    <div class="topbar-title">
        <h1><?php echo htmlspecialchars($pageTitle); ?></h1>
        <p><?php echo htmlspecialchars($pageSubtitle); ?></p>
    </div>

    <div class="badges unified-badges">
        <span id="freqHeaderState" class="badge blue">
            <span class="dot"></span>
            FREQTRADE CHECKING
        </span>

        <span id="engineHeaderState" class="badge blue">
            <span class="dot"></span>
            ENGINE CHECKING
        </span>

        <div class="switch-card adapter-header-switch">
            <span class="switch-label" id="adapterHeaderLabel">ADAPTER OFF</span>
            <label class="switch">
                <input type="checkbox" id="adapterHeaderSwitch">
                <span class="slider"></span>
            </label>
        </div>

        <div class="switch-card pm-header-switch">
            <span class="switch-label" id="pmHeaderLabel">PM OFF</span>
            <label class="switch">
                <input type="checkbox" id="pmHeaderSwitch">
                <span class="slider"></span>
            </label>
        </div>

        <div class="switch-card px-header-switch">
            <span class="switch-label" id="pxHeaderLabel">PX OFF</span>
            <label class="switch">
                <input type="checkbox" id="pxHeaderSwitch">
                <span class="slider"></span>
            </label>
        </div>

        <div class="switch-card danger">
            <span class="switch-label" id="liveLabel">PAPER</span>
            <label class="switch">
                <input type="checkbox" id="liveSwitch">
                <span class="slider"></span>
            </label>
        </div>

        <div class="switch-card">
            <span class="switch-label" id="autoLabel">AUTO OFF</span>
            <label class="switch">
                <input type="checkbox" id="autoSwitch">
                <span class="slider"></span>
            </label>
        </div>
    </div>
</header>

<section class="sup-grid">
    <div class="sup-card"><span>Status</span><strong id="supStatus">--</strong></div>
    <div class="sup-card"><span>Running</span><strong id="supRunning">--</strong></div>
    <div class="sup-card"><span>Stopped</span><strong id="supStopped">--</strong></div>
    <div class="sup-card"><span>Restart delay</span><strong id="supDelay">--</strong></div>
</section>

<section class="card module-card">
    <div class="card-head">
        <h2>Services</h2>
        <button class="sup-btn yellow" onclick="saveSupervisorConfig()"><span class="material-icons">save</span>Save config</button>
    </div>
    <table class="module-table">
        <thead><tr><th>Service</th><th>PID</th><th>Status</th><th>Enabled</th><th>Auto restart</th><th>Command</th></tr></thead>
        <tbody id="supServices"><tr><td colspan="6">Loading...</td></tr></tbody>
    </table>
</section>

<section class="card module-card">
    <h2>How to run</h2>
    <pre class="sup-pre">cd C:\xampp\htdocs\newtrade_02\engine
.\.venv\Scripts\Activate.ps1
python supervisor.py</pre>
</section>

</main>
</div>
<script src="../assets/js/header-switches.js"></script>
<script src="../assets/js/module-common.js"></script>
<script src="../assets/js/topbar-controls.js"></script>

<script src="../assets/js/supervisor-module.js"></script>
</body>
</html>
