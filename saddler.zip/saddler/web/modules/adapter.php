<?php
$pageTitle='Execution Adapter';
$pageSubtitle='Adapter koji šalje READY tradeove prema Freqtrade API-ju i prati exit zaštite.';
$moduleScript='adapter-module.js';
$extraCss='adapter.css';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?php echo htmlspecialchars($pageTitle); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/hud.css">
<link rel="stylesheet" href="../assets/css/modules.css">
<link rel="stylesheet" href="../assets/css/header-switches.css">
<link rel="stylesheet" href="../assets/css/adapter.css">
<link rel="stylesheet" href="../assets/css/layout-compact.css">
<link rel="stylesheet" href="../assets/css/layout-unified.css">
</head>
<body>
<div class="app" id="appRoot">
<aside class="sidebar" id="sidebar">
    <div class="brand">
        <div class="brand-left">
            <span class="material-icons brand-icon">analytics</span>
            <span class="brand-text">NewTrade</span>
        </div>
        <button class="collapse-btn" id="collapseBtn" title="Collapse sidebar">
            <span class="material-icons">chevron_left</span>
        </button>
    </div>

    
    
    <nav class="side-nav compact-nav">

        <div class="nav-group">
            <div class="nav-group-title">Core</div>

            <a href="../index.php" data-section="dashboard">
                <span class="material-icons">dashboard</span>
                <span class="nav-label">Dashboard</span>
            </a>

            <a href="supervisor.php" data-section="supervisor">
                <span class="material-icons">settings_power</span>
                <span class="nav-label">Supervisor</span>
            </a>
        </div>

        <div class="nav-group">
            <div class="nav-group-title">Signals</div>

            <a href="signals.php" data-section="signals">
                <span class="material-icons">stacked_line_chart</span>
                <span class="nav-label">Signals</span>
            </a>

            <a href="agents.php" data-section="agents">
                <span class="material-icons">psychology</span>
                <span class="nav-label">Agents</span>
            </a>

            <a href="risk.php" data-section="risk">
                <span class="material-icons">shield</span>
                <span class="nav-label">Risk</span>
            </a>
        </div>

        <div class="nav-group">
            <div class="nav-group-title">Execution</div>

            <a href="strategies.php" data-section="strategies">
                <span class="material-icons">account_tree</span>
                <span class="nav-label">Strategies</span>
            </a>

            <a href="orchestrator.php" data-section="orchestrator">
                <span class="material-icons">hub</span>
                <span class="nav-label">Orchestrator</span>
            </a>

            <a href="execution.php" data-section="execution">
                <span class="material-icons">bolt</span>
                <span class="nav-label">Execution</span>
            </a>

            <a href="adapter.php" data-section="adapter">
                <span class="material-icons">electrical_services</span>
                <span class="nav-label">Adapter</span>
            </a>
        </div>

        <div class="nav-group">
            <div class="nav-group-title">Positions</div>

            <a href="positions.php" data-section="positions">
                <span class="material-icons">show_chart</span>
                <span class="nav-label">Positions</span>
            </a>

            <a href="position_manager.php" data-section="position_manager">
                <span class="material-icons">precision_manufacturing</span>
                <span class="nav-label">Position Manager</span>
            </a>

            <a href="position_executor.php" data-section="position_executor">
                <span class="material-icons">published_with_changes</span>
                <span class="nav-label">Position Executor</span>
            </a>
        </div>

        <div class="nav-group">
            <div class="nav-group-title">System</div>

            <a href="logs.php" data-section="logs">
                <span class="material-icons">terminal</span>
                <span class="nav-label">Logs</span>
            </a>
        </div>

    </nav>


</aside>

<main class="main">
<header class="topbar unified-topbar">
    <div class="topbar-title">
        <h1><?php echo htmlspecialchars($pageTitle); ?></h1>
        <p><?php echo htmlspecialchars($pageSubtitle); ?></p>
    </div>

    <div class="badges unified-badges">
        <span id="freqHeaderState" class="badge blue">
            <span class="dot"></span>
            FREQTRADE CHECKING
        </span>

        <span id="engineHeaderState" class="badge blue">
            <span class="dot"></span>
            ENGINE CHECKING
        </span>

        <div class="switch-card adapter-header-switch">
            <span class="switch-label" id="adapterHeaderLabel">ADAPTER OFF</span>
            <label class="switch">
                <input type="checkbox" id="adapterHeaderSwitch">
                <span class="slider"></span>
            </label>
        </div>

        <div class="switch-card pm-header-switch">
            <span class="switch-label" id="pmHeaderLabel">PM OFF</span>
            <label class="switch">
                <input type="checkbox" id="pmHeaderSwitch">
                <span class="slider"></span>
            </label>
        </div>

        <div class="switch-card px-header-switch">
            <span class="switch-label" id="pxHeaderLabel">PX OFF</span>
            <label class="switch">
                <input type="checkbox" id="pxHeaderSwitch">
                <span class="slider"></span>
            </label>
        </div>

        <div class="switch-card danger">
            <span class="switch-label" id="liveLabel">PAPER</span>
            <label class="switch">
                <input type="checkbox" id="liveSwitch">
                <span class="slider"></span>
            </label>
        </div>

        <div class="switch-card">
            <span class="switch-label" id="autoLabel">AUTO OFF</span>
            <label class="switch">
                <input type="checkbox" id="autoSwitch">
                <span class="slider"></span>
            </label>
        </div>
    </div>
</header>

<section class="adapter-grid">
    <div class="adapter-card"><span>Status</span><strong id="adapterStatus">--</strong></div>
    <div class="adapter-card"><span>Freqtrade</span><strong id="adapterFreqtrade">--</strong></div>
    <div class="adapter-card"><span>Execution Enabled</span><strong id="adapterEnabled">--</strong></div>
    <div class="adapter-card"><span>Open Trades</span><strong id="adapterOpenTrades">--</strong></div>
</section>

<section class="layout">
    <div class="card module-card">
        <h2>Adapter Control</h2>
        <div class="adapter-actions">
            <button class="adapter-btn green" onclick="enableAdapter()"><span class="material-icons">power_settings_new</span>Enable adapter</button>
            <button class="adapter-btn red" onclick="disableAdapter()"><span class="material-icons">power_off</span>Disable adapter</button>
        </div>
        <div class="notice">
            Adapter se sada može paliti i iz header switch-a. Za realno slanje tradeova moraju biti: AUTO ON, Adapter ON, Freqtrade online, READY signal i odgovarajući PAPER/LIVE guard.
        </div>
    </div>

    <div class="card module-card">
        <h2>Execution Guards</h2>
        <div class="adapter-config">
            <label><input type="checkbox" id="cfg_force_entry_enabled"> Force entry enabled</label>
            <label><input type="checkbox" id="cfg_force_exit_enabled"> Force exit enabled</label>
            <label><input type="checkbox" id="cfg_paper_execution_enabled"> Paper execution enabled</label>
            <label><input type="checkbox" id="cfg_live_execution_enabled"> Live execution enabled</label>
            <label><input type="checkbox" id="cfg_exit_on_blocked_pair"> Exit on blocked pair</label>
            <label><input type="checkbox" id="cfg_exit_profit_guard_enabled"> Exit profit guard</label>

            <label>Max entries per cycle <input type="number" id="cfg_max_entries_per_cycle"></label>
            <label>Exit profit below <input type="number" step="0.001" id="cfg_exit_profit_below"></label>
            <label>Loop seconds <input type="number" step="0.5" id="cfg_loop_seconds"></label>

            <button class="adapter-btn yellow" onclick="saveAdapterConfig()">Save adapter config</button>
        </div>
    </div>
</section>

<section class="layout">
    <div class="card module-card">
        <h2>Last Entry / Exit</h2>
        <pre id="adapterLast" class="adapter-json">Loading...</pre>
    </div>
    <div class="card module-card">
        <h2>Last Error</h2>
        <pre id="adapterError" class="adapter-json">Loading...</pre>
    </div>
</section>

<section class="card module-card">
    <div class="card-head">
        <h2>Adapter History</h2>
        <input id="adapterHistorySearch" placeholder="Search history...">
    </div>
    <table class="module-table">
        <thead><tr><th>Time</th><th>Event</th><th>Pair</th><th>Side</th><th>Status</th><th>Reason</th></tr></thead>
        <tbody id="adapterHistory"><tr><td colspan="6">Loading...</td></tr></tbody>
    </table>
</section>

</main>
</div>
<script src="../assets/js/header-switches.js"></script>
<script src="../assets/js/module-common.js"></script>
<script src="../assets/js/topbar-controls.js"></script>

<script src="../assets/js/adapter-module.js"></script>
</body>
</html>
