<?php
$pageTitle='Position Executor';
$pageSubtitle='Executes emergency exit and records breakeven, trailing and partial TP intents.';
$moduleScript='position-executor-module.js';
$extraCss='position-executor.css';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?php echo htmlspecialchars($pageTitle); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/hud.css">
<link rel="stylesheet" href="../assets/css/modules.css">
<link rel="stylesheet" href="../assets/css/header-switches.css">
<link rel="stylesheet" href="../assets/css/position-executor.css">
<link rel="stylesheet" href="../assets/css/layout-unified.css">
</head>
<body>
<div class="app" id="appRoot">
<aside class="sidebar" id="sidebar">
    <div class="brand">
        <div class="brand-left">
            <span class="material-icons brand-icon">analytics</span>
            <span class="brand-text">NewTrade</span>
        </div>
        <button class="collapse-btn" id="collapseBtn"><span class="material-icons">chevron_left</span></button>
    </div>

    
    <nav class="side-nav compact-nav">

        <div class="nav-group">
            <div class="nav-group-title">Core</div>

            <a href="../index.php" data-section="dashboard">
                <span class="material-icons">dashboard</span>
                <span class="nav-label">Dashboard</span>
            </a>

            <a href="supervisor.php" data-section="supervisor">
                <span class="material-icons">settings_power</span>
                <span class="nav-label">Supervisor</span>
            </a>
        </div>

        <div class="nav-group">
            <div class="nav-group-title">Signals</div>

            <a href="signals.php" data-section="signals">
                <span class="material-icons">stacked_line_chart</span>
                <span class="nav-label">Signals</span>
            </a>

            <a href="agents.php" data-section="agents">
                <span class="material-icons">psychology</span>
                <span class="nav-label">Agents</span>
            </a>

            <a href="risk.php" data-section="risk">
                <span class="material-icons">shield</span>
                <span class="nav-label">Risk</span>
            </a>
        </div>

        <div class="nav-group">
            <div class="nav-group-title">Execution</div>

            <a href="strategies.php" data-section="strategies">
                <span class="material-icons">account_tree</span>
                <span class="nav-label">Strategies</span>
            </a>

            <a href="orchestrator.php" data-section="orchestrator">
                <span class="material-icons">hub</span>
                <span class="nav-label">Orchestrator</span>
            </a>

            <a href="execution.php" data-section="execution">
                <span class="material-icons">bolt</span>
                <span class="nav-label">Execution</span>
            </a>

            <a href="adapter.php" data-section="adapter">
                <span class="material-icons">electrical_services</span>
                <span class="nav-label">Adapter</span>
            </a>
        </div>

        <div class="nav-group">
            <div class="nav-group-title">Positions</div>

            <a href="positions.php" data-section="positions">
                <span class="material-icons">show_chart</span>
                <span class="nav-label">Positions</span>
            </a>

            <a href="position_manager.php" data-section="position_manager">
                <span class="material-icons">precision_manufacturing</span>
                <span class="nav-label">Position Manager</span>
            </a>

            <a href="position_executor.php" data-section="position_executor">
                <span class="material-icons">published_with_changes</span>
                <span class="nav-label">Position Executor</span>
            </a>
        </div>

        <div class="nav-group">
            <div class="nav-group-title">System</div>

            <a href="logs.php" data-section="logs">
                <span class="material-icons">terminal</span>
                <span class="nav-label">Logs</span>
            </a>
        </div>

    </nav>

</aside>

<main class="main">
<header class="topbar unified-topbar">
    <div class="topbar-title">
        <h1><?php echo htmlspecialchars($pageTitle); ?></h1>
        <p><?php echo htmlspecialchars($pageSubtitle); ?></p>
    </div>

    <div class="badges unified-badges">
        <span id="freqHeaderState" class="badge blue">
            <span class="dot"></span>
            FREQTRADE CHECKING
        </span>

        <span id="engineHeaderState" class="badge blue">
            <span class="dot"></span>
            ENGINE CHECKING
        </span>

        <div class="switch-card adapter-header-switch">
            <span class="switch-label" id="adapterHeaderLabel">ADAPTER OFF</span>
            <label class="switch">
                <input type="checkbox" id="adapterHeaderSwitch">
                <span class="slider"></span>
            </label>
        </div>

        <div class="switch-card pm-header-switch">
            <span class="switch-label" id="pmHeaderLabel">PM OFF</span>
            <label class="switch">
                <input type="checkbox" id="pmHeaderSwitch">
                <span class="slider"></span>
            </label>
        </div>

        <div class="switch-card px-header-switch">
            <span class="switch-label" id="pxHeaderLabel">PX OFF</span>
            <label class="switch">
                <input type="checkbox" id="pxHeaderSwitch">
                <span class="slider"></span>
            </label>
        </div>

        <div class="switch-card danger">
            <span class="switch-label" id="liveLabel">PAPER</span>
            <label class="switch">
                <input type="checkbox" id="liveSwitch">
                <span class="slider"></span>
            </label>
        </div>

        <div class="switch-card">
            <span class="switch-label" id="autoLabel">AUTO OFF</span>
            <label class="switch">
                <input type="checkbox" id="autoSwitch">
                <span class="slider"></span>
            </label>
        </div>
    </div>
</header>

<section class="px-grid">
    <div class="px-card"><span>Status</span><strong id="pxStatus">--</strong></div>
    <div class="px-card"><span>Freqtrade</span><strong id="pxFreqtrade">--</strong></div>
    <div class="px-card"><span>Enabled</span><strong id="pxEnabled">--</strong></div>
    <div class="px-card"><span>Actions sent</span><strong id="pxActions">--</strong></div>
</section>

<section class="layout">
    <div class="card module-card">
        <h2>Executor Control</h2>
        <div class="px-actions">
            <button class="px-btn green" onclick="enableExecutor()"><span class="material-icons">power_settings_new</span>Enable executor</button>
            <button class="px-btn red" onclick="disableExecutor()"><span class="material-icons">power_off</span>Disable executor</button>
        </div>
        <div class="notice">
            Position Executor v2 šalje FULL EXIT samo za EMERGENCY/CRITICAL uslove. Breakeven, trailing i partial TP se trenutno bilježe kao intent, bez slanja ordera.
        </div>
    </div>

    <div class="card module-card">
        <h2>Executor Guards</h2>
        <div class="px-config">
            <label><input type="checkbox" id="cfg_paper_execution_enabled"> Paper enabled</label>
            <label><input type="checkbox" id="cfg_live_execution_enabled"> Live enabled</label>
            <label><input type="checkbox" id="cfg_breakeven_executor_enabled"> Breakeven intent</label>
            <label><input type="checkbox" id="cfg_trailing_executor_enabled"> Trailing intent</label>
            <label><input type="checkbox" id="cfg_partial_tp_executor_enabled"> Partial TP intent</label>
            <label><input type="checkbox" id="cfg_emergency_exit_executor_enabled"> Emergency exit</label>
            <label><input type="checkbox" id="cfg_execute_emergency_exit"> Execute emergency</label>
            <label><input type="checkbox" id="cfg_execute_reduce_or_exit"> Execute reduce/exit</label>

            <label>Min seconds between actions <input type="number" id="cfg_min_seconds_between_actions"></label>
            <label>Max actions per cycle <input type="number" id="cfg_max_actions_per_cycle"></label>
            <label>Loop seconds <input type="number" step="0.5" id="cfg_loop_seconds"></label>

            <button class="px-btn yellow config-save" onclick="saveExecutorConfig()">Save config</button>
        </div>
    </div>
</section>

<section class="layout">
    <div class="card module-card">
        <h2>Last Action</h2>
        <pre id="pxLastAction" class="px-json">Loading...</pre>
    </div>
    <div class="card module-card">
        <h2>Last Error</h2>
        <pre id="pxLastError" class="px-json">Loading...</pre>
    </div>
</section>

<section class="card module-card">
    <div class="card-head">
        <h2>Executor Events</h2>
        <input id="pxSearch" placeholder="Search events...">
    </div>
    <table class="module-table">
        <thead><tr><th>Time</th><th>Type</th><th>Pair</th><th>Action</th><th>Status</th><th>Reason</th></tr></thead>
        <tbody id="pxEvents"><tr><td colspan="6">Loading...</td></tr></tbody>
    </table>
</section>

</main>
</div>
<script src="../assets/js/header-switches.js"></script>
<script src="../assets/js/module-common.js"></script>
<script src="../assets/js/topbar-controls.js"></script>

<script src="../assets/js/position-executor-module.js"></script>
</body>
</html>
