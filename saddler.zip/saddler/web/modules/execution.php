<?php
$pageTitle='Execution Engine';
$pageSubtitle='Priority queue, signal expiry, consensus scoring, anti-overtrade and protections.';
$moduleScript='execution-module.js';
$extraCss='execution.css';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?php echo htmlspecialchars($pageTitle); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/hud.css">
<link rel="stylesheet" href="../assets/css/modules.css">
<link rel="stylesheet" href="../assets/css/header-switches.css">
<link rel="stylesheet" href="../assets/css/execution.css">
<link rel="stylesheet" href="../assets/css/layout-compact.css">
<link rel="stylesheet" href="../assets/css/layout-unified.css">
</head>
<body>
<div class="app" id="appRoot">
<aside class="sidebar" id="sidebar">
    <div class="brand">
        <div class="brand-left">
            <span class="material-icons brand-icon">analytics</span>
            <span class="brand-text">NewTrade</span>
        </div>
        <button class="collapse-btn" id="collapseBtn" title="Collapse sidebar">
            <span class="material-icons">chevron_left</span>
        </button>
    </div>

    
    
    <nav class="side-nav compact-nav">

        <div class="nav-group">
            <div class="nav-group-title">Core</div>

            <a href="../index.php" data-section="dashboard">
                <span class="material-icons">dashboard</span>
                <span class="nav-label">Dashboard</span>
            </a>

            <a href="supervisor.php" data-section="supervisor">
                <span class="material-icons">settings_power</span>
                <span class="nav-label">Supervisor</span>
            </a>
        </div>

        <div class="nav-group">
            <div class="nav-group-title">Signals</div>

            <a href="signals.php" data-section="signals">
                <span class="material-icons">stacked_line_chart</span>
                <span class="nav-label">Signals</span>
            </a>

            <a href="agents.php" data-section="agents">
                <span class="material-icons">psychology</span>
                <span class="nav-label">Agents</span>
            </a>

            <a href="risk.php" data-section="risk">
                <span class="material-icons">shield</span>
                <span class="nav-label">Risk</span>
            </a>
        </div>

        <div class="nav-group">
            <div class="nav-group-title">Execution</div>

            <a href="strategies.php" data-section="strategies">
                <span class="material-icons">account_tree</span>
                <span class="nav-label">Strategies</span>
            </a>

            <a href="orchestrator.php" data-section="orchestrator">
                <span class="material-icons">hub</span>
                <span class="nav-label">Orchestrator</span>
            </a>

            <a href="execution.php" data-section="execution">
                <span class="material-icons">bolt</span>
                <span class="nav-label">Execution</span>
            </a>

            <a href="adapter.php" data-section="adapter">
                <span class="material-icons">electrical_services</span>
                <span class="nav-label">Adapter</span>
            </a>
        </div>

        <div class="nav-group">
            <div class="nav-group-title">Positions</div>

            <a href="positions.php" data-section="positions">
                <span class="material-icons">show_chart</span>
                <span class="nav-label">Positions</span>
            </a>

            <a href="position_manager.php" data-section="position_manager">
                <span class="material-icons">precision_manufacturing</span>
                <span class="nav-label">Position Manager</span>
            </a>

            <a href="position_executor.php" data-section="position_executor">
                <span class="material-icons">published_with_changes</span>
                <span class="nav-label">Position Executor</span>
            </a>
        </div>

        <div class="nav-group">
            <div class="nav-group-title">System</div>

            <a href="logs.php" data-section="logs">
                <span class="material-icons">terminal</span>
                <span class="nav-label">Logs</span>
            </a>
        </div>

    </nav>


</aside>

<main class="main">
<header class="topbar unified-topbar">
    <div class="topbar-title">
        <h1><?php echo htmlspecialchars($pageTitle); ?></h1>
        <p><?php echo htmlspecialchars($pageSubtitle); ?></p>
    </div>

    <div class="badges unified-badges">
        <span id="freqHeaderState" class="badge blue">
            <span class="dot"></span>
            FREQTRADE CHECKING
        </span>

        <span id="engineHeaderState" class="badge blue">
            <span class="dot"></span>
            ENGINE CHECKING
        </span>

        <div class="switch-card adapter-header-switch">
            <span class="switch-label" id="adapterHeaderLabel">ADAPTER OFF</span>
            <label class="switch">
                <input type="checkbox" id="adapterHeaderSwitch">
                <span class="slider"></span>
            </label>
        </div>

        <div class="switch-card pm-header-switch">
            <span class="switch-label" id="pmHeaderLabel">PM OFF</span>
            <label class="switch">
                <input type="checkbox" id="pmHeaderSwitch">
                <span class="slider"></span>
            </label>
        </div>

        <div class="switch-card px-header-switch">
            <span class="switch-label" id="pxHeaderLabel">PX OFF</span>
            <label class="switch">
                <input type="checkbox" id="pxHeaderSwitch">
                <span class="slider"></span>
            </label>
        </div>

        <div class="switch-card danger">
            <span class="switch-label" id="liveLabel">PAPER</span>
            <label class="switch">
                <input type="checkbox" id="liveSwitch">
                <span class="slider"></span>
            </label>
        </div>

        <div class="switch-card">
            <span class="switch-label" id="autoLabel">AUTO OFF</span>
            <label class="switch">
                <input type="checkbox" id="autoSwitch">
                <span class="slider"></span>
            </label>
        </div>
    </div>
</header>

<section class="execution-grid">
    <div class="execution-card"><span>Status</span><strong id="execStatus">--</strong></div>
    <div class="execution-card"><span>Market State</span><strong id="marketState">--</strong></div>
    <div class="execution-card"><span>Ready</span><strong id="readyCount">--</strong></div>
    <div class="execution-card"><span>Blocked</span><strong id="blockedCount">--</strong></div>
    <div class="execution-card"><span>Wait</span><strong id="waitCount">--</strong></div>
    <div class="execution-card"><span>Queue</span><strong id="queueCount">--</strong></div>
    <div class="execution-card"><span>Top Priority</span><strong id="topPriority">--</strong></div>
    <div class="execution-card"><span>Cooldown</span><strong id="cooldownCount">--</strong></div>
</section>

<section class="execution-row">
    <div class="card module-card">
        <div class="card-head">
            <h2>Trade Queue</h2>
            <input id="queueSearch" placeholder="Search queue...">
        </div>
        <table class="module-table">
            <thead>
            <tr>
                <th>Pair</th><th>Side</th><th>Status</th><th>Reason</th><th>Score</th><th>Risk</th>
                <th>Consensus</th><th>Exec</th><th>Priority</th><th>Market</th><th>Expires</th><th>Actions</th>
            </tr>
            </thead>
            <tbody id="queueTable"><tr><td colspan="12">Loading...</td></tr></tbody>
        </table>
    </div>
</section>

<section class="layout execution-two-col">
    <div class="card module-card">
        <div class="card-head"><h2>Emergency / Protection Events</h2><input id="eventSearch" placeholder="Search events..."></div>
        <table class="module-table">
            <thead><tr><th>Time</th><th>Pair</th><th>Type</th><th>Reason</th><th>Action</th></tr></thead>
            <tbody id="eventsTable"><tr><td colspan="5">Loading...</td></tr></tbody>
        </table>
    </div>

    <div class="card module-card">
        <h2>Execution Rules</h2>
        <div class="config-grid">
            <label>Entry score<input id="cfg_entry_score_min" type="number"></label>
            <label>Confidence<input id="cfg_confidence_min" type="number"></label>
            <label>Orderflow<input id="cfg_orderflow_min" type="number"></label>
            <label>Risk<input id="cfg_risk_min" type="number"></label>
            <label>Consensus<input id="cfg_consensus_min" type="number"></label>
            <label>Execution score<input id="cfg_execution_score_min" type="number"></label>
            <label>TTL min<input id="cfg_signal_ttl_minutes" type="number"></label>
            <label>Anti-overtrade min<input id="cfg_anti_overtrade_minutes" type="number"></label>
            <button class="exec-btn yellow config-save" onclick="saveConfig()">Save rules</button>
        </div>
    </div>
</section>

<section class="layout execution-two-col">
    <div class="card module-card">
        <div class="card-head"><h2>Cooldowns</h2><input id="cooldownSearch" placeholder="Search cooldowns..."></div>
        <table class="module-table">
            <thead><tr><th>Pair</th><th>Until</th><th>Reason</th><th>Actions</th></tr></thead>
            <tbody id="cooldownTable"><tr><td colspan="4">Loading...</td></tr></tbody>
        </table>
    </div>

    <div class="card module-card">
        <h2>Manual Cooldowns</h2>
        <div class="cooldown-form">
            <input id="cooldownPair" placeholder="BTC/USDT">
            <input id="cooldownMinutes" type="number" value="15" min="1">
            <input id="cooldownReason" placeholder="Reason" value="MANUAL_COOLDOWN">
            <button class="exec-btn yellow" onclick="setCooldown()">Set cooldown</button>
        </div>
    </div>
</section>

<section class="card module-card">
    <div class="card-head"><h2>Execution History</h2><input id="historySearch" placeholder="Search history..."></div>
    <table class="module-table">
        <thead><tr><th>Time</th><th>Pair</th><th>Side</th><th>Status</th><th>Reason</th><th>Exec Score</th><th>Priority</th></tr></thead>
        <tbody id="historyTable"><tr><td colspan="7">Loading...</td></tr></tbody>
    </table>
</section>

</main>
</div>
<script src="../assets/js/header-switches.js"></script>
<script src="../assets/js/module-common.js"></script>
<script src="../assets/js/topbar-controls.js"></script>

<script src="../assets/js/execution-module.js"></script>
</body>
</html>
