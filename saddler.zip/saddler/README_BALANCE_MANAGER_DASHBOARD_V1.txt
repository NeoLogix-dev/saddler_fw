NewTrade Balance Manager Dashboard v1

Kopiraj:
1) web folder preko postojećeg:
   C:\xampp\htdocs\newtrade_02\web\

2) opciono inicijalne storage fajlove:
   engine/storage/balance_manager.json
   engine/storage/balance_history.json

Dashboard raspored:
- Total Balance / Open Trades / Realized PnL / Total Realized PnL
- Risk Manager traka
- Open Trades + Balance Manager settings
- Signal Candidates + AI Consensus
- Log

Napomene:
- Total Balance kartica prikazuje static/locked balance.
- Open trade PnL ostaje u tabeli otvorenih trejdova, ne u glavnim karticama.
- Realized PnL se računa iz Freqtrade SQLite zatvorenih tradeova ako postoje profit kolone.
- Balance Manager postavke se snimaju u engine/storage/balance_manager.json.
- Freqtrade API health koristi ping + SQLite, ne opterećuje /api/v1/status.

Nakon kopiranja:
CTRL + F5
